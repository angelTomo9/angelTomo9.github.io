import { useState } from 'react'
import './App.css'
import CalendarTab from './components/CalendarTab'
import PersonSelector from './components/PersonSelector'
import ShoppingTab from './components/ShoppingTab'
import TasksTab from './components/TasksTab'
import { PEOPLE, TABS } from './constants'
import { firebaseConfigMissing, isFirebaseConfigured } from './firebase'

function App() {
  const [activeTab, setActiveTab] = useState('calendar')
  const [activePerson, setActivePerson] = useState(PEOPLE[0].name)

  return (
    <div className="app-shell">
      <header className="app-header">
        <div>
          <p className="section-eyebrow">Piso peñiscola</p>
          <h1>Organización del piso</h1>
        </div>
      </header>

      {!isFirebaseConfigured && (
        <div className="setup-warning" role="status">
          Firebase no está listo todavía. Revisa estos campos en <code>.env.local</code>: {firebaseConfigMissing.join(', ')}.
        </div>
      )}

      <main className="main-content">
        <PersonSelector activePerson={activePerson} onChange={setActivePerson} />

        {activeTab === 'calendar' && <CalendarTab activePerson={activePerson} />}
        {activeTab === 'tasks' && <TasksTab activePerson={activePerson} />}
        {activeTab === 'shopping' && <ShoppingTab activePerson={activePerson} />}
      </main>

      <nav className="bottom-nav" aria-label="Navegación principal">
        {TABS.map((tab) => (
          <button
            className={activeTab === tab.id ? 'is-active' : ''}
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            type="button"
            aria-current={activeTab === tab.id ? 'page' : undefined}
          >
            <span className="nav-icon" aria-hidden="true">{tab.icon}</span>
            <span>{tab.label}</span>
          </button>
        ))}
      </nav>
    </div>
  )
}

export default App
