export const PEOPLE = [
  { name: 'Alicia', color: '#d85c8a' },
  { name: 'Jesús', color: '#2f80ed' },
  { name: 'Pili', color: '#27ae60' },
  { name: 'Rosa', color: '#9b51e0' },
  { name: 'Invitados', color: '#f2994a' },
]

export const TABS = [
  { id: 'calendar', label: 'Calendario', icon: '📅' },
  { id: 'tasks', label: 'Tareas', icon: '✅' },
  { id: 'shopping', label: 'Compra', icon: '🛒' },
]

export const getPersonColor = (personName) => PEOPLE.find((person) => person.name === personName)?.color ?? '#4a90d9'
