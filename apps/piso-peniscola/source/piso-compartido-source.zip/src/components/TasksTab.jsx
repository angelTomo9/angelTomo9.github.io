import SharedListTab from './SharedListTab'
import { addTask, deleteTask, subscribeToTasks, toggleTaskDone } from '../services/firestoreService'

function TasksTab({ activePerson }) {
  return (
    <SharedListTab
      activePerson={activePerson}
      addItem={addTask}
      deleteItem={deleteTask}
      doneField="done"
      emptyText="No hay tareas pendientes. Todo está al día."
      inputLabel="Nueva tarea"
      placeholder="Ej. Sacar la basura"
      subscribe={subscribeToTasks}
      textField="text"
      title="Tareas"
      toggleItem={toggleTaskDone}
    />
  )
}

export default TasksTab
