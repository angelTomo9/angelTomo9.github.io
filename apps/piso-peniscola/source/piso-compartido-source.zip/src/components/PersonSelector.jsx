import { PEOPLE } from '../constants'

function PersonSelector({ activePerson, onChange }) {
  return (
    <section className="person-selector" aria-label="Selector de persona activa">
      <p className="section-eyebrow">Persona activa</p>
      <div className="person-row">
        {PEOPLE.map((person) => (
          <button
            className={`person-button ${activePerson === person.name ? 'is-active' : ''}`}
            key={person.name}
            onClick={() => onChange(person.name)}
            style={{ '--person-color': person.color }}
            type="button"
            aria-pressed={activePerson === person.name}
            aria-label={`Seleccionar a ${person.name}`}
          >
            <span className="person-initial" aria-hidden="true">{person.name.charAt(0)}</span>
            <span>{person.name}</span>
          </button>
        ))}
      </div>
    </section>
  )
}

export default PersonSelector
