import { useEffect, useState } from 'react'
import FullCalendar from '@fullcalendar/react'
import dayGridPlugin from '@fullcalendar/daygrid'
import interactionPlugin from '@fullcalendar/interaction'
import esLocale from '@fullcalendar/core/locales/es'
import { getPersonColor } from '../constants'
import { subscribeToEvents, togglePersonOnDay } from '../services/firestoreService'

function CalendarTab({ activePerson }) {
  const [events, setEvents] = useState([])
  const [error, setError] = useState('')
  const [savingDate, setSavingDate] = useState('')

  useEffect(() => {
    const unsubscribe = subscribeToEvents(setEvents, (snapshotError) => setError(snapshotError.message))
    return unsubscribe
  }, [])

  async function handleToggle(dateStr) {
    setError('')
    setSavingDate(dateStr)

    try {
      await togglePersonOnDay(dateStr, activePerson)
    } catch (toggleError) {
      setError(toggleError.message)
    } finally {
      setSavingDate('')
    }
  }

  function renderEventContent(eventInfo) {
    const people = eventInfo.event.extendedProps.people ?? []

    return (
      <div className="calendar-people" title={people.join(', ')}>
        {people.map((person) => (
          <span className="calendar-person-chip" key={person} style={{ '--person-color': getPersonColor(person) }}>
            {person}
          </span>
        ))}
      </div>
    )
  }

  return (
    <section className="tab-panel calendar-panel" aria-label="Calendario de ocupación">
      <div className="panel-heading">
        <div>
          <p className="section-eyebrow">Calendario</p>
          <h1>Ocupación del piso</h1>
        </div>
        <p className="panel-hint">Toca un día para añadir o quitar a {activePerson}.</p>
      </div>

      {savingDate && <p className="status-note">Guardando cambios para el {savingDate}…</p>}
      {error && <p className="error-note">{error}</p>}

      <div className="calendar-card">
        <FullCalendar
          plugins={[dayGridPlugin, interactionPlugin]}
          initialView="dayGridMonth"
          locale={esLocale}
          firstDay={1}
          height="auto"
          dayMaxEventRows={3}
          events={events}
          dateClick={(info) => handleToggle(info.dateStr)}
          eventClick={(info) => handleToggle(info.event.startStr)}
          eventContent={renderEventContent}
          headerToolbar={{ left: 'prev,next today', center: 'title', right: '' }}
          buttonText={{ today: 'Hoy' }}
        />
      </div>
    </section>
  )
}

export default CalendarTab
