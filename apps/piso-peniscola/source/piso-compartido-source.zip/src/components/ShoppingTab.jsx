import SharedListTab from './SharedListTab'
import { addShoppingItem, deleteShoppingItem, subscribeToShopping, toggleBought } from '../services/firestoreService'

function ShoppingTab({ activePerson }) {
  return (
    <SharedListTab
      activePerson={activePerson}
      addItem={addShoppingItem}
      deleteItem={deleteShoppingItem}
      doneField="bought"
      emptyText="La lista de la compra está vacía."
      inputLabel="Nuevo artículo para comprar"
      placeholder="Ej. Leche"
      subscribe={subscribeToShopping}
      textField="item"
      title="Compra"
      toggleItem={toggleBought}
    />
  )
}

export default ShoppingTab
