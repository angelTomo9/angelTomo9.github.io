import { useEffect, useState } from 'react'

function SharedListTab({
  activePerson,
  addItem,
  deleteItem,
  doneField,
  emptyText,
  inputLabel,
  placeholder,
  subscribe,
  textField,
  title,
  toggleItem,
}) {
  const [items, setItems] = useState([])
  const [value, setValue] = useState('')
  const [error, setError] = useState('')
  const [isAdding, setIsAdding] = useState(false)

  useEffect(() => {
    const unsubscribe = subscribe(setItems, (snapshotError) => setError(snapshotError.message))
    return unsubscribe
  }, [subscribe])

  async function handleSubmit(event) {
    event.preventDefault()
    setError('')
    setIsAdding(true)

    try {
      await addItem(value, activePerson)
      setValue('')
    } catch (addError) {
      setError(addError.message)
    } finally {
      setIsAdding(false)
    }
  }

  async function handleToggle(item) {
    setError('')
    try {
      await toggleItem(item.id, item[doneField])
    } catch (toggleError) {
      setError(toggleError.message)
    }
  }

  async function handleDelete(item) {
    setError('')
    try {
      await deleteItem(item.id)
    } catch (deleteError) {
      setError(deleteError.message)
    }
  }

  return (
    <section className="tab-panel list-panel" aria-label={title}>
      <div className="panel-heading compact">
        <div>
          <p className="section-eyebrow">{title}</p>
          <h1>{title}</h1>
        </div>
      </div>

      <form className="add-form" onSubmit={handleSubmit}>
        <label className="sr-only" htmlFor={`${textField}-input`}>{inputLabel}</label>
        <input
          id={`${textField}-input`}
          value={value}
          onChange={(event) => setValue(event.target.value)}
          placeholder={placeholder}
          autoComplete="off"
        />
        <button type="submit" disabled={isAdding || !value.trim()}>
          {isAdding ? 'Añadiendo…' : 'Añadir'}
        </button>
      </form>

      {error && <p className="error-note">{error}</p>}

      <ul className="shared-list">
        {items.map((item) => (
          <li className={`shared-item ${item[doneField] ? 'is-done' : ''}`} key={item.id}>
            <label className="shared-checkbox-row">
              <input
                type="checkbox"
                checked={item[doneField]}
                onChange={() => handleToggle(item)}
                aria-label={item[doneField] ? `Marcar como pendiente: ${item[textField]}` : `Marcar como hecho: ${item[textField]}`}
              />
              <span className="shared-item-text">{item[textField]}</span>
            </label>
            <div className="shared-item-meta">
              {item.addedBy && <span>Añadido por {item.addedBy}</span>}
              <button className="delete-button" type="button" onClick={() => handleDelete(item)} aria-label={`Eliminar ${item[textField]}`}>
                Eliminar
              </button>
            </div>
          </li>
        ))}
      </ul>

      {items.length === 0 && <p className="empty-state">{emptyText}</p>}
    </section>
  )
}

export default SharedListTab
