import { initializeApp } from 'firebase/app'
import { getFirestore } from 'firebase/firestore'

const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY,
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN,
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID,
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID,
  appId: import.meta.env.VITE_FIREBASE_APP_ID,
}

const requiredFields = ['apiKey', 'authDomain', 'projectId', 'appId']
const looksIncomplete = (value) => !value || value.includes('…') || value.includes('***') || value.includes('your-')

export const firebaseConfigMissing = Object.entries(firebaseConfig)
  .filter(([key, value]) => requiredFields.includes(key) && looksIncomplete(value))
  .map(([key]) => key)

export const isFirebaseConfigured = firebaseConfigMissing.length === 0

export const app = isFirebaseConfigured ? initializeApp(firebaseConfig) : null
export const db = app ? getFirestore(app) : null
