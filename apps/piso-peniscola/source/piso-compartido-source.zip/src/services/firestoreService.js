import {
  addDoc,
  collection,
  deleteDoc,
  doc,
  onSnapshot,
  orderBy,
  query,
  runTransaction,
  serverTimestamp,
  updateDoc,
} from 'firebase/firestore'
import { db } from '../firebase'
import { getPersonColor } from '../constants'

const notConfiguredMessage = 'Firebase no está configurado. Añade la clave completa en .env.local para activar la sincronización.'

function requireDb() {
  if (!db) {
    throw new Error(notConfiguredMessage)
  }
  return db
}

function safeSubscribe(callback) {
  callback([])
  return () => {}
}

function timestampToMillis(value) {
  if (!value) return 0
  if (typeof value.toMillis === 'function') return value.toMillis()
  if (typeof value.seconds === 'number') return value.seconds * 1000
  const parsed = new Date(value).getTime()
  return Number.isNaN(parsed) ? 0 : parsed
}

function sortByOpenThenRecent(items, doneField) {
  return [...items].sort((a, b) => {
    if (a[doneField] !== b[doneField]) return a[doneField] ? 1 : -1
    return b.createdAtMs - a.createdAtMs
  })
}

export function subscribeToEvents(callback, onError) {
  if (!db) return safeSubscribe(callback)

  return onSnapshot(
    collection(db, 'events'),
    (snapshot) => {
      const events = snapshot.docs
        .map((docSnapshot) => {
          const people = Array.isArray(docSnapshot.data().people) ? docSnapshot.data().people.filter(Boolean) : []
          if (people.length === 0) return null

          return {
            id: docSnapshot.id,
            title: people.join(', '),
            start: docSnapshot.id,
            allDay: true,
            display: 'block',
            backgroundColor: people.length === 1 ? getPersonColor(people[0]) : '#4a90d9',
            borderColor: 'transparent',
            textColor: '#ffffff',
            extendedProps: { people },
          }
        })
        .filter(Boolean)

      callback(events)
    },
    (error) => {
      console.error('Error al cargar el calendario', error)
      onError?.(error)
    },
  )
}

export async function togglePersonOnDay(dateStr, person) {
  const firestore = requireDb()
  const eventRef = doc(firestore, 'events', dateStr)

  await runTransaction(firestore, async (transaction) => {
    const eventSnapshot = await transaction.get(eventRef)
    const currentPeople = eventSnapshot.exists() && Array.isArray(eventSnapshot.data().people) ? eventSnapshot.data().people : []
    const nextPeople = currentPeople.includes(person)
      ? currentPeople.filter((currentPerson) => currentPerson !== person)
      : [...currentPeople, person]

    if (nextPeople.length === 0) {
      if (eventSnapshot.exists()) transaction.delete(eventRef)
      return
    }

    transaction.set(eventRef, { people: nextPeople }, { merge: true })
  })
}

export function subscribeToTasks(callback, onError) {
  if (!db) return safeSubscribe(callback)

  const tasksQuery = query(collection(db, 'tasks'), orderBy('createdAt', 'desc'))
  return onSnapshot(
    tasksQuery,
    (snapshot) => {
      const tasks = snapshot.docs.map((docSnapshot) => {
        const data = docSnapshot.data()
        return {
          id: docSnapshot.id,
          text: data.text ?? '',
          done: Boolean(data.done),
          addedBy: data.addedBy ?? '',
          createdAt: data.createdAt ?? null,
          createdAtMs: timestampToMillis(data.createdAt),
        }
      })

      callback(sortByOpenThenRecent(tasks, 'done'))
    },
    (error) => {
      console.error('Error al cargar las tareas', error)
      onError?.(error)
    },
  )
}

export async function addTask(text, person) {
  const trimmed = text.trim()
  if (!trimmed) return

  await addDoc(collection(requireDb(), 'tasks'), {
    text: trimmed,
    done: false,
    addedBy: person,
    createdAt: serverTimestamp(),
  })
}

export async function toggleTaskDone(docId, currentDone) {
  await updateDoc(doc(requireDb(), 'tasks', docId), { done: !currentDone })
}

export async function deleteTask(docId) {
  await deleteDoc(doc(requireDb(), 'tasks', docId))
}

export function subscribeToShopping(callback, onError) {
  if (!db) return safeSubscribe(callback)

  const shoppingQuery = query(collection(db, 'shopping'), orderBy('createdAt', 'desc'))
  return onSnapshot(
    shoppingQuery,
    (snapshot) => {
      const items = snapshot.docs.map((docSnapshot) => {
        const data = docSnapshot.data()
        return {
          id: docSnapshot.id,
          item: data.item ?? '',
          bought: Boolean(data.bought),
          addedBy: data.addedBy ?? '',
          createdAt: data.createdAt ?? null,
          createdAtMs: timestampToMillis(data.createdAt),
        }
      })

      callback(sortByOpenThenRecent(items, 'bought'))
    },
    (error) => {
      console.error('Error al cargar la compra', error)
      onError?.(error)
    },
  )
}

export async function addShoppingItem(item, person) {
  const trimmed = item.trim()
  if (!trimmed) return

  await addDoc(collection(requireDb(), 'shopping'), {
    item: trimmed,
    bought: false,
    addedBy: person,
    createdAt: serverTimestamp(),
  })
}

export async function toggleBought(docId, currentBought) {
  await updateDoc(doc(requireDb(), 'shopping', docId), { bought: !currentBought })
}

export async function deleteShoppingItem(docId) {
  await deleteDoc(doc(requireDb(), 'shopping', docId))
}
