# Piso peñiscola

App mínima para gestionar un piso compartido en Peñíscola con:

- Calendario mensual de ocupación para Alicia, Jesús, Pili, Rosa e Invitados.
- Tareas compartidas en tiempo real.
- Lista de la compra compartida en tiempo real.
- PWA instalable en iPhone desde Safari.
- APK Android generado con Capacitor.

## Stack

React + Vite, FullCalendar, Firebase Firestore y Capacitor Android. No usa login, router ni librería UI.

## Configuración Firebase

1. Crea o usa el proyecto Firebase `piso-peniscola`.
2. Activa Firestore.
3. Copia la configuración web completa en `.env.local` usando `.env.example` como plantilla.
4. Las reglas previstas para este entorno de confianza son abiertas:

```bash
firebase deploy --only firestore:rules
```

## Desarrollo

```bash
npm install
npm run dev
```

## Build web/PWA

```bash
npm run build
npm run preview
```

En iPhone, abre la URL HTTPS desplegada en Safari y usa Compartir → Añadir a pantalla de inicio.

## Android

```bash
npm run build
npx cap copy android
cd android
./gradlew assembleDebug
```

APK debug esperado:

```text
android/app/build/outputs/apk/debug/app-debug.apk
```
