package com.tuapp.piso;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
