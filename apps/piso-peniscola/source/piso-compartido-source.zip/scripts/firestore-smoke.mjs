import { initializeApp } from 'firebase/app'
import {
  addDoc,
  collection,
  deleteDoc,
  doc,
  getDoc,
  getFirestore,
  onSnapshot,
  serverTimestamp,
  setDoc,
  updateDoc,
} from 'firebase/firestore'
import fs from 'node:fs'
import path from 'node:path'

function readEnvFile(filePath) {
  const env = {}
  const content = fs.readFileSync(filePath, 'utf8')
  for (const line of content.split(/\r?\n/)) {
    if (!line || line.trim().startsWith('#')) continue
    const index = line.indexOf('=')
    if (index === -1) continue
    env[line.slice(0, index)] = line.slice(index + 1)
  }
  return env
}

const root = process.cwd()
const env = readEnvFile(path.join(root, '.env.local'))
const config = {
  apiKey: env.VITE_FIREBASE_API_KEY,
  authDomain: env.VITE_FIREBASE_AUTH_DOMAIN,
  projectId: env.VITE_FIREBASE_PROJECT_ID,
  storageBucket: env.VITE_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: env.VITE_FIREBASE_MESSAGING_SENDER_ID,
  appId: env.VITE_FIREBASE_APP_ID,
}

if (!config.apiKey || config.apiKey.includes('…') || config.apiKey.includes('*')) {
  throw new Error('La clave VITE_FIREBASE_API_KEY está incompleta o redactada. No se puede probar Firestore en vivo.')
}

const app = initializeApp(config)
const db = getFirestore(app)
const suffix = Date.now().toString(36)
const eventId = `2099-12-${String((Date.now() % 20) + 1).padStart(2, '0')}`
const eventRef = doc(db, 'events', eventId)
const taskRef = await addDoc(collection(db, 'tasks'), {
  text: `Prueba de sincronización ${suffix}`,
  done: false,
  addedBy: 'Alicia',
  createdAt: serverTimestamp(),
})
const shoppingRef = await addDoc(collection(db, 'shopping'), {
  item: `Producto de prueba ${suffix}`,
  bought: false,
  addedBy: 'Alicia',
  createdAt: serverTimestamp(),
})

let eventSeen = false
let taskSeen = false
let shoppingSeen = false

const wait = (ms) => new Promise((resolve) => setTimeout(resolve, ms))
const unsubs = [
  onSnapshot(collection(db, 'events'), (snapshot) => {
    eventSeen = snapshot.docs.some((item) => item.id === eventId && item.data().people?.includes('Alicia'))
  }),
  onSnapshot(collection(db, 'tasks'), (snapshot) => {
    taskSeen = snapshot.docs.some((item) => item.id === taskRef.id && item.data().text?.includes(suffix))
  }),
  onSnapshot(collection(db, 'shopping'), (snapshot) => {
    shoppingSeen = snapshot.docs.some((item) => item.id === shoppingRef.id && item.data().item?.includes(suffix))
  }),
]

await setDoc(eventRef, { people: ['Alicia'] }, { merge: true })
await updateDoc(taskRef, { done: true })
await updateDoc(shoppingRef, { bought: true })

for (let attempt = 0; attempt < 20 && !(eventSeen && taskSeen && shoppingSeen); attempt += 1) {
  await wait(500)
}

const eventDoc = await getDoc(eventRef)
for (const unsub of unsubs) unsub()
await deleteDoc(eventRef)
await deleteDoc(taskRef)
await deleteDoc(shoppingRef)

if (!eventSeen || !taskSeen || !shoppingSeen || !eventDoc.exists()) {
  throw new Error(`Sync incompleta: events=${eventSeen}, tasks=${taskSeen}, shopping=${shoppingSeen}`)
}

console.log('Firestore OK: events, tasks y shopping responden con onSnapshot en tiempo real.')
