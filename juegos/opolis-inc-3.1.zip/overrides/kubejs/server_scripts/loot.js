console.info('Loading loot.js for Opolis Inc')

LootJS.modifiers(event => {

    // Helper to add bounty loot to a list of mobs
    const addBounty = (mobs, fragmentItem, weapon, chance) => {
        event.addEntityModifier(mobs).addLoot(
            LootEntry.of(fragmentItem)
                .matchMainHand(weapon)
                .randomChance(chance)
        )
    }

    addBounty(
        ["cow", "sheep", "chicken", "pig", "squid", "glow_squid", "horse", "armadillo", "axolotl", "cod", "salmon", "pufferfish", "camel", "cat", "dolphin", "donkey", "frog", "llama", "mooshroom", "mule", "ocelot", "panda", "parrot", "rabbit", "sniffer", "tropical_fish", "turtle"],
        "opolisinc:basic_bounty_fragment", "minecraft:stone_sword", 0.5
    )

    addBounty(
        ["zombie", "skeleton", "creeper", "spider", "cave_spider", "enderman", "breeze"],
        "opolisinc:advanced_bounty_fragment", "minecraft:iron_sword", 0.5
    )

    addBounty(
        ["blaze", "wither_skeleton", "ghast", "piglin", "piglin_brute", "hoglin", "magma_cube", "zombified_piglin"],
        "opolisinc:elite_bounty_fragment", "minecraft:diamond_sword", 0.5
    )

    addBounty(
        ["shulker", "ender_dragon", "wither", "endermite"],
        "opolisinc:ultimate_bounty_fragment", "minecraft:netherite_sword", 0.5
    )

    // Special Enderman Loot
    event.addEntityModifier("enderman").addLoot([
        LootEntry.of("opolisinc:ultimate_bounty_fragment").matchDimension("minecraft:the_end").matchMainHand("minecraft:netherite_sword").randomChance(0.5),
        LootEntry.of("opolisinc:elite_bounty_fragment").matchDimension("minecraft:nether").matchMainHand("minecraft:diamond_sword").randomChance(0.5),
        LootEntry.of("opolisinc:activated_ender_pearl").matchDimension("minecraft:the_end").setCount([0, 1])
    ])

    event.addEntityModifier("wither_skeleton").replaceLoot("bone", "opolisinc:withered_bone", true)

    // Bacterial Mulchs
    event.addBlockModifier("opolisinc:benign_bacterial_mulch").removeLoot("opolisinc:benign_bacterial_mulch")
        .addAlternativesLoot(
            LootEntry.of("opolisinc:benign_bacterial_mulch").matchTool(ItemFilter.hasEnchantment("minecraft:silk_touch")),
            LootEntry.group([
                LootEntry.of("chicken").randomChance(0.5).applyOreBonus("minecraft:fortune"),
                LootEntry.of("leather").randomChance(0.5).applyOreBonus("minecraft:fortune"),
                LootEntry.of("feather").randomChance(0.5).applyOreBonus("minecraft:fortune"),
                LootEntry.of("ink_sac").randomChance(0.5).applyOreBonus("minecraft:fortune"),
                LootEntry.of("beef").randomChance(0.5).applyOreBonus("minecraft:fortune"),
                LootEntry.of("porkchop").randomChance(0.5).applyOreBonus("minecraft:fortune"),
                LootEntry.of("opolisinc:basic_bounty_fragment").randomChance(0.25).applyOreBonus("minecraft:fortune")
            ])
        )

    event.addBlockModifier("opolisinc:malignant_bacterial_mulch").removeLoot("opolisinc:malignant_bacterial_mulch")
        .addAlternativesLoot(
            LootEntry.of("opolisinc:malignant_bacterial_mulch").matchTool(ItemFilter.hasEnchantment("minecraft:silk_touch")),
            LootEntry.group([
                LootEntry.of("bone").randomChance(0.5).setCount([1, 3]).applyOreBonus("minecraft:fortune"),
                LootEntry.of("arrow").randomChance(0.5).setCount([1, 3]).applyOreBonus("minecraft:fortune"),
                LootEntry.of("rotten_flesh").randomChance(0.5).setCount([1, 3]).applyOreBonus("minecraft:fortune"),
                LootEntry.of("gunpowder").randomChance(0.5).applyOreBonus("minecraft:fortune"),
                LootEntry.of("spider_eye").randomChance(0.5).applyOreBonus("minecraft:fortune"),
                LootEntry.of("breeze_rod").randomChance(0.5).applyOreBonus("minecraft:fortune"),
                LootEntry.of("ender_pearl").randomChance(0.5).applyOreBonus("minecraft:fortune"),
                LootEntry.of("opolisinc:advanced_bounty_fragment").randomChance(0.25).applyOreBonus("minecraft:fortune")
            ])
        )

    event.addBlockModifier("opolisinc:feverish_bacterial_mulch").removeLoot("opolisinc:feverish_bacterial_mulch")
        .addAlternativesLoot(
            LootEntry.of("opolisinc:feverish_bacterial_mulch").matchTool(ItemFilter.hasEnchantment("minecraft:silk_touch")),
            LootEntry.group([
                LootEntry.of("blaze_rod").randomChance(0.5).setCount([2, 4]).applyOreBonus("minecraft:fortune"),
                LootEntry.of("ghast_tear").randomChance(0.5).setCount([1, 3]).applyOreBonus("minecraft:fortune"),
                LootEntry.of("opolisinc:withered_bone").randomChance(0.5).setCount([2, 3]).applyOreBonus("minecraft:fortune"),
                LootEntry.of("opolisinc:elite_bounty_fragment").randomChance(0.25).applyOreBonus("minecraft:fortune")
            ])
        )

    event.addBlockModifier("opolisinc:draconic_bacterial_mulch").removeLoot("opolisinc:draconic_bacterial_mulch")
        .addAlternativesLoot(
            LootEntry.of("opolisinc:draconic_bacterial_mulch").matchTool(ItemFilter.hasEnchantment("minecraft:silk_touch")),
            LootEntry.group([
                LootEntry.of("shulker_shell").randomChance(0.5).setCount([1, 4]).applyOreBonus("minecraft:fortune"),
                LootEntry.of("opolisinc:activated_ender_pearl").randomChance(0.5).setCount([1, 2]).applyOreBonus("minecraft:fortune"),
                LootEntry.of("opolisinc:ultimate_bounty_fragment").randomChance(0.25).applyOreBonus("minecraft:fortune")
            ])
        )

    event.addBlockModifier("opolisinc:irradiated_bacterial_mulch").removeLoot("opolisinc:irradiated_bacterial_mulch")
        .addAlternativesLoot(
            LootEntry.of("opolisinc:irradiated_bacterial_mulch").matchTool(ItemFilter.hasEnchantment("minecraft:silk_touch")),
            LootEntry.of("opolisinc:mutated_supercell")
        )

    // License Ores 
    const licenseOres = [
        { block: "basic", fragment: "basic" },
        { block: "advanced", fragment: "advanced" },
        { block: "elite", fragment: "elite" },
        { block: "ultimate", fragment: "ultimate" }
    ]

    licenseOres.forEach(ore => {
        event.addBlockModifier(`opolisinc:${ore.block}_license_ore`)
            .removeLoot(`opolisinc:${ore.block}_license_ore`)
            .addAlternativesLoot(
                LootEntry.of(`opolisinc:${ore.block}_license_ore`).matchTool(ItemFilter.hasEnchantment("minecraft:silk_touch")),
                LootEntry.of(`opolisinc:${ore.fragment}_mining_fragment`).setCount([1, 3]).applyOreBonus("minecraft:fortune")
            )
    })

    // Trial Chambers
    event.addTableModifier("minecraft:chests/trial_chambers/reward").addLoot(LootEntry.of("heavy_core").randomChance(0.25))
    event.addTableModifier("minecraft:chests/trial_chambers/reward_ominous").addLoot(LootEntry.of("heavy_core"))

    // Ore Replacements
    const oreMap = [
        { tag: "iron", raw: "minecraft:raw_iron" },
        { tag: "copper", raw: "minecraft:raw_copper", count: [2, 5] },
        { tag: "gold", raw: "minecraft:raw_gold" },
        { tag: "aluminum", raw: "alltheores:raw_aluminum" },
        { tag: "lead", raw: "alltheores:raw_lead" },
        { tag: "nickel", raw: "alltheores:raw_nickel" },
        { tag: "osmium", raw: "alltheores:raw_osmium" },
        { tag: "platinum", raw: "alltheores:raw_platinum" },
        { tag: "silver", raw: "alltheores:raw_silver" },
        { tag: "tin", raw: "alltheores:raw_tin" },
        { tag: "uranium", raw: "alltheores:raw_uranium" },
        { tag: "zinc", raw: "alltheores:raw_zinc" },
        { tag: "iridium", raw: "alltheores:raw_iridium" }
    ]

    oreMap.forEach(ore => {
        let modifier = event.addBlockModifier(`#c:ores/${ore.tag}`)
            .replaceLoot(ore.raw, `opolisinc:activated_raw_${ore.tag}`)
            .matchDimension("minecraft:the_end")
            .applyOreBonus("minecraft:fortune")

        if (ore.count) {
            modifier.setCount(ore.count)
        }
    })

    // Sculked & Phased Crops
    const cropData = [
        { block: "minecraft:wheat", item: "minecraft:wheat", sculked: "opolisinc:sculked_wheat", phased: "opolisinc:phased_wheat", age: "7" },
        { block: "minecraft:potatoes", item: "minecraft:potato", sculked: "opolisinc:sculked_potato", phased: "opolisinc:phased_potato", age: "7" },
        { block: "minecraft:carrots", item: "minecraft:carrot", sculked: "opolisinc:sculked_carrot", phased: "opolisinc:phased_carrot", age: "7" },
        { block: "minecraft:beetroots", item: "minecraft:beetroot", sculked: "opolisinc:sculked_beetroot", phased: "opolisinc:phased_beetroot", age: "3" }
    ]

    cropData.forEach(data => {

        // 1. Sculked Crops
        event.addBlockModifier(data.block)
            .matchCustomCondition({
                block: data.block,
                condition: "minecraft:block_state_property",
                properties: { "age": data.age }
            })
            .customAction((context, loot) => {
                let pos = context.position;
                let x = pos.x;
                let y = pos.y;
                let z = pos.z;

                // Check for Sculk 2 blocks below
                let blockBelow = context.level.getBlock(Math.floor(x), Math.floor(y) - 2, Math.floor(z));

                if (blockBelow.id === "minecraft:sculk") {
                    let cropCount = 0;

                    // 1. Count existing crops (forEach works on LootBucket)
                    loot.forEach(stack => {
                        if (stack.id === data.item) {
                            cropCount += stack.count;
                        }
                    });

                    // 2. Swap if crops exist
                    if (cropCount > 0) {
                        // Use .remove() (worked in your original script)
                        loot.remove(data.item);

                        // Use .addItem() (worked in your original script)
                        loot.addItem(Item.of(data.sculked).withCount(cropCount));
                    }
                }
            });

        // 2. Phased Crops (End Dimension)
        event.addBlockModifier(data.block)
            .matchCustomCondition({
                block: data.block,
                condition: "minecraft:block_state_property",
                properties: { "age": data.age }
            })
            .matchDimension("minecraft:the_end")
            .replaceLoot(data.item, data.phased, true);
    })

})

// Other Modifiers
LootJS.modifiers(event => {
    let bannedItemsInLootTables = Ingredient.of("#opolisinc:banned_in_loot_tables").itemIds
    bannedItemsInLootTables.forEach(item => {
        event.addTableModifier("/chest|mob/").removeLoot(item)
    })
})

LootJS.modifiers(event => {
    event.addTableModifier("minecraft:gameplay/piglin_bartering").addLoot(LootEntry.of("opolisinc:piglin_receipt").randomChance(0.75))
})

// Ore Drops Replacement
LootJS.modifiers(event => {
    const mekanismOres = [
        { mod: "tin", drop: "tin" },
        { mod: "lead", drop: "lead" },
        { mod: "osmium", drop: "osmium" },
        { mod: "uranium", drop: "uranium" },
        { mod: "fluorite", drop: "fluorite", isGem: true }
    ]

    mekanismOres.forEach(ore => {
        let rawId = ore.isGem ? `mekanism:fluorite_gem` : `mekanism:raw_${ore.mod}`
        let replaceId = ore.isGem ? `alltheores:fluorite` : `alltheores:raw_${ore.mod}`

        event.addBlockModifier(`mekanism:${ore.mod}_ore`).replaceLoot(rawId, replaceId, true)
        event.addBlockModifier(`mekanism:deepslate_${ore.mod}_ore`).replaceLoot(rawId, replaceId, true)
    })
})