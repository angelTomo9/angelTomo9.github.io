//JEI

RecipeViewerEvents.removeCategories((event) => {

    event.remove('opolisutilities:cloche')
    event.remove('caveopolis:colored_crafting')

})