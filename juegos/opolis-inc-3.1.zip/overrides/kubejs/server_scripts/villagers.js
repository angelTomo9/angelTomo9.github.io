console.info('Loading villagers.js for Opolis Inc')

MoreJS.villagerTrades((event) => {

    event.removeVanillaTypedTrades()
    event.removeModdedTypedTrades()
    event.removeModdedTypedTrades("sawmill:carpenter", 5)

    //Overworld Fragments
    event.addTrade("armorer", 5, "1x opolisinc:ultimate_trading_bucks", "opolisinc:fragments_of_the_overworld")
    event.addTrade("butcher", 5, "1x opolisinc:ultimate_trading_bucks", "opolisinc:fragments_of_the_overworld")
    event.addTrade("cartographer", 5, "1x opolisinc:ultimate_trading_bucks", "opolisinc:fragments_of_the_overworld")
    event.addTrade("farmer", 5, "1x opolisinc:ultimate_trading_bucks", "opolisinc:fragments_of_the_overworld")
    event.addTrade("fisherman", 5, "1x opolisinc:ultimate_trading_bucks", "opolisinc:fragments_of_the_overworld")
    event.addTrade("fletcher", 5, "1x opolisinc:ultimate_trading_bucks", "opolisinc:fragments_of_the_overworld")
    event.addTrade("mason", 5, "1x opolisinc:ultimate_trading_bucks", "opolisinc:fragments_of_the_overworld")
    event.addTrade("shepherd", 5, "1x opolisinc:ultimate_trading_bucks", "opolisinc:fragments_of_the_overworld")
    event.addTrade("sawmill:carpenter", 5, "1x opolisinc:ultimate_trading_bucks", "opolisinc:fragments_of_the_overworld")
    event.addTrade("toolsmith", 5, "1x opolisinc:ultimate_trading_bucks", "opolisinc:fragments_of_the_overworld")
    event.addTrade("librarian", 5, "1x opolisinc:ultimate_trading_bucks", "opolisinc:fragments_of_the_overworld")
    event.addTrade("weaponsmith", 5, "1x opolisinc:ultimate_trading_bucks", "opolisinc:fragments_of_the_overworld")
    event.addTrade("cleric", 5, "1x opolisinc:ultimate_trading_bucks", "opolisinc:fragments_of_the_overworld")
    event.addTrade("leatherworker", 5, "1x opolisinc:ultimate_trading_bucks", "opolisinc:fragments_of_the_overworld")
    event.addTrade("ae2:fluix_researcher", 5, "1x opolisinc:ultimate_trading_bucks", "opolisinc:fragments_of_the_overworld")

    //Blast Furnace (Armorer)
    event.addTrade("armorer", 1, '16x opolisutilities:mini_coal', '1x opolisinc:villager_receipt_1').villagerExperience(4)
    event.addTrade("armorer", 1, '16x opolisutilities:mini_charcoal', '1x opolisinc:villager_receipt_1').villagerExperience(4)
    event.addTrade("armorer", 1, '3x minecraft:leather', '1x opolisinc:villager_receipt_1').villagerExperience(4)

    event.addTrade("armorer", 2, '6x mcwlights:copper_chain', '2x opolisinc:villager_receipt_1').villagerExperience(12)
    event.addTrade("armorer", 2, '6x mcwlights:golden_chain', '2x opolisinc:villager_receipt_1').villagerExperience(12)
    event.addTrade("armorer", 2, '6x minecraft:chain', '2x opolisinc:villager_receipt_1').villagerExperience(12)

    event.addTrade("armorer", 3, '1x minecraft:shield', '2x opolisinc:villager_receipt_1').villagerExperience(21)
    event.addTrade("armorer", 3, '1x minecraft:lava_bucket', '2x opolisinc:villager_receipt_1').villagerExperience(21)
    event.addTrade("armorer", 3, '1x casting:molten_coal_bucket', '2x opolisinc:villager_receipt_1').villagerExperience(21)

    event.addTrade("armorer", 4, '1x minecraft:anvil', '4x opolisinc:villager_receipt_1').villagerExperience(35)
    event.addTrade("armorer", 4, '1x alltheores:copper_ore_hammer', '4x opolisinc:villager_receipt_1').villagerExperience(35)
    event.addTrade("armorer", 4, '1x alltheores:iron_ore_hammer', '5x opolisinc:villager_receipt_1').villagerExperience(35)
    event.addTrade("armorer", 4, '1x alltheores:bronze_ore_hammer', '7x opolisinc:villager_receipt_1').villagerExperience(35)
    event.addTrade("armorer", 4, '1x alltheores:invar_ore_hammer', '7x opolisinc:villager_receipt_1').villagerExperience(35)
    event.addTrade("armorer", 4, '1x alltheores:platinum_ore_hammer', '10x opolisinc:villager_receipt_1').villagerExperience(35)

    event.addTrade("armorer", 5, '15x opolisinc:basic_trading_bucks', '1x opolisinc:nether_passport_fragment_1').villagerExperience(35)

    //Smoker (Butcher)

    let raw_meats = Ingredient.of("#c:foods/raw_meat").itemIds;
    raw_meats.forEach(element => {
        let noNameSpace = element.toString().replace(":", "_")
        if (element.toString().includes("farmersdelight")) {
        } else {
            event.addTrade("butcher", 1, `4x ${element}`, '1x opolisinc:villager_receipt_1').villagerExperience(4)
        }
    })
    let raw_fish = Ingredient.of("#c:foods/raw_fish").itemIds;
    raw_fish.forEach(element => {
        let noNameSpace = element.toString().replace(":", "_")
        if (element.toString().includes("farmersdelight")) {
        } else {
            event.addTrade("butcher", 2, `4x ${element}`, '1x opolisinc:villager_receipt_1').villagerExperience(12)
        }
    })

    event.addTrade("butcher", 3, '16x opolisutilities:mini_coal', '1x opolisinc:villager_receipt_1').villagerExperience(21)
    event.addTrade("butcher", 3, '16x opolisutilities:mini_charcoal', '1x opolisinc:villager_receipt_1').villagerExperience(21)

    event.addTrade("butcher", 4, '32x minecraft:kelp', '2x opolisinc:villager_receipt_1').villagerExperience(35)
    event.addTrade("butcher", 4, '12x minecraft:charcoal', '4x opolisinc:villager_receipt_1').villagerExperience(35)

    event.addTrade("butcher", 5, '15x opolisinc:basic_trading_bucks', '1x opolisinc:nether_passport_fragment_1').villagerExperience(35)

    //Cartographer (Cartography Table)

    event.addTrade("cartographer", 1, '6x minecraft:paper', '1x opolisinc:villager_receipt_1').villagerExperience(4)
    event.addTrade("cartographer", 1, '8x minecraft:glass', '1x opolisinc:villager_receipt_1').villagerExperience(4)

    event.addTrade("cartographer", 2, '1x minecraft:compass', '2x opolisinc:villager_receipt_1').villagerExperience(12)
    event.addTrade("cartographer", 2, '1x minecraft:clock', '2x opolisinc:villager_receipt_1').villagerExperience(12)

    event.addTrade("cartographer", 3, '1x minecraft:map', '3x opolisinc:villager_receipt_1').villagerExperience(21)
    event.addTrade("cartographer", 3, '1x structurecompass:structure_compass', '5x opolisinc:villager_receipt_1').villagerExperience(21)

    event.addTrade("cartographer", 4, '1x minecraft:white_banner', '4x opolisinc:villager_receipt_1').villagerExperience(35)
    event.addTrade("cartographer", 4, '1x opolisutilities:home_stone', '8x opolisinc:villager_receipt_1').villagerExperience(35)

    event.addTrade("cartographer", 5, '15x opolisinc:basic_trading_bucks', '1x opolisinc:nether_passport_fragment_1').villagerExperience(35)

    //Farmer (Composter)

    event.addTrade("farmer", 1, '8x minecraft:wheat', '1x opolisinc:villager_receipt_2').villagerExperience(4)
    event.addTrade("farmer", 1, '8x minecraft:carrot', '1x opolisinc:villager_receipt_2').villagerExperience(4)
    event.addTrade("farmer", 1, '8x minecraft:potato', '1x opolisinc:villager_receipt_2').villagerExperience(4)
    event.addTrade("farmer", 1, '8x minecraft:beetroot', '1x opolisinc:villager_receipt_2').villagerExperience(4)
    event.addTrade("farmer", 1, '8x farmersdelight:onion', '1x opolisinc:villager_receipt_2').villagerExperience(4)
    event.addTrade("farmer", 1, '8x farmersdelight:tomato', '1x opolisinc:villager_receipt_2').villagerExperience(4)
    event.addTrade("farmer", 1, '8x farmersdelight:cabbage', '1x opolisinc:villager_receipt_2').villagerExperience(4)

    event.addTrade("farmer", 2, '8x minecraft:melon_slice', '2x opolisinc:villager_receipt_2').villagerExperience(12)
    event.addTrade("farmer", 2, '8x minecraft:pumpkin', '2x opolisinc:villager_receipt_2').villagerExperience(12)
    event.addTrade("farmer", 2, '8x farmersdelight:rice', '2x opolisinc:villager_receipt_2').villagerExperience(12)

    event.addTrade("farmer", 3, '8x minecraft:sugar_cane', '3x opolisinc:villager_receipt_2').villagerExperience(21)
    event.addTrade("farmer", 3, '8x minecraft:cocoa_beans', '5x opolisinc:villager_receipt_2').villagerExperience(21)
    event.addTrade("farmer", 3, '8x minecraft:sweet_berries', '5x opolisinc:villager_receipt_2').villagerExperience(21)

    event.addTrade("farmer", 4, '8x minecraft:bamboo', '4x opolisinc:villager_receipt_2').villagerExperience(35)
    event.addTrade("farmer", 4, '8x minecraft:kelp', '8x opolisinc:villager_receipt_2').villagerExperience(35)

    event.addTrade("farmer", 5, '15x opolisinc:basic_trading_bucks', '1x opolisinc:nether_passport_fragment_2').villagerExperience(35)

    //Fishermand (Barrel)

    raw_fish.forEach(element => {
        let noNameSpace = element.toString().replace(":", "_")
        if (element.toString().includes("farmersdelight")) {
        } else {
            event.addTrade("fisherman", 1, `3x ${element}`, '1x opolisinc:villager_receipt_2').villagerExperience(4)
        }
    })

    event.addTrade("fisherman", 2, '4x minecraft:string', '1x opolisinc:villager_receipt_2').villagerExperience(12)
    event.addTrade("fisherman", 2, '8x minecraft:stick', '1x opolisinc:villager_receipt_2').villagerExperience(12)

    event.addTrade("fisherman", 3, '8x chipped:fish_barrel', '2x opolisinc:villager_receipt_2').villagerExperience(21)
    event.addTrade("fisherman", 3, '1x minecraft:cod_bucket', '3x opolisinc:villager_receipt_2').villagerExperience(21)

    event.addTrade("fisherman", 4, '1x minecraft:salmon_bucket', '4x opolisinc:villager_receipt_2').villagerExperience(35)
    event.addTrade("fisherman", 4, '1x minecraft:pufferfish_bucket', '8x opolisinc:villager_receipt_2').villagerExperience(35)

    event.addTrade("fisherman", 5, '15x opolisinc:basic_trading_bucks', '1x opolisinc:nether_passport_fragment_2').villagerExperience(35)

    //Fletcher (Fletching Table)

    event.addTrade("fletcher", 1, '8x minecraft:stick', '1x opolisinc:villager_receipt_2').villagerExperience(4)
    event.addTrade("fletcher", 1, '8x minecraft:feather', '1x opolisinc:villager_receipt_2').villagerExperience(4)

    event.addTrade("fletcher", 2, '1x minecraft:target', '2x opolisinc:villager_receipt_2').villagerExperience(12)
    event.addTrade("fletcher", 2, '1x minecraft:bow', '2x opolisinc:villager_receipt_2').villagerExperience(12)

    event.addTrade("fletcher", 3, '1x minecraft:crossbow', '3x opolisinc:villager_receipt_2').villagerExperience(21)
    event.addTrade("fletcher", 3, '10x minecraft:arrow', '5x opolisinc:villager_receipt_2').villagerExperience(21)

    event.addTrade("fletcher", 4, '10x minecraft:flint', '5x opolisinc:villager_receipt_2').villagerExperience(35)
    event.addTrade("fletcher", 4, '14x minecraft:gravel', '5x opolisinc:villager_receipt_2').villagerExperience(35)

    event.addTrade("fletcher", 5, '15x opolisinc:basic_trading_bucks', '1x opolisinc:nether_passport_fragment_2').villagerExperience(35)

    //Mason (Stonecutter)

    event.addTrade("mason", 1, '8x minecraft:stone', '1x opolisinc:villager_receipt_3').villagerExperience(4)
    event.addTrade("mason", 1, '8x minecraft:cobblestone', '1x opolisinc:villager_receipt_3').villagerExperience(4)

    event.addTrade("mason", 2, '8x minecraft:brick', '2x opolisinc:villager_receipt_3').villagerExperience(12)
    event.addTrade("mason", 2, '8x minecraft:stone_bricks', '2x opolisinc:villager_receipt_3').villagerExperience(12)

    let colored_stone = Ingredient.of("#opolisinc:colored_stone").itemIds;
    colored_stone.forEach(element => {
        if (element.toString().includes("colors")) { event.addTrade("mason", 3, `16x ${element}`, "2x opolisinc:villager_receipt_3").villagerExperience(4) }
        else { }
    })

    event.addTrade("mason", 4, '8x minecraft:deepslate', '4x opolisinc:villager_receipt_3').villagerExperience(35)
    event.addTrade("mason", 4, '8x minecraft:tuff', '8x opolisinc:villager_receipt_3').villagerExperience(35)

    event.addTrade("mason", 5, '15x opolisinc:basic_trading_bucks', '1x opolisinc:nether_passport_fragment_3').villagerExperience(35)

    //Shepard (Loom)

    let colored_wool = Ingredient.of("#minecraft:wool").itemIds;
    colored_wool.forEach(element => {
        let noNameSpace = element.toString().replace(":", "_")
        if (element.toString().includes("farmersdelight")) {
        } else {
            event.addTrade("shepherd", 1, `6x ${element}`, '1x opolisinc:villager_receipt_3').villagerExperience(4)
            event.addTrade("shepherd", 2, `12x ${element}`, '1x opolisinc:villager_receipt_3').villagerExperience(12)
            event.addTrade("shepherd", 3, `18x ${element}`, '1x opolisinc:villager_receipt_3').villagerExperience(21)
            event.addTrade("shepherd", 4, `24x ${element}`, '1x opolisinc:villager_receipt_3').villagerExperience(35)
        }
    })

    event.addTrade("shepherd", 5, '15x opolisinc:basic_trading_bucks', '1x opolisinc:nether_passport_fragment_3').villagerExperience(35)

    //Carpenter (Sawmill)
    event.removeTrades({ professions: "sawmill:carpenter" })

    let logs = Ingredient.of("#minecraft:logs").itemIds;
    let planks = Ingredient.of("#minecraft:planks").itemIds;
    logs.forEach(element => {
        if (element.toString().includes("minecraft") || element.toString().includes("colors")) {
            event.addTrade("sawmill:carpenter", 1, `6x ${element}`, '1x opolisinc:villager_receipt_3').villagerExperience(4)
            event.addTrade("sawmill:carpenter", 2, `12x ${element}`, '1x opolisinc:villager_receipt_3').villagerExperience(12)
            event.addTrade("sawmill:carpenter", 3, `18x ${element}`, '1x opolisinc:villager_receipt_3').villagerExperience(21)
            event.addTrade("sawmill:carpenter", 4, `24x ${element}`, '1x opolisinc:villager_receipt_3').villagerExperience(35)
        } else {
        }
    })
    planks.forEach(element => {
        if (element.toString().includes("minecraft") || element.toString().includes("colors")) {
            event.addTrade("sawmill:carpenter", 1, `6x ${element}`, '1x opolisinc:villager_receipt_3').villagerExperience(4)
            event.addTrade("sawmill:carpenter", 2, `12x ${element}`, '1x opolisinc:villager_receipt_3').villagerExperience(12)
            event.addTrade("sawmill:carpenter", 3, `18x ${element}`, '1x opolisinc:villager_receipt_3').villagerExperience(21)
            event.addTrade("sawmill:carpenter", 4, `24x ${element}`, '1x opolisinc:villager_receipt_3').villagerExperience(35)
        } else {
        }
    })

    event.addTrade("sawmill:carpenter", 5, '15x opolisinc:basic_trading_bucks', '1x opolisinc:nether_passport_fragment_3').villagerExperience(35)


    //Toolsmith (Smithing Table)

    let tools = Ingredient.of("#c:tools").itemIds;
    tools.forEach(element => {
        let noNameSpace = element.toString().replace(":", "_")

        if (element.toString().includes("glowstone" || "mysticalagriculture")) {
        } else if (element.toString().includes("stone")) {
            event.addTrade("toolsmith", 1, `1x ${element}`, '1x opolisinc:villager_receipt_4').villagerExperience(4)
        }
    })

    tools.forEach(element => {
        let noNameSpace = element.toString().replace(":", "_")
        if (element.toString().includes("iron")) {
            event.addTrade("toolsmith", 2, `1x ${element}`, '1x opolisinc:villager_receipt_4').villagerExperience(12)
        } else {
        }
    })

    tools.forEach(element => {
        let noNameSpace = element.toString().replace(":", "_")
        if (element.toString().includes("gold")) {
            event.addTrade("toolsmith", 3, `1x ${element}`, '1x opolisinc:villager_receipt_4').villagerExperience(21)
        } else {
        }
    })


    tools.forEach(element => {
        let noNameSpace = element.toString().replace(":", "_")
        if (element.toString().includes("diamond")) {
            event.addTrade("toolsmith", 4, `1x ${element}`, '1x opolisinc:villager_receipt_4').villagerExperience(35)
        } else {
        }
    })

    event.addTrade("toolsmith", 5, '15x opolisinc:basic_trading_bucks', '1x opolisinc:nether_passport_fragment_4').villagerExperience(35)


    //Librarian (Lectern)

    event.addTrade("librarian", 1, '3x minecraft:book', '1x opolisinc:villager_receipt_4').villagerExperience(4)
    event.addTrade("librarian", 1, '8x minecraft:paper', '1x opolisinc:villager_receipt_4').villagerExperience(4)

    event.addTrade("librarian", 2, '1x minecraft:bookshelf', '2x opolisinc:villager_receipt_4').villagerExperience(12)
    event.addTrade("librarian", 2, '1x minecraft:enchanting_table', '2x opolisinc:villager_receipt_4').villagerExperience(12)

    event.addTrade("librarian", 3, '4x minecraft:ink_sac', '2x opolisinc:villager_receipt_4').villagerExperience(21)
    event.addTrade("librarian", 3, '1x minecraft:writable_book', '5x opolisinc:villager_receipt_4').villagerExperience(21)

    event.addTrade("librarian", 4, '1x minecraft:written_book', '4x opolisinc:villager_receipt_4').villagerExperience(35)
    event.addTrade("librarian", 4, '1x minecraft:bell', '8x opolisinc:villager_receipt_4').villagerExperience(35)

    event.addTrade("librarian", 5, '15x opolisinc:basic_trading_bucks', '1x opolisinc:nether_passport_fragment_4').villagerExperience(35)

    //Weaponsmith (Grindstone)

    event.addTrade("weaponsmith", 1, "10x minecraft:cobblestone", '1x opolisinc:villager_receipt_4').villagerExperience(5)
    event.addTrade("weaponsmith", 1, "10x minecraft:lapis_lazuli", '1x opolisinc:villager_receipt_4').villagerExperience(5)

    event.addTrade("weaponsmith", 2, "10x alltheores:bronze_ingot", '3x opolisinc:villager_receipt_4').villagerExperience(13)
    event.addTrade("weaponsmith", 2, "10x ae2:certus_quartz_crystal", '3x opolisinc:villager_receipt_4').villagerExperience(13)
    event.addTrade("weaponsmith", 2, "10x ae2:fluix_crystal", '3x opolisinc:villager_receipt_4').villagerExperience(13)


    event.addTrade("weaponsmith", 3, "10x minecraft:iron_ingot", '1x opolisinc:villager_receipt_4').villagerExperience(22)
    event.addTrade("weaponsmith", 3, "10x alltheores:steel_ingot", '5x opolisinc:villager_receipt_4').villagerExperience(22)
    event.addTrade("weaponsmith", 3, "10x minecraft:gold_ingot", '4x opolisinc:villager_receipt_4').villagerExperience(22)

    event.addTrade("weaponsmith", 4, "10x alltheores:osmium_ingot", '2x opolisinc:villager_receipt_4').villagerExperience(22)
    event.addTrade("weaponsmith", 4, "3x minecraft:diamond", '4x opolisinc:villager_receipt_4').villagerExperience(22)

    event.addTrade("weaponsmith", 5, '15x opolisinc:basic_trading_bucks', '1x opolisinc:nether_passport_fragment_4').villagerExperience(35)


    //Cleric (Brewing Stand)

    event.addTrade("cleric", 1, '3x minecraft:rotten_flesh', '1x opolisinc:villager_receipt_5').villagerExperience(4)
    event.addTrade("cleric", 1, '3x minecraft:bone', '1x opolisinc:villager_receipt_5').villagerExperience(4)

    event.addTrade("cleric", 2, '3x minecraft:spider_eye', '2x opolisinc:villager_receipt_5').villagerExperience(12)
    event.addTrade("cleric", 2, '3x minecraft:redstone', '2x opolisinc:villager_receipt_5').villagerExperience(12)

    event.addTrade("cleric", 3, '3x minecraft:glass_bottle', '3x opolisinc:villager_receipt_5').villagerExperience(21)
    event.addTrade("cleric", 3, '3x minecraft:gold_ingot', '5x opolisinc:villager_receipt_5').villagerExperience(21)

    event.addTrade("cleric", 4, '1x minecraft:rabbit_foot', '4x opolisinc:villager_receipt_5').villagerExperience(35)
    event.addTrade("cleric", 4, '10x opolisutilities:ender_pearl_fragment', '8x opolisinc:villager_receipt_5').villagerExperience(35)

    event.addTrade("cleric", 5, '15x opolisinc:basic_trading_bucks', '1x opolisinc:nether_passport_fragment_5').villagerExperience(35)

    //Leatherworker (Cauldron)

    event.addTrade("leatherworker", 1, '3x minecraft:leather', '1x opolisinc:villager_receipt_5').villagerExperience(4)
    event.addTrade("leatherworker", 1, '3x minecraft:rabbit_hide', '3x opolisinc:villager_receipt_5').villagerExperience(4)

    event.addTrade("leatherworker", 2, '1x minecraft:leather_boots', '3x opolisinc:villager_receipt_5').villagerExperience(12)
    event.addTrade("leatherworker", 2, '1x minecraft:leather_helmet', '5x opolisinc:villager_receipt_5').villagerExperience(12)

    event.addTrade("leatherworker", 3, '1x minecraft:leather_chestplate', '2x opolisinc:villager_receipt_5').villagerExperience(21)
    event.addTrade("leatherworker", 3, '1x minecraft:leather_leggings', '2x opolisinc:villager_receipt_5').villagerExperience(21)

    event.addTrade("leatherworker", 4, '1x minecraft:saddle', '4x opolisinc:villager_receipt_5').villagerExperience(35)
    event.addTrade("leatherworker", 4, '3x minecraft:lead', '8x opolisinc:villager_receipt_5').villagerExperience(35)

    event.addTrade("leatherworker", 5, '15x opolisinc:basic_trading_bucks', '1x opolisinc:nether_passport_fragment_5').villagerExperience(35)


    //Fluix Researcher (Charger)

    event.addTrade("ae2:fluix_researcher", 1, "4x ae2:certus_quartz_crystal", '1x opolisinc:villager_receipt_5').villagerExperience(4)
    event.addTrade("ae2:fluix_researcher", 1, "4x ae2:fluix_crystal", '5x opolisinc:villager_receipt_5').villagerExperience(4)

    event.addTrade("ae2:fluix_researcher", 2, "2x ae2:fluix_dust", '2x opolisinc:villager_receipt_5').villagerExperience(12)
    event.addTrade("ae2:fluix_researcher", 2, "4x ae2:charged_certus_quartz_crystal", '2x opolisinc:villager_receipt_5').villagerExperience(12)

    event.addTrade("ae2:fluix_researcher", 3, '12x ae2:cable_anchor', '3x opolisinc:villager_receipt_5').villagerExperience(21)
    event.addTrade("ae2:fluix_researcher", 3, '6x ae2:certus_quartz_dust', '5x opolisinc:villager_receipt_5').villagerExperience(21)

    event.addTrade("ae2:fluix_researcher", 4, "4x ae2:fluix_block", '4x opolisinc:villager_receipt_5').villagerExperience(35)
    event.addTrade("ae2:fluix_researcher", 4, "4x ae2:fluix_smart_dense_cable", '8x opolisinc:villager_receipt_5').villagerExperience(35)

    event.addTrade("ae2:fluix_researcher", 5, '15x opolisinc:basic_trading_bucks', '1x opolisinc:nether_passport_fragment_5').villagerExperience(35)
})