console.info('Loading market.js for Opolis Inc')

ServerEvents.recipes(event => {

    //Starting License

    event.recipes.market.market("#opolisinc:starting_license", "8x minecraft:short_grass", 4, "1x opolisutilities:b_bucks").id("opolisinc:market/starting/short_grass")
    event.recipes.market.market("#opolisinc:starting_license", "12x #minecraft:leaves", 6, "1x opolisutilities:b_bucks").id("opolisinc:market/starting/leaves")
    event.recipes.market.market("#opolisinc:starting_license", "8x #c:cobblestones", 4, "1x opolisutilities:b_bucks").id("opolisinc:market/starting/cobblestone")
    event.recipes.market.market("#opolisinc:starting_license", "8x minecraft:dirt", 4, "1x opolisutilities:b_bucks").id("opolisinc:market/starting/dirt")


    //Mining Licenses

    event.recipes.market.market("#opolisinc:basic_mining_license", "8x #minecraft:dirt", 3, "1x opolisinc:basic_mining_bucks").id("opolisinc:market/mining/basic/dirt")
    event.recipes.market.market(SL("dirt"), "16x #minecraft:dirt", 6, "1x opolisinc:basic_mining_bucks").id("opolisinc:market/mining/basic/specialised/dirt")
    event.recipes.market.market("#opolisinc:basic_mining_license", "8x #c:cobblestones", 2, "1x opolisinc:basic_mining_bucks").id("opolisinc:market/mining/basic/cobblestone")
    event.recipes.market.market(SL("cobblestone"), "16x #c:cobblestones", 4, "1x opolisinc:basic_mining_bucks").id("opolisinc:market/mining/basic/specialised/cobblestone")
    event.recipes.market.market("#opolisinc:basic_mining_license", "6x #minecraft:sand", 2, "1x opolisinc:basic_mining_bucks").id("opolisinc:market/mining/basic/sand")
    event.recipes.market.market(SL("sand"), "12x #minecraft:sand", 4, "1x opolisinc:basic_mining_bucks").id("opolisinc:market/mining/basic/specialised/sand")

    event.recipes.market.market("#opolisinc:advanced_mining_license", "3x raw_iron", 1, "1x opolisinc:advanced_mining_bucks").id("opolisinc:market/mining/advanced/raw_iron")
    event.recipes.market.market(SL("raw_iron"), "6x raw_iron", 2, "1x opolisinc:advanced_mining_bucks").id("opolisinc:market/mining/advanced/specialised/raw_iron")
    event.recipes.market.market("#opolisinc:advanced_mining_license", "8x raw_copper", 3, "1x opolisinc:advanced_mining_bucks").id("opolisinc:market/mining/advanced/raw_copper")
    event.recipes.market.market(SL("raw_copper"), "8x raw_copper", 6, "1x opolisinc:advanced_mining_bucks").id("opolisinc:market/mining/advanced/specialised/raw_copper")
    event.recipes.market.market("#opolisinc:advanced_mining_license", "3x #c:raw_materials/tin", 1, "1x opolisinc:advanced_mining_bucks").id("opolisinc:market/mining/advanced/raw_tin")
    event.recipes.market.market(SL("raw_tin"), "6x #c:raw_materials/tin", 2, "1x opolisinc:advanced_mining_bucks").id("opolisinc:market/mining/advanced/specialised/raw_tin")
    event.recipes.market.market("#opolisinc:advanced_mining_license", "2x #c:raw_materials/aluminum", 1, "1x opolisinc:advanced_mining_bucks").id("opolisinc:market/mining/advanced/raw_aluminum")
    event.recipes.market.market(SL("raw_aluminum"), "4x #c:raw_materials/aluminum", 2, "1x opolisinc:advanced_mining_bucks").id("opolisinc:market/mining/advanced/specialised/raw_aluminum")
    event.recipes.market.market("#opolisinc:advanced_mining_license", "10x lapis_lazuli", 3, "2x opolisinc:advanced_mining_bucks").id("opolisinc:market/mining/advanced/lapis_lazuli")
    event.recipes.market.market(SL("lapis_lazuli"), "20x lapis_lazuli", 6, "2x opolisinc:advanced_mining_bucks").id("opolisinc:market/mining/advanced/specialised/lapis_lazuli")
    event.recipes.market.market("#opolisinc:advanced_mining_license", "3x alltheores:cinnabar", 1, "1x opolisinc:advanced_mining_bucks").id("opolisinc:market/mining/advanced/cinnabar")
    event.recipes.market.market(SL("cinnabar"), "6x alltheores:cinnabar", 2, "1x opolisinc:advanced_mining_bucks").id("opolisinc:market/mining/advanced/specialised/cinnabar")

    event.recipes.market.market("#opolisinc:elite_mining_license", "6x quartz", 2, "1x opolisinc:elite_mining_bucks").id("opolisinc:market/mining/elite/quartz")
    event.recipes.market.market(SL("quartz"), "12x quartz", 4, "1x opolisinc:elite_mining_bucks").id("opolisinc:market/mining/elite/specialised/quartz")
    event.recipes.market.market("#opolisinc:elite_mining_license", "3x diamond", 1, "1x opolisinc:elite_mining_bucks").id("opolisinc:market/mining/elite/diamond")
    event.recipes.market.market(SL("diamond"), "6x diamond", 2, "1x opolisinc:elite_mining_bucks").id("opolisinc:market/mining/elite/specialised/diamond")
    event.recipes.market.market("#opolisinc:elite_mining_license", "3x alltheores:raw_platinum", 1, "1x opolisinc:elite_mining_bucks").id("opolisinc:market/mining/elite/raw_platinum")
    event.recipes.market.market(SL("raw_platinum"), "6x alltheores:raw_platinum", 2, "1x opolisinc:elite_mining_bucks").id("opolisinc:market/mining/elite/specialised/raw_platinum")
    event.recipes.market.market("#opolisinc:elite_mining_license", "3x emerald", 1, "1x opolisinc:elite_mining_bucks").id("opolisinc:market/mining/elite/emerald")
    event.recipes.market.market(SL("emerald"), "6x emerald", 2, "1x opolisinc:elite_mining_bucks").id("opolisinc:market/mining/elite/specialised/emerald")
    event.recipes.market.market("#opolisinc:elite_mining_license", "1x ancient_debris", 0, "1x opolisinc:elite_mining_bucks").id("opolisinc:market/mining/elite/ancient_debris")
    event.recipes.market.market(SL("ancient_debris"), "2x ancient_debris", 1, "1x opolisinc:elite_mining_bucks").id("opolisinc:market/mining/elite/specialised/ancient_debris")

    event.recipes.market.market("#opolisinc:ultimate_mining_license", "4x opolisinc:activated_raw_gold", 2, "1x opolisinc:ultimate_mining_bucks").id("opolisinc:market/mining/ultimate/activated_raw_gold")
    event.recipes.market.market(SL("activated_raw_gold"), "8x opolisinc:activated_raw_gold", 4, "1x opolisinc:ultimate_mining_bucks").id("opolisinc:market/mining/ultimate/specialised/activated_raw_gold")
    event.recipes.market.market("#opolisinc:ultimate_mining_license", "4x opolisinc:activated_raw_lead", 2, "1x opolisinc:ultimate_mining_bucks").id("opolisinc:market/mining/ultimate/activated_raw_lead")
    event.recipes.market.market(SL("activated_raw_lead"), "8x opolisinc:activated_raw_lead", 4, "1x opolisinc:ultimate_mining_bucks").id("opolisinc:market/mining/ultimate/specialised/activated_raw_lead")
    event.recipes.market.market("#opolisinc:ultimate_mining_license", "4x opolisinc:activated_raw_nickel", 2, "1x opolisinc:ultimate_mining_bucks").id("opolisinc:market/mining/ultimate/activated_raw_nickel")
    event.recipes.market.market(SL("activated_raw_nickel"), "8x opolisinc:activated_raw_nickel", 4, "1x opolisinc:ultimate_mining_bucks").id("opolisinc:market/mining/ultimate/specialised/activated_raw_nickel")
    event.recipes.market.market("#opolisinc:ultimate_mining_license", "4x opolisinc:activated_raw_osmium", 2, "1x opolisinc:ultimate_mining_bucks").id("opolisinc:market/mining/ultimate/activated_raw_osmium")
    event.recipes.market.market(SL("activated_raw_osmium"), "8x opolisinc:activated_raw_osmium", 4, "1x opolisinc:ultimate_mining_bucks").id("opolisinc:market/mining/ultimate/specialised/activated_raw_osmium")
    event.recipes.market.market("#opolisinc:ultimate_mining_license", "4x opolisinc:activated_raw_silver", 2, "1x opolisinc:ultimate_mining_bucks").id("opolisinc:market/mining/ultimate/activated_raw_silver")
    event.recipes.market.market(SL("activated_raw_silver"), "8x opolisinc:activated_raw_silver", 4, "1x opolisinc:ultimate_mining_bucks").id("opolisinc:market/mining/ultimate/specialised/activated_raw_silver")
    event.recipes.market.market("#opolisinc:ultimate_mining_license", "4x opolisinc:activated_raw_uranium", 2, "1x opolisinc:ultimate_mining_bucks").id("opolisinc:market/mining/ultimate/activated_raw_uranium")
    event.recipes.market.market(SL("activated_raw_uranium"), "8x opolisinc:activated_raw_uranium", 4, "1x opolisinc:ultimate_mining_bucks").id("opolisinc:market/mining/ultimate/specialised/activated_raw_uranium")
    event.recipes.market.market("#opolisinc:ultimate_mining_license", "4x opolisinc:activated_raw_zinc", 2, "1x opolisinc:ultimate_mining_bucks").id("opolisinc:market/mining/ultimate/activated_raw_zinc")
    event.recipes.market.market(SL("activated_raw_zinc"), "8x opolisinc:activated_raw_zinc", 4, "1x opolisinc:ultimate_mining_bucks").id("opolisinc:market/mining/ultimate/specialised/activated_raw_zinc")

    event.recipes.market.market("opolisinc:drill_license", "8x opolisinc:ultimate_mining_bucks", 0, "opolisinc:plasma_tipped_drill_bit").id("opolisinc:market/misc/plasma_tipped_drill_bit")

    //Farming Licenses

    event.recipes.market.market("#opolisinc:basic_farming_license", "3x #opolisinc:wheat", 1, "1x opolisinc:basic_farming_bucks").id("opolisinc:market/farming/basic/wheat")
    event.recipes.market.market(SL("wheat"), "6x #opolisinc:wheat", 2, "1x opolisinc:basic_farming_bucks").id("opolisinc:market/farming/basic/specialised/wheat")
    event.recipes.market.market("#opolisinc:basic_farming_license", "3x #opolisinc:carrot", 1, "1x opolisinc:basic_farming_bucks").id("opolisinc:market/farming/basic/carrot")
    event.recipes.market.market(SL("carrot"), "6x #opolisinc:carrot", 2, "1x opolisinc:basic_farming_bucks").id("opolisinc:market/farming/basic/specialised/carrot")
    event.recipes.market.market("#opolisinc:basic_farming_license", "3x #opolisinc:potato", 1, "1x opolisinc:basic_farming_bucks").id("opolisinc:market/farming/basic/potato")
    event.recipes.market.market(SL("potato"), "6x #opolisinc:potato", 2, "1x opolisinc:basic_farming_bucks").id("opolisinc:market/farming/basic/specialised/potato")
    event.recipes.market.market("#opolisinc:basic_farming_license", "3x #opolisinc:beetroot", 1, "1x opolisinc:basic_farming_bucks").id("opolisinc:market/farming/basic/beetroot")
    event.recipes.market.market(SL("beetroot"), "6x #opolisinc:beetroot", 2, "1x opolisinc:basic_farming_bucks").id("opolisinc:market/farming/basic/specialised/beetroot")

    event.recipes.market.market("#opolisinc:advanced_farming_license", "3x #opolisinc:sculked_wheat", 1, "1x opolisinc:advanced_farming_bucks").id("opolisinc:market/farming/advanced/sculked_wheat")
    event.recipes.market.market(SL("sculked_wheat"), "6x #opolisinc:sculked_wheat", 2, "1x opolisinc:advanced_farming_bucks").id("opolisinc:market/farming/advanced/specialised/sculked_wheat")
    event.recipes.market.market("#opolisinc:advanced_farming_license", "3x #opolisinc:sculked_carrot", 1, "1x opolisinc:advanced_farming_bucks").id("opolisinc:market/farming/advanced/sculked_carrot")
    event.recipes.market.market(SL("sculked_carrot"), "6x #opolisinc:sculked_carrot", 2, "1x opolisinc:advanced_farming_bucks").id("opolisinc:market/farming/advanced/specialised/sculked_carrot")
    event.recipes.market.market("#opolisinc:advanced_farming_license", "3x #opolisinc:sculked_potato", 1, "1x opolisinc:advanced_farming_bucks").id("opolisinc:market/farming/advanced/sculked_potato")
    event.recipes.market.market(SL("sculked_potato"), "6x #opolisinc:sculked_potato", 2, "1x opolisinc:advanced_farming_bucks").id("opolisinc:market/farming/advanced/specialised/sculked_potato")
    event.recipes.market.market("#opolisinc:advanced_farming_license", "3x #opolisinc:sculked_beetroot", 1, "1x opolisinc:advanced_farming_bucks").id("opolisinc:market/farming/advanced/sculked_beetroot")
    event.recipes.market.market(SL("sculked_beetroot"), "6x #opolisinc:sculked_beetroot", 2, "1x opolisinc:advanced_farming_bucks").id("opolisinc:market/farming/advanced/specialised/sculked_beetroot")

    event.recipes.market.market("#opolisinc:elite_farming_license", "6x #opolisinc:twisting_vines", 2, "1x opolisinc:elite_farming_bucks").id("opolisinc:market/farming/elite/twisting_vines")
    event.recipes.market.market(SL("twisting_vines"), "12x #opolisinc:twisting_vines", 4, "1x opolisinc:elite_farming_bucks").id("opolisinc:market/farming/elite/specialised/twisting_vines")
    event.recipes.market.market("#opolisinc:elite_farming_license", "6x #opolisinc:weeping_vines", 2, "1x opolisinc:elite_farming_bucks").id("opolisinc:market/farming/elite/weeping_vines")
    event.recipes.market.market(SL("weeping_vines"), "12x #opolisinc:weeping_vines", 4, "1x opolisinc:elite_farming_bucks").id("opolisinc:market/farming/elite/specialised/weeping_vines")

    event.recipes.market.market("#opolisinc:ultimate_farming_license", "4x #opolisinc:phased_wheat", 1, "1x opolisinc:ultimate_farming_bucks").id("opolisinc:market/farming/ultimate/phased_wheat")
    event.recipes.market.market(SL("phased_wheat"), "8x #opolisinc:phased_wheat", 2, "1x opolisinc:ultimate_farming_bucks").id("opolisinc:market/farming/ultimate/specialised/phased_wheat")
    event.recipes.market.market("#opolisinc:ultimate_farming_license", "4x #opolisinc:phased_carrot", 1, "1x opolisinc:ultimate_farming_bucks").id("opolisinc:market/farming/ultimate/phased_carrot")
    event.recipes.market.market(SL("phased_carrot"), "8x #opolisinc:phased_carrot", 2, "1x opolisinc:ultimate_farming_bucks").id("opolisinc:market/farming/ultimate/specialised/phased_carrot")
    event.recipes.market.market("#opolisinc:ultimate_farming_license", "4x #opolisinc:phased_potato", 1, "1x opolisinc:ultimate_farming_bucks").id("opolisinc:market/farming/ultimate/phased_potato")
    event.recipes.market.market(SL("phased_potato"), "8x #opolisinc:phased_potato", 2, "1x opolisinc:ultimate_farming_bucks").id("opolisinc:market/farming/ultimate/specialised/phased_potato")
    event.recipes.market.market("#opolisinc:ultimate_farming_license", "4x #opolisinc:phased_beetroot", 1, "1x opolisinc:ultimate_farming_bucks").id("opolisinc:market/farming/ultimate/phased_beetroot")
    event.recipes.market.market(SL("phased_beetroot"), "8x #opolisinc:phased_beetroot", 2, "1x opolisinc:ultimate_farming_bucks").id("opolisinc:market/farming/ultimate/specialised/phased_beetroot")


    //Bounty Licenses

    event.recipes.market.market("#opolisinc:basic_bounty_license", "2x minecraft:feather", 1, "1x opolisinc:basic_bounty_bucks").id("opolisinc:market/bounty/basic/feather")
    event.recipes.market.market(SL("feather"), "4x minecraft:feather", 2, "1x opolisinc:basic_bounty_bucks").id("opolisinc:market/bounty/basic/specialised/feather")
    event.recipes.market.market("#opolisinc:basic_bounty_license", "2x minecraft:leather", 1, "1x opolisinc:basic_bounty_bucks").id("opolisinc:market/bounty/basic/leather")
    event.recipes.market.market(SL("leather"), "4x minecraft:leather", 2, "1x opolisinc:basic_bounty_bucks").id("opolisinc:market/bounty/basic/specialised/leather")
    event.recipes.market.market("#opolisinc:basic_bounty_license", "2x minecraft:beef", 1, "1x opolisinc:basic_bounty_bucks").id("opolisinc:market/bounty/basic/beef")
    event.recipes.market.market(SL("beef"), "4x minecraft:beef", 2, "1x opolisinc:basic_bounty_bucks").id("opolisinc:market/bounty/basic/specialised/beef")
    event.recipes.market.market("#opolisinc:basic_bounty_license", "2x minecraft:porkchop", 1, "2x opolisinc:basic_bounty_bucks").id("opolisinc:market/bounty/basic/porkchop")
    event.recipes.market.market(SL("porkchop"), "4x minecraft:porkchop", 2, "1x opolisinc:basic_bounty_bucks").id("opolisinc:market/bounty/basic/specialised/porkchop")
    event.recipes.market.market("#opolisinc:basic_bounty_license", "2x minecraft:ink_sac", 1, "1x opolisinc:basic_bounty_bucks").id("opolisinc:market/bounty/basic/ink_sac")
    event.recipes.market.market(SL("ink_sac"), "4x minecraft:ink_sac", 2, "1x opolisinc:basic_bounty_bucks").id("opolisinc:market/bounty/basic/specialised/ink_sac")
    event.recipes.market.market("#opolisinc:basic_bounty_license", "2x minecraft:chicken", 1, "1x opolisinc:basic_bounty_bucks").id("opolisinc:market/bounty/basic/chicken")
    event.recipes.market.market(SL("chicken"), "4x minecraft:chicken", 2, "1x opolisinc:basic_bounty_bucks").id("opolisinc:market/bounty/basic/specialised/chicken")
    event.recipes.market.market("#opolisinc:basic_bounty_license", "2x minecraft:mutton", 1, "1x opolisinc:basic_bounty_bucks").id("opolisinc:market/bounty/basic/mutton")
    event.recipes.market.market(SL("mutton"), "4x minecraft:mutton", 2, "1x opolisinc:basic_bounty_bucks").id("opolisinc:market/bounty/basic/specialised/mutton")

    event.recipes.market.market("#opolisinc:advanced_bounty_license", "4x minecraft:rotten_flesh", 3, "1x opolisinc:advanced_bounty_bucks").id("opolisinc:market/bounty/advanced/rotten_flesh")
    event.recipes.market.market(SL("rotten_flesh"), "8x minecraft:rotten_flesh", 6, "1x opolisinc:advanced_bounty_bucks").id("opolisinc:market/bounty/advanced/specialised/rotten_flesh")
    event.recipes.market.market("#opolisinc:advanced_bounty_license", "4x minecraft:bone", 2, "1x opolisinc:advanced_bounty_bucks").id("opolisinc:market/bounty/advanced/bone")
    event.recipes.market.market(SL("bone"), "8x minecraft:bone", 4, "1x opolisinc:advanced_bounty_bucks").id("opolisinc:market/bounty/advanced/specialised/bone")
    event.recipes.market.market("#opolisinc:advanced_bounty_license", "4x minecraft:arrow", 1, "1x opolisinc:advanced_bounty_bucks").id("opolisinc:market/bounty/advanced/arrow")
    event.recipes.market.market(SL("arrow"), "8x minecraft:arrow", 2, "1x opolisinc:advanced_bounty_bucks").id("opolisinc:market/bounty/advanced/specialised/arrow")
    event.recipes.market.market("#opolisinc:advanced_bounty_license", "2x minecraft:spider_eye", 1, "1x opolisinc:advanced_bounty_bucks").id("opolisinc:market/bounty/advanced/spider_eye")
    event.recipes.market.market(SL("spider_eye"), "4x minecraft:spider_eye", 2, "1x opolisinc:advanced_bounty_bucks").id("opolisinc:market/bounty/advanced/specialised/spider_eye")
    event.recipes.market.market("#opolisinc:advanced_bounty_license", "2x minecraft:gunpowder", 1, "1x opolisinc:advanced_bounty_bucks").id("opolisinc:market/bounty/advanced/gunpowder")
    event.recipes.market.market(SL("gunpowder"), "4x minecraft:gunpowder", 3, "1x opolisinc:advanced_bounty_bucks").id("opolisinc:market/bounty/advanced/specialised/gunpowder")
    event.recipes.market.market("#opolisinc:advanced_bounty_license", "1x minecraft:ender_pearl", 0, "1x opolisinc:advanced_bounty_bucks").id("opolisinc:market/bounty/advanced/ender_pearl")
    event.recipes.market.market(SL("ender_pearl"), "2x minecraft:ender_pearl", 1, "1x opolisinc:advanced_bounty_bucks").id("opolisinc:market/bounty/advanced/specialised/ender_pearl")
    event.recipes.market.market("#opolisinc:advanced_bounty_license", "1x minecraft:breeze_rod", 0, "1x opolisinc:advanced_bounty_bucks").id("opolisinc:market/bounty/advanced/breeze_rod")
    event.recipes.market.market(SL("breeze_rod"), "2x minecraft:breeze_rod", 1, "1x opolisinc:advanced_bounty_bucks").id("opolisinc:market/bounty/advanced/specialised/breeze_rod")

    event.recipes.market.market("#opolisinc:elite_bounty_license", "2x blaze_rod", 1, "1x opolisinc:elite_bounty_bucks").id("opolisinc:market/bounty/elite/blaze_rod")
    event.recipes.market.market(SL("blaze_rod"), "4x blaze_rod", 2, "1x opolisinc:elite_bounty_bucks").id("opolisinc:market/bounty/elite/specialised/blaze_rod")
    event.recipes.market.market("#opolisinc:elite_bounty_license", "2x ghast_tear", 1, "1x opolisinc:elite_bounty_bucks").id("opolisinc:market/bounty/elite/ghast_tear")
    event.recipes.market.market(SL("ghast_tear"), "4x ghast_tear", 2, "1x opolisinc:elite_bounty_bucks").id("opolisinc:market/bounty/elite/specialised/ghast_teat")
    event.recipes.market.market("#opolisinc:elite_bounty_license", "3x opolisinc:withered_bone", 1, "1x opolisinc:elite_bounty_bucks").id("opolisinc:market/bounty/elite/withered_bone")
    event.recipes.market.market(SL("withered_bone"), "6x opolisinc:withered_bone", 2, "1x opolisinc:elite_bounty_bucks").id("opolisinc:market/bounty/elite/specialised/withered_bone")

    event.recipes.market.market("#opolisinc:ultimate_bounty_license", "2x shulker_shell", 1, "3x opolisinc:ultimate_bounty_bucks").id("opolisinc:market/bounty/ultimate/shulker_shell")
    event.recipes.market.market(SL("shulker_shell"), "4x shulker_shell", 2, "3x opolisinc:ultimate_bounty_bucks").id("opolisinc:market/bounty/ultimate/specialised/shulker_shell")
    event.recipes.market.market("#opolisinc:ultimate_bounty_license", "4x opolisinc:activated_ender_pearl", 2, "3x opolisinc:ultimate_bounty_bucks").id("opolisinc:market/bounty/ultimate/activated_ender_pearl")
    event.recipes.market.market(SL("activated_ender_pearl"), "8x opolisinc:activated_ender_pearl", 4, "3x opolisinc:ultimate_bounty_bucks").id("opolisinc:market/bounty/ultimate/specialised/activated_ender_pearl")

    event.recipes.market.market("nether_star", "32x opolisinc:ultimate_bounty_bucks", 0, "nether_star").id("opolisinc:market/misc/nether_star")


    //Processing Licenses

    event.recipes.market.market("#opolisinc:basic_processing_license", "12x minecraft:copper_ingot", 2, "1x opolisinc:basic_processing_bucks").id("opolisinc:market/processing/basic/copper_ingot")
    event.recipes.market.market(SL("copper"), "24x minecraft:copper_ingot", 4, "1x opolisinc:basic_processing_bucks").id("opolisinc:market/processing/basic/specialised/copper_ingot")
    event.recipes.market.market("#opolisinc:basic_processing_license", "3x minecraft:iron_ingot", 1, "1x opolisinc:basic_processing_bucks").id("opolisinc:market/processing/basic/iron_ingot")
    event.recipes.market.market(SL("iron"), "6x minecraft:iron_ingot", 2, "1x opolisinc:basic_processing_bucks").id("opolisinc:market/processing/basic/specialised/iron_ingot")
    event.recipes.market.market("#opolisinc:basic_processing_license", "3x alltheores:aluminum_ingot", 1, "1x opolisinc:basic_processing_bucks").id("opolisinc:market/processing/basic/aluminum_ingot")
    event.recipes.market.market(SL("aluminum"), "6x alltheores:aluminum_ingot", 2, "1x opolisinc:basic_processing_bucks").id("opolisinc:market/processing/basic/specialised/aluminum_ingot")
    event.recipes.market.market("#opolisinc:basic_processing_license", "3x alltheores:tin_ingot", 1, "1x opolisinc:basic_processing_bucks").id("opolisinc:market/processing/basic/tin_ingot")
    event.recipes.market.market(SL("tin"), "6x alltheores:tin_ingot", 2, "1x opolisinc:basic_processing_bucks").id("opolisinc:market/processing/basic/specialised/tin_ingot")
    event.recipes.market.market("#opolisinc:basic_processing_license", "3x alltheores:nickel_ingot", 1, "1x opolisinc:basic_processing_bucks").id("opolisinc:market/processing/basic/nickel_ingot")
    event.recipes.market.market(SL("nickel"), "6x alltheores:nickel_ingot", 2, "1x opolisinc:basic_processing_bucks").id("opolisinc:market/processing/basic/specialised/nickel_ingot")
    event.recipes.market.market("#opolisinc:basic_processing_license", "3x alltheores:lead_ingot", 1, "1x opolisinc:basic_processing_bucks").id("opolisinc:market/processing/basic/lead_ingot")
    event.recipes.market.market(SL("lead"), "6x alltheores:lead_ingot", 2, "1x opolisinc:basic_processing_bucks").id("opolisinc:market/processing/basic/specialised/lead_ingot")
    event.recipes.market.market("#opolisinc:basic_processing_license", "3x alltheores:zinc_ingot", 1, "1x opolisinc:basic_processing_bucks").id("opolisinc:market/processing/basic/zinc_ingot")
    event.recipes.market.market(SL("zinc"), "6x alltheores:zinc_ingot", 2, "1x opolisinc:basic_processing_bucks").id("opolisinc:market/processing/basic/specialised/zinc_ingot")
    event.recipes.market.market("#opolisinc:basic_processing_license", "3x alltheores:silver_ingot", 1, "1x opolisinc:basic_processing_bucks").id("opolisinc:market/processing/basic/silver_ingot")
    event.recipes.market.market(SL("silver"), "6x alltheores:silver_ingot", 2, "1x opolisinc:basic_processing_bucks").id("opolisinc:market/processing/basic/specialised/silver_ingot")
    event.recipes.market.market("#opolisinc:basic_processing_license", "8x minecraft:glass", 2, "1x opolisinc:basic_processing_bucks").id("opolisinc:market/processing/basic/glass")
    event.recipes.market.market(SL("glass"), "16x minecraft:glass", 4, "1x opolisinc:basic_processing_bucks").id("opolisinc:market/processing/basic/specialised/glass")

    event.recipes.market.market("#opolisinc:advanced_processing_license", "3x #c:ingots/steel", 1, "1x opolisinc:advanced_processing_bucks").id("opolisinc:market/processing/advanced/steel_ingot")
    event.recipes.market.market(SL("steel"), "6x #c:ingots/steel", 2, "1x opolisinc:advanced_processing_bucks").id("opolisinc:market/processing/advanced/specialised/steel_ingot")
    event.recipes.market.market("#opolisinc:advanced_processing_license", "4x #c:ingots/bronze", 2, "1x opolisinc:advanced_processing_bucks").id("opolisinc:market/processing/advanced/bronze_ingot")
    event.recipes.market.market(SL("bronze"), "8x #c:ingots/bronze", 2, "1x opolisinc:advanced_processing_bucks").id("opolisinc:market/processing/advanced/specialised/bronze_ingot")
    event.recipes.market.market("#opolisinc:advanced_processing_license", "3x #c:ingots/electrum", 2, "1x opolisinc:advanced_processing_bucks").id("opolisinc:market/processing/advanced/electrum")
    event.recipes.market.market(SL("electrum"), "6x #c:ingots/electrum", 4, "1x opolisinc:advanced_processing_bucks").id("opolisinc:market/processing/advanced/specialised/electrum")
    event.recipes.market.market("#opolisinc:advanced_processing_license", "4x #c:ingots/invar", 2, "1x opolisinc:advanced_processing_bucks").id("opolisinc:market/processing/advanced/invar")
    event.recipes.market.market(SL("invar"), "8x #c:ingots/invar", 4, "1x opolisinc:advanced_processing_bucks").id("opolisinc:market/processing/advanced/specialised/invar")
    event.recipes.market.market("#opolisinc:advanced_processing_license", "4x #c:ingots/constantan", 2, "1x opolisinc:advanced_processing_bucks").id("opolisinc:market/processing/advanced/constantan")
    event.recipes.market.market(SL("constantan"), "8x #c:ingots/constantan", 4, "1x opolisinc:advanced_processing_bucks").id("opolisinc:market/processing/advanced/specialised/constantan")
    event.recipes.market.market("#opolisinc:advanced_processing_license", "4x #c:ingots/brass", 2, "1x opolisinc:advanced_processing_bucks").id("opolisinc:market/processing/advanced/brass")
    event.recipes.market.market(SL("brass"), "8x #c:ingots/brass", 4, "1x opolisinc:advanced_processing_bucks").id("opolisinc:market/processing/advanced/specialised/brass")
    event.recipes.market.market("#opolisinc:advanced_processing_license", "4x mekanism:alloy_infused", 2, "1x opolisinc:advanced_processing_bucks").id("opolisinc:market/processing/advanced/infused_alloy")
    event.recipes.market.market(SL("infused_alloy"), "8x mekanism:alloy_infused", 4, "1x opolisinc:advanced_processing_bucks").id("opolisinc:market/processing/advanced/specialised/infused_alloy")

    event.recipes.market.market("#opolisinc:elite_processing_license", "2x mekanism:alloy_reinforced", 1, "1x opolisinc:elite_processing_bucks").id("opolisinc:market/processing/elite/reinforced_alloy")
    event.recipes.market.market(SL("reinforced_alloy"), "4x mekanism:alloy_reinforced", 2, "1x opolisinc:elite_processing_bucks").id("opolisinc:market/processing/elite/specialised/reinforced_alloy")
    event.recipes.market.market("#opolisinc:elite_processing_license", "3x #c:ingots/enderium", 1, "1x opolisinc:elite_processing_bucks").id("opolisinc:market/processing/elite/enderium_ingot")
    event.recipes.market.market(SL("enderium"), "6x #c:ingots/enderium", 2, "1x opolisinc:elite_processing_bucks").id("opolisinc:market/processing/elite/specialised/enderium_ingot")
    event.recipes.market.market("#opolisinc:elite_processing_license", "3x #c:ingots/lumium", 1, "1x opolisinc:elite_processing_bucks").id("opolisinc:market/processing/elite/lumium_ingot")
    event.recipes.market.market(SL("lumium"), "6x #c:ingots/lumium", 2, "1x opolisinc:elite_processing_bucks").id("opolisinc:market/processing/elite/specialised/lumium_ingot")
    event.recipes.market.market("#opolisinc:elite_processing_license", "3x #c:ingots/signalum", 1, "1x opolisinc:elite_processing_bucks").id("opolisinc:market/processing/elite/signalum_ingot")
    event.recipes.market.market(SL("signalum"), "6x #c:ingots/signalum", 2, "1x opolisinc:elite_processing_bucks").id("opolisinc:market/processing/elite/specialised/signalum_ingot")

    event.recipes.market.market("#opolisinc:ultimate_processing_license", "3x opolisinc:activated_enderium_ingot", 1, "1x opolisinc:ultimate_processing_bucks").id("opolisinc:market/processing/ultimate/activated_enderium_ingot")
    event.recipes.market.market(SL("activated_enderium"), "6x opolisinc:activated_enderium_ingot", 2, "1x opolisinc:ultimate_processing_bucks").id("opolisinc:market/processing/ultimate/specialised/activated_enderium_ingot")
    event.recipes.market.market("#opolisinc:ultimate_processing_license", "3x opolisinc:activated_signalum_ingot", 1, "1x opolisinc:ultimate_processing_bucks").id("opolisinc:market/processing/ultimate/activated_signalum_ingot")
    event.recipes.market.market(SL("activated_signalum"), "6x opolisinc:activated_signalum_ingot", 2, "1x opolisinc:ultimate_processing_bucks").id("opolisinc:market/processing/ultimate/specialised/activated_signalum_ingot")
    event.recipes.market.market("#opolisinc:ultimate_processing_license", "3x opolisinc:activated_lumium_ingot", 1, "1x opolisinc:ultimate_processing_bucks").id("opolisinc:market/processing/ultimate/activated_lumium_ingot")
    event.recipes.market.market(SL("activated_lumium"), "6x opolisinc:activated_lumium_ingot", 2, "1x opolisinc:ultimate_processing_bucks").id("opolisinc:market/processing/ultimate/specialised/activated_lumium_ingot")


    //Power Licenses 

    event.recipes.market.market("#opolisinc:basic_power_license", "4x #minecraft:coals", 2, "1x opolisinc:basic_power_bucks").id("opolisinc:market/power/basic/coal")
    event.recipes.market.market(SL("coal"), "8x #minecraft:coals", 4, "1x opolisinc:basic_power_bucks").id("opolisinc:market/power/basic/specialised/coal")
    event.recipes.market.market("#opolisinc:basic_power_license", "5x minecraft:redstone", 2, "1x opolisinc:basic_power_bucks").id("opolisinc:market/power/basic/redstone")
    event.recipes.market.market(SL("redstone"), "10x minecraft:redstone", 4, "1x opolisinc:basic_power_bucks").id("opolisinc:market/power/basic/specialised/redstone")

    //Advanced in datapacks

    event.recipes.market.market("#opolisinc:elite_power_license", '3x powah:capacitor_blazing', 1, "2x opolisinc:elite_power_bucks").id("opolisinc:market/power/elite/capacitor_blazing")

    event.recipes.market.market("#opolisinc:ultimate_power_license", "2x powah:capacitor_niotic", 1, "1x opolisinc:ultimate_power_bucks").id("opolisinc:market/power/ultimate/capacitor_niotic")
    event.recipes.market.market(SL("niotic_capacitor"), "4x powah:capacitor_niotic", 2, "1x opolisinc:ultimate_power_bucks").id("opolisinc:market/power/ultimate/specialised/capacitor_niotic")
    event.recipes.market.market("#opolisinc:ultimate_power_license", "2x powah:capacitor_spirited", 1, "1x opolisinc:ultimate_power_bucks").id("opolisinc:market/power/ultimate/capacitor_spirited")
    event.recipes.market.market(SL("spirited_capacitor"), "4x powah:capacitor_spirited", 2, "1x opolisinc:ultimate_power_bucks").id("opolisinc:market/power/ultimate/specialised/capacitor_spirited")

    event.recipes.market.market("opolisinc:nuclear_license", "8x opolisinc:ultimate_power_bucks", 0, "mekanism:reprocessed_fissile_fragment").id("opolisinc:market/misc/reprocessed_fissile_fragment")


    //Storage Licenses

    event.recipes.market.market("#opolisinc:basic_storage_license", "3x #c:chests/wooden", 1, "3x opolisinc:basic_storage_bucks").id("opolisinc:market/storage/basic/chest")
    event.recipes.market.market(SL("chest"), "6x #c:chests/wooden", 2, "3x opolisinc:basic_storage_bucks").id("opolisinc:market/storage/basic/specialised/chest")
    event.recipes.market.market("#opolisinc:basic_storage_license", "12x #minecraft:logs", 4, "4x opolisinc:basic_storage_bucks").id("opolisinc:market/storage/basic/logs")
    event.recipes.market.market(SL("wood"), "24x #minecraft:logs", 8, "4x opolisinc:basic_storage_bucks").id("opolisinc:market/storage/basic/specialised/logs")

    event.recipes.market.market("#opolisinc:advanced_storage_license", "2x ae2:cell_component_1k", 1, "5x opolisinc:advanced_storage_bucks").id("opolisinc:market/storage/advanced/cell_component_1k")

    event.recipes.market.market("#opolisinc:elite_storage_license", "2x ae2:cell_component_16k", 1, "8x opolisinc:elite_storage_bucks").id("opolisinc:market/storage/elite/cell_component_16k")
    event.recipes.market.market(SL("cell_component_16k"), "4x ae2:cell_component_16k", 2, "8x opolisinc:elite_storage_bucks").id("opolisinc:market/storage/elite/specialised/cell_component_16k")
    event.recipes.market.market("#opolisinc:elite_storage_license", "6x extendedae:entro_ingot", 1, "3x opolisinc:elite_storage_bucks").id("opolisinc:market/storage/elite/entro_ingot")
    event.recipes.market.market(SL("entro_ingot"), "12x extendedae:entro_ingot", 2, "3x opolisinc:elite_storage_bucks").id("opolisinc:market/storage/elite/specialised/entro_ingot")

    event.recipes.market.market("#opolisinc:ultimate_storage_license", "2x ae2:cell_component_256k", 1, "5x opolisinc:ultimate_storage_bucks").id("opolisinc:market/storage/ultimate/cell_component_256k")

    event.recipes.market.market("opolisinc:data_license", "16x opolisinc:ultimate_storage_bucks", 0, "1x opolisinc:ancient_data").id("opolisinc:market/misc/ancient_data")


    //Trading Licenses

    event.recipes.market.market("#opolisinc:basic_trading_license", "3x #opolisinc:villager_receipt_1", 1, "1x opolisinc:basic_trading_bucks").id("opolisinc:market/trading/basic/villager_receipt_1")
    event.recipes.market.market(SL("villager_receipt_1"), "6x #opolisinc:villager_receipt_1", 2, "1x opolisinc:basic_trading_bucks").id("opolisinc:market/trading/basic/specialised/villager_receipt_1")
    event.recipes.market.market("#opolisinc:basic_trading_license", "3x #opolisinc:villager_receipt_2", 1, "1x opolisinc:basic_trading_bucks").id("opolisinc:market/trading/basic/villager_receipt_2")
    event.recipes.market.market(SL("villager_receipt_2"), "6x #opolisinc:villager_receipt_2", 2, "1x opolisinc:basic_trading_bucks").id("opolisinc:market/trading/basic/specialised/villager_receipt_2")
    event.recipes.market.market("#opolisinc:basic_trading_license", "3x #opolisinc:villager_receipt_3", 1, "1x opolisinc:basic_trading_bucks").id("opolisinc:market/trading/basic/villager_receipt_3")
    event.recipes.market.market(SL("villager_receipt_3"), "6x #opolisinc:villager_receipt_3", 2, "1x opolisinc:basic_trading_bucks").id("opolisinc:market/trading/basic/specialised/villager_receipt_3")
    event.recipes.market.market("#opolisinc:basic_trading_license", "3x #opolisinc:villager_receipt_4", 1, "1x opolisinc:basic_trading_bucks").id("opolisinc:market/trading/basic/villager_receipt_4")
    event.recipes.market.market(SL("villager_receipt_4"), "6x #opolisinc:villager_receipt_4", 2, "1x opolisinc:basic_trading_bucks").id("opolisinc:market/trading/basic/specialised/villager_receipt_4")
    event.recipes.market.market("#opolisinc:basic_trading_license", "3x #opolisinc:villager_receipt_5", 1, "1x opolisinc:basic_trading_bucks").id("opolisinc:market/trading/basic/villager_receipt_5")
    event.recipes.market.market(SL("villager_receipt_5"), "6x #opolisinc:villager_receipt_5", 2, "1x opolisinc:basic_trading_bucks").id("opolisinc:market/trading/basic/specialised/villager_receipt_5")

    event.recipes.market.market("#opolisinc:advanced_trading_license", "3x #opolisinc:piglin_receipt", 1, "1x opolisinc:advanced_trading_bucks").id("opolisinc:market/trading/advanced/piglin_receipt")

    event.recipes.market.market("#opolisinc:elite_trading_license", "3x #opolisinc:queen_receipt", 1, "1x opolisinc:elite_trading_bucks").id("opolisinc:market/trading/elite/queen_receipt")

    event.recipes.market.market("#opolisinc:ultimate_trading_license", "4x #opolisinc:null_receipt", 2, "1x opolisinc:ultimate_trading_bucks").id("opolisinc:market/trading/ultimate/null_receipt")

    event.recipes.market.market("opolisinc:transaction_license", "1x opolisinc:ultimate_trading_bucks", 0, "opolisinc:monodimensional_transactor").id("opolisinc:market/misc/monodimensional_transactor")

    //batteries in data packs


    //TODO this now works inside the mod but will need to add very specific things to the kubejs system, may be easier to just use data packs for these specific recipes

    /* 
    event.recipes.market.market(1, "2x opolisinc:basic_processing_bucks", "opolisinc:basic_power_license", 'mekanism:portable_teleporter[mekanism:energy={energy_containers:[L;1000000L]}]')
    //'minecraft:potion[potion_contents={potion:"minecraft:night_vision"}]'
    */

    //Tools
    event.recipes.market.market("stone_pickaxe", "opolisutilities:b_bucks", 0, "stone_pickaxe").id("opolisinc:market/misc/stone_pickaxe")
    event.recipes.market.market("stone_sword", "opolisutilities:b_bucks", 0, "stone_sword").id("opolisinc:market/misc/stone_sword")
    event.recipes.market.market("stone_axe", "opolisutilities:b_bucks", 0, "stone_axe").id("opolisinc:market/misc/stone_axe")
    event.recipes.market.market("stone_shovel", "opolisutilities:b_bucks", 0, "stone_shovel").id("opolisinc:market/misc/stone_shovel")
    event.recipes.market.market("stone_hoe", "opolisutilities:b_bucks", 0, "stone_hoe").id("opolisinc:market/misc/stone_hoe")

    event.recipes.market.market("mekanismtools:lapis_lazuli_pickaxe", "opolisutilities:b_bucks", 0, "mekanismtools:lapis_lazuli_pickaxe").id("opolisinc:market/misc/lapis_lazuli_pickaxe")
    event.recipes.market.market("mekanismtools:lapis_lazuli_sword", "opolisutilities:b_bucks", 0, "mekanismtools:lapis_lazuli_sword").id("opolisinc:market/misc/lapis_lazuli_sword")
    event.recipes.market.market("mekanismtools:lapis_lazuli_axe", "opolisutilities:b_bucks", 0, "mekanismtools:lapis_lazuli_axe").id("opolisinc:market/misc/lapis_lazuli_axe")
    event.recipes.market.market("mekanismtools:lapis_lazuli_shovel", "opolisutilities:b_bucks", 0, "mekanismtools:lapis_lazuli_shovel").id("opolisinc:market/misc/lapis_lazuli_shovel")
    event.recipes.market.market("mekanismtools:lapis_lazuli_hoe", "opolisutilities:b_bucks", 0, "mekanismtools:lapis_lazuli_hoe").id("opolisinc:market/misc/lapis_lazuli_hoe")

    function toolBuying(type, buck_tier) {
        event.recipes.market.market(type + "_pickaxe", "6x opolisinc:" + buck_tier + "_mining_bucks", 0, type + "_pickaxe").id("opolisinc:market/misc/" + type.split(":")[1] + "_pickaxe")
        event.recipes.market.market(type + "_sword", "6x opolisinc:" + buck_tier + "_bounty_bucks", 0, type + "_sword").id("opolisinc:market/misc/" + type.split(":")[1] + "_sword")
        event.recipes.market.market(type + "_axe", "10x opolisinc:" + buck_tier + "_bounty_bucks", 0, type + "_axe").id("opolisinc:market/misc/" + type.split(":")[1] + "_axe")
        event.recipes.market.market(type + "_shovel", "6x opolisinc:" + buck_tier + "_mining_bucks", 0, type + "_shovel").id("opolisinc:market/misc/" + type.split(":")[1] + "_shovel")
        event.recipes.market.market(type + "_hoe", "6x opolisinc:" + buck_tier + "_farming_bucks", 0, type + "_hoe").id("opolisinc:market/misc/" + type.split(":")[1] + "_hoe")
    }

    toolBuying("minecraft:iron", "basic")
    toolBuying("ae2:nether_quartz", "basic")
    toolBuying("ae2:certus_quartz", "basic")
    toolBuying("mekanismtools:bronze", "basic")
    toolBuying("mekanismtools:refined_glowstone", "basic")

    toolBuying("minecraft:diamond", "advanced")
    toolBuying("mekanismtools:steel", "advanced")

    toolBuying("minecraft:netherite", "elite")
    toolBuying("mekanismtools:osmium", "elite")

    toolBuying("mekanismtools:refined_obsidian", "ultimate")

    event.recipes.market.market("ae2:fluix_pickaxe", "12x opolisinc:basic_mining_bucks", 0, "ae2:fluix_pickaxe").id("opolisinc:market/misc/fluix_pickaxe")
    event.recipes.market.market("ae2:fluix_sword", "12x opolisinc:basic_bounty_bucks", 0, "ae2:fluix_sword").id("opolisinc:market/misc/fluix_sword")
    event.recipes.market.market("ae2:fluix_axe", "20x opolisinc:basic_bounty_bucks", 0, "ae2:fluix_axe").id("opolisinc:market/misc/fluix_axe")
    event.recipes.market.market("ae2:fluix_shovel", "12x opolisinc:basic_mining_bucks", 0, "ae2:fluix_shovel").id("opolisinc:market/misc/fluix_shovel")
    event.recipes.market.market("ae2:fluix_hoe", "12x opolisinc:basic_farming_bucks", 0, "ae2:fluix_hoe").id("opolisinc:market/misc/fluix_hoe")


})
