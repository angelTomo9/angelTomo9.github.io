console.info('Loading crafting.js for Opolis Inc')

//priority: 10

ServerEvents.recipes(event => {

  //Licenses

  event.shaped('opolisinc:starting_license', [' S ', 'SBS', ' S '], { B: "opolisutilities:b_bucks", S: 'minecraft:stone' }).id('opolisinc:starting_license')


  event.shaped("opolisinc:basic_mining_license", ["FFF", "FFF", "FFF"], { F: "opolisinc:basic_mining_fragment" }).id("opolisinc:basic_mining_license")
  event.shaped("opolisinc:advanced_mining_license", ["FFF", "FBF", "FFF"], { F: "opolisinc:advanced_mining_fragment", B: "opolisinc:basic_mining_bucks" }).id("opolisinc:advanced_mining_license")
  event.shaped("opolisinc:elite_mining_license", ["FFF", "FBF", "FFF"], { F: "opolisinc:elite_mining_fragment", B: "opolisinc:advanced_mining_bucks" }).id("opolisinc:elite_mining_license")
  event.shaped("opolisinc:ultimate_mining_license", ["FFF", "FBF", "FFF"], { F: "opolisinc:ultimate_mining_fragment", B: "opolisinc:elite_mining_bucks" }).id("opolisinc:ultimate_mining_license")

  event.shaped('opolisinc:elite_power_license', ['CAC', 'APA', 'CAC'], { P: 'minecraft:paper', A: 'powah:capacitor_blazing', C: "#c:ingots/steel" }).id('opolisinc:elite_power_license')

  event.shaped('opolisinc:basic_storage_license', ['CCC', 'APA', 'CCC'], { P: 'minecraft:paper', A: "#c:ingots/iron", C: "#c:chests/wooden" }).id('opolisinc:basic_storage_license')
  event.shaped("opolisinc:advanced_storage_license", [" Q ", "QCQ", " Q "], { Q: "ae2:charged_certus_quartz_crystal", C: "ae2:cell_component_1k" }).id("opolisinc:advanced_storage_license")

  event.shaped('market:market', ['SCS', 'CDC', 'SCS'], { C: '#c:chests/wooden', D: "opolisutilities:b_bucks", S: 'minecraft:stone' }).id('market:market')

  event.shaped('opolisinc:basic_farming_license', ['SSS', 'STS', 'SSS'], { S: '#opolisinc:basic_crops', T: 'opolisinc:starting_license' }).id('opolisinc:basic_farming_license')
  event.shaped('opolisinc:advanced_farming_license', [' R ', 'RBR', ' R '], { R: '#opolisinc:sculked_crops', B: 'opolisinc:basic_farming_bucks' }).id('opolisinc:advanced_farming_license')
  event.custom({
    type: "mysticalagriculture:infusion",
    ingredients: [
      { item: "mysticalagriculture:inferium_essence" },
      { item: "minecraft:twisting_vines" },
      { item: "mysticalagriculture:inferium_essence" },
      { item: "minecraft:weeping_vines" },
      { item: "mysticalagriculture:inferium_essence" },
      { item: "minecraft:twisting_vines" },
      { item: "mysticalagriculture:inferium_essence" },
      { item: "minecraft:weeping_vines" }
    ],
    input: { item: "opolisinc:advanced_farming_bucks" },
    result: { id: "opolisinc:elite_farming_license", count: 1 }
  }).id("opolisinc:elite_farming_license")
  event.shaped('opolisinc:ultimate_farming_license', [' R ', 'RBR', ' R '], { B: 'opolisinc:elite_farming_bucks', R: '#opolisinc:phased_crops' }).id('opolisinc:ultimate_farming_license')

  event.shaped("opolisinc:basic_trading_license", [" O ", "THF", " I "], { O: "opolisinc:villager_receipt_1", T: "opolisinc:villager_receipt_2", H: "opolisinc:villager_receipt_3", F: "opolisinc:villager_receipt_4", I: "opolisinc:villager_receipt_5" }).id("opolisinc:basic_trading_license")
  event.shaped('opolisinc:advanced_trading_license', ['SSS', 'STS', 'SSS'], { S: 'minecraft:nether_bricks', T: 'opolisinc:basic_trading_license' }).id('opolisinc:advanced_trading_license')
  event.shaped("opolisinc:elite_trading_license", [" P ", "PLP", " P "], { P: "the_bumblezone:pollen_puff", L: "opolisinc:advanced_trading_license" }).id("opolisinc:elite_trading_license")
  event.shaped("opolisinc:ultimate_trading_license", [" R ", "RLR", " R "], { R: "opolisinc:null_receipt", L: "opolisinc:elite_trading_license" }).id("opolisinc:ultimate_trading_license")

  //Buck Uncrafting

  function buckDowncrafting(type) {
    event.shapeless("4x opolisinc:basic_" + type + "_bucks", "opolisinc:advanced_" + type + "_bucks").id("opolisinc:basic_" + type + "_bucks_downcraft")
    event.shapeless("4x opolisinc:advanced_" + type + "_bucks", "opolisinc:elite_" + type + "_bucks").id("opolisinc:advanced_" + type + "_bucks_downcraft")
    event.shapeless("4x opolisinc:elite_" + type + "_bucks", "opolisinc:ultimate_" + type + "_bucks").id("opolisinc:elite_" + type + "_bucks_downcraft")
  }

  buckDowncrafting("mining")
  buckDowncrafting("processing")
  buckDowncrafting("farming")
  buckDowncrafting("storage")
  buckDowncrafting("power")
  buckDowncrafting("bounty")
  buckDowncrafting("trading")

  function buckUpcrafting(type) {
    event.shaped("2x opolisinc:advanced_" + type + "_bucks", [" B ", "BAB", " B "], { B: "opolisinc:basic_" + type + "_bucks", A: "opolisinc:advanced_" + type + "_bucks" }).id("opolisinc:advanced_" + type + "_bucks_upcrafting")
    event.shaped("2x opolisinc:elite_" + type + "_bucks", [" B ", "BAB", " B "], { B: "opolisinc:advanced_" + type + "_bucks", A: "opolisinc:elite_" + type + "_bucks" }).id("opolisinc:elite_" + type + "_bucks_upcrafting")
    event.shaped("2x opolisinc:ultimate_" + type + "_bucks", [" B ", "BAB", " B "], { B: "opolisinc:elite_" + type + "_bucks", A: "opolisinc:ultimate_" + type + "_bucks" }).id("opolisinc:ultimate_" + type + "_bucks_upcrafting")
  }

  buckUpcrafting("mining")
  buckUpcrafting("processing")
  buckUpcrafting("farming")
  buckUpcrafting("storage")
  buckUpcrafting("power")
  buckUpcrafting("bounty")
  buckUpcrafting("trading")

  event.shapeless('1x opolisinc:nether_passport', ["opolisinc:nether_passport_fragment_1", "opolisinc:nether_passport_fragment_2", "opolisinc:nether_passport_fragment_3", "opolisinc:nether_passport_fragment_4", "opolisinc:nether_passport_fragment_5"]).id('opolisinc:nether_passport')

  event.shaped("opolisinc:basic_license_ore", ["BBB", "BSB", "BBB"], { B: "opolisinc:basic_mining_bucks", S: "stone" }).id("opolisinc:basic_license_ore")
  event.shaped("opolisinc:advanced_license_ore", ["BBB", "BSB", "BBB"], { B: "opolisinc:advanced_mining_bucks", S: "deepslate" }).id("opolisinc:advanced_license_ore")
  event.shaped("opolisinc:elite_license_ore", ["BBB", "BSB", "BBB"], { B: "opolisinc:elite_mining_bucks", S: "netherrack" }).id("opolisinc:elite_license_ore")
  event.shaped("opolisinc:ultimate_license_ore", ["BBB", "BSB", "BBB"], { B: "opolisinc:ultimate_mining_bucks", S: "end_stone" }).id("opolisinc:ultimate_license_ore")

  event.shaped("minecraft:enchanted_book[stored_enchantments={levels:{'minecraft:looting':1}}]", ["AAA", "ABA", "AAA"], { A: "opolisinc:advanced_bounty_bucks", B: "book" }).id("minecraft:enchanted_book/looting_1")
  event.shaped("minecraft:enchanted_book[stored_enchantments={levels:{'minecraft:looting':2}}]", ["AAA", "ABA", "AAA"], { A: "opolisinc:elite_bounty_bucks", B: "book" }).id("minecraft:enchanted_book/looting_2")
  event.shaped("minecraft:enchanted_book[stored_enchantments={levels:{'minecraft:looting':3}}]", ["AAA", "ABA", "AAA"], { A: "opolisinc:ultimate_bounty_bucks", B: "book" }).id("minecraft:enchanted_book/looting_3")
  event.shaped("minecraft:enchanted_book[stored_enchantments={levels:{'minecraft:fortune':1}}]", ["AAA", "ABA", "AAA"], { A: "opolisinc:advanced_mining_bucks", B: "book" }).id("minecraft:enchanted_book/fortune_1")
  event.shaped("minecraft:enchanted_book[stored_enchantments={levels:{'minecraft:fortune':2}}]", ["AAA", "ABA", "AAA"], { A: "opolisinc:elite_mining_bucks", B: "book" }).id("minecraft:enchanted_book/fortune_2")
  event.shaped("minecraft:enchanted_book[stored_enchantments={levels:{'minecraft:fortune':3}}]", ["AAA", "ABA", "AAA"], { A: "opolisinc:ultimate_mining_bucks", B: "book" }).id("minecraft:enchanted_book/fortune_3")
  event.shaped("minecraft:enchanted_book[stored_enchantments={levels:{'minecraft:silk_touch':1}}]", ["AAA", "ABA", "AAA"], { A: "opolisinc:basic_farming_bucks", B: "book" }).id("minecraft:enchanted_book/silk_touch")

  event.shaped("2x minecraft:heavy_core", [" O ", "OCO", " O "], { O: "#c:storage_blocks/osmium", C: "minecraft:heavy_core" }).id("minecraft:heavy_core")
  event.shaped("opolisinc:demon_core", [" F ", "FCF", " F "], { F: "mekanism:reprocessed_fissile_fragment", C: "minecraft:heavy_core" }).id("opolisinc:demon_core")

  event.shaped("2x opolisinc:basic_bounty_bucks", [" F ", "FBF", " F "], { B: "opolisinc:basic_bounty_bucks", F: "opolisinc:basic_bounty_fragment" }).id("opolisinc:basic_bounty_bucks_from_fragment")
  event.shaped("2x opolisinc:advanced_bounty_bucks", [" F ", "FBF", " F "], { B: "opolisinc:advanced_bounty_bucks", F: "opolisinc:advanced_bounty_fragment" }).id("opolisinc:advanced_bounty_bucks_from_fragment")
  event.shaped("2x opolisinc:elite_bounty_bucks", [" F ", "FBF", " F "], { B: "opolisinc:elite_bounty_bucks", F: "opolisinc:elite_bounty_fragment" }).id("opolisinc:elite_bounty_bucks_from_fragment")
  event.shaped("2x opolisinc:ultimate_bounty_bucks", [" F ", "FBF", " F "], { B: "opolisinc:ultimate_bounty_bucks", F: "opolisinc:ultimate_bounty_fragment" }).id("opolisinc:ultimate_bounty_bucks_from_fragment")

  //AE2
  event.shaped("ae2:mysterious_cube", ["SFS", "Q Q", "SFS"], { S: "ae2:sky_dust", F: "ae2:fluix_block", Q: "ae2:quartz_block" }).id("opolisinc:mysterious_cube")
  event.shaped('opolisinc:elite_storage_license', ["EEE", "EDE", "EEE"], { E: "extendedae:entro_ingot", D: "#opolisinc:1k_4k_storage_cells" }).id('opolisinc:elite_storage_license')
  event.shaped('opolisinc:ultimate_storage_license', ["EEE", "EDE", "EEE"], { E: 'extendedae:concurrent_processor_print', D: "#opolisinc:1k_4k_storage_cells" }).id('opolisinc:ultimate_storage_license')
  event.shapeless("extendedae:entro_budding_fully", ['extendedae:entro_seed', 'ae2:fluix_block']).id("opolisinc:entro_budding_fully")

  event.custom({
    "type": "extendedae:crystal_assembler",
    input_fluid: { amount: 25, ingredient: { fluid: "opolisinc:quantum_memory_fluid" } },
    "input_items": [
      {
        "amount": 2,
        "ingredient": {
          "item": "extendedae:concurrent_processor"
        }
      },
      {
        "amount": 3,
        "ingredient": {
          "item": "ae2:annihilation_core"
        }
      },
      {
        "amount": 3,
        "ingredient": {
          "item": "ae2:formation_core"
        }
      }
    ],
    "output": {
      "count": 1,
      "id": "opolisinc:quantum_processor"
    }
  }).id('opolisinc:quantum_processor')

  event.custom({
    "type": "extendedae:crystal_assembler",
    "input_fluid": {
      "amount": 180,
      "ingredient": {
        "fluid": "casting:molten_netherite"
      }
    },
    "input_items": [
      {
        "amount": 2,
        "ingredient": {
          "item": "opolisinc:shattered_singularity"
        }
      },
      {
        "amount": 4,
        "ingredient": {
          "item": "opolisinc:quantum_processor"
        }
      },
      {
        amount: 10,
        ingredient: {
          item: "opolisinc:phase_gene"
        }
      }
    ],
    "output": {
      "count": 1,
      "id": "opolisinc:quantum_encoded_storage_component"
    }
  }).id('opolisinc:quantum_encoded_storage_component')

  event.custom({
    "type": "extendedae:circuit_cutter",
    "input": {
      "ingredient": {
        "item": "ae2:singularity"
      }
    },
    "output": {
      "count": 8,
      "id": "opolisinc:shattered_singularity"
    }
  }).id('opolisinc:shattered_singularity')

  //Supreme Bucks

  event.recipes.powah.energizing(["powah:crystal_nitro", "powah:crystal_nitro", "powah:crystal_nitro", "powah:crystal_nitro"], "opolisinc:nitro_temporal_lattice", 20000000).id("powah:energizing/nitro_temporal_lattice")

  //Supreme Storage Bucks

  event.custom({
    type: "mysticalagriculture:awakening",
    essences: [
      { id: 'opolisinc:shattered_singularity', count: 4 },
      { id: 'opolisinc:shattered_singularity', count: 4 },
      { id: 'opolisinc:shattered_singularity', count: 4 },
      { id: 'opolisinc:shattered_singularity', count: 4 }
    ],
    input: { item: "opolisinc:reality_seeds" },
    ingredients: [
      { item: "opolisinc:ancient_data" },
      { item: "opolisinc:ancient_data" },
      { item: "opolisinc:ancient_data" },
      { item: "opolisinc:ancient_data" }
    ],
    result: { id: "opolisinc:cosmic_roots", count: 8 }
  }).id('opolisinc:supreme_farming_bucks')

  event.remove({ output: '#casting:molds' })

  //Cloche

  event.recipes.cloche.cloche("ae2:damaged_budding_quartz", "ae2:sky_stone_block", 2400, [["ae2:certus_quartz_crystal"]])
  event.recipes.cloche.cloche("ae2:flawed_budding_quartz", "ae2:sky_stone_block", 1200, [["ae2:certus_quartz_crystal"]])
  event.recipes.cloche.cloche("ae2:chipped_budding_quartz", "ae2:sky_stone_block", 600, [["ae2:certus_quartz_crystal"]])
  event.recipes.cloche.cloche("ae2:flawless_budding_quartz", "ae2:sky_stone_block", 300, [["ae2:certus_quartz_crystal"]])

  // Sculk Recipe
  event.recipes.cloche.cloche("minecraft:sculk", "minecraft:deepslate", 1200, [["minecraft:sculk"]])

  //Mystical Agriculture

  event.custom({
    "type": "mysticalagriculture:infusion",
    "ingredients": [
      { "item": "mysticalagriculture:inferium_essence" },
      { "item": "mysticalagriculture:inferium_essence" },
      { "item": "mysticalagriculture:inferium_essence" },
      { "item": "mysticalagriculture:inferium_essence" },
      { "item": "mysticalagriculture:inferium_essence" },
      { "item": "mysticalagriculture:inferium_essence" },
      { "item": "mysticalagriculture:inferium_essence" },
      { "item": "mysticalagriculture:inferium_essence" }
    ],
    "input": { "tag": "c:seeds" },
    "result": { "count": 1, "id": "mysticalagriculture:inferium_seeds" }
  }).id('mysticalagriculture:inferium_seeds')

  event.custom({
    "type": "mysticalagriculture:infusion",
    "ingredients": [
      {
        "item": "mysticalagriculture:imperium_essence",
      },
      {
        "item": "ae2:charged_certus_quartz_crystal",

      },
      {
        "item": "mysticalagriculture:imperium_essence",

      },
      {
        "item": "minecraft:redstone_block",

      },
      {
        "item": "mysticalagriculture:imperium_essence",

      },
      {
        "item": "ae2:charged_certus_quartz_crystal",

      },
      {
        "item": "mysticalagriculture:imperium_essence",

      },
      {
        "item": "minecraft:redstone_block",

      }
    ],
    "input": {
      "item": "mysticalagriculture:certus_quartz_seeds",
    },
    "result": {
      "count": 1,
      "id": "mysticalagriculture:fluix_seeds"
    }
  }).id('mysticalagriculture:seed/infusion/fluix')

  event.custom({
    type: "mysticalagriculture:infusion",
    ingredients: [
      { item: "mysticalagriculture:imperium_essence" },
      { item: "alltheores:steel_ingot" },
      { item: "mysticalagriculture:imperium_essence" },
      { item: "alltheores:steel_ingot" },
      { item: "mysticalagriculture:imperium_essence" },
      { item: "alltheores:steel_ingot" },
      { item: "mysticalagriculture:imperium_essence" },
      { item: "alltheores:steel_ingot" }
    ],
    input: { item: "mysticalagriculture:prosperity_seed_base" },
    result: { id: "mysticalagriculture:steel_seeds" }
  }).id("mysticalagriculture:seed/infusion/steel")


  event.custom({
    type: "mysticalagriculture:infusion",
    ingredients: [
      { item: "mysticalagriculture:inferium_essence" },
      { tag: "minecraft:logs" },
      { item: "mysticalagriculture:inferium_essence" },
      { tag: "minecraft:logs" },
      { item: "mysticalagriculture:inferium_essence" },
      { tag: "minecraft:logs" },
      { item: "mysticalagriculture:inferium_essence" },
      { tag: "minecraft:logs" }
    ],
    input: { item: "mysticalagriculture:prosperity_seed_base" },
    result: { id: "mysticalagriculture:wood_seeds" }
  }).id("mysticalagriculture:seed/infusion/wood")

  event.custom({
    type: "mysticalagriculture:infusion",
    ingredients: [
      { item: "mysticalagriculture:tertium_essence" },
      { tag: "c:gems/certus_quartz" },
      { item: "mysticalagriculture:tertium_essence" },
      { tag: "c:gems/certus_quartz" },
      { item: "mysticalagriculture:tertium_essence" },
      { tag: "c:gems/certus_quartz" },
      { item: "mysticalagriculture:tertium_essence" },
      { tag: "c:gems/certus_quartz" }
    ],
    input: { item: "mysticalagriculture:prosperity_seed_base" },
    result: { id: "mysticalagriculture:certus_quartz_seeds" }
  }).id("mysticalagriculture:seed/infusion/certus_quartz")

  event.custom(
    {
      type: "mysticalagriculture:infusion",
      ingredients: [
        { item: "mysticalagriculture:tertium_essence" },
        { item: "alltheores:bronze_ingot" },
        { item: "mysticalagriculture:tertium_essence" },
        { item: "alltheores:bronze_ingot" },
        { item: "mysticalagriculture:tertium_essence" },
        { item: "alltheores:bronze_ingot" },
        { item: "mysticalagriculture:tertium_essence" },
        { item: "alltheores:bronze_ingot" }
      ],
      input: { item: "mysticalagriculture:prosperity_seed_base" },
      result: { id: "mysticalagriculture:bronze_seeds" }
    }
  ).id("mysticalagriculture:seed/infusion/bronze")
  event.custom(
    {
      type: "mysticalagriculture:infusion",
      ingredients: [
        { item: "mysticalagriculture:tertium_essence" },
        { item: "alltheores:lead_ingot" },
        { item: "mysticalagriculture:tertium_essence" },
        { item: "alltheores:lead_ingot" },
        { item: "mysticalagriculture:tertium_essence" },
        { item: "alltheores:lead_ingot" },
        { item: "mysticalagriculture:tertium_essence" },
        { item: "alltheores:lead_ingot" }
      ],
      input: { item: "mysticalagriculture:prosperity_seed_base" },
      result: { id: "mysticalagriculture:lead_seeds" }
    }
  ).id("mysticalagriculture:seed/infusion/lead")
  event.custom(
    {
      type: "mysticalagriculture:infusion",
      ingredients: [
        { item: "mysticalagriculture:tertium_essence" },
        { item: "alltheores:tin_ingot" },
        { item: "mysticalagriculture:tertium_essence" },
        { item: "alltheores:tin_ingot" },
        { item: "mysticalagriculture:tertium_essence" },
        { item: "alltheores:tin_ingot" },
        { item: "mysticalagriculture:tertium_essence" },
        { item: "alltheores:tin_ingot" }
      ],
      input: { item: "mysticalagriculture:prosperity_seed_base" },
      result: { id: "mysticalagriculture:tin_seeds" }
    }
  ).id("mysticalagriculture:seed/infusion/tin")
  event.custom(
    {
      type: "mysticalagriculture:infusion",
      ingredients: [
        { item: "mysticalagriculture:imperium_essence" },
        { item: "alltheores:uranium_ingot" },
        { item: "mysticalagriculture:imperium_essence" },
        { item: "alltheores:uranium_ingot" },
        { item: "mysticalagriculture:imperium_essence" },
        { item: "alltheores:uranium_ingot" },
        { item: "mysticalagriculture:imperium_essence" },
        { item: "alltheores:uranium_ingot" }
      ],
      input: { item: "mysticalagriculture:prosperity_seed_base" },
      result: { id: "mysticalagriculture:uranium_seeds" }
    }
  ).id("mysticalagriculture:seed/infusion/uranium")
  event.custom(
    {
      type: "mysticalagriculture:infusion",
      ingredients: [
        { item: "mysticalagriculture:imperium_essence" },
        { item: "alltheores:osmium_ingot" },
        { item: "mysticalagriculture:imperium_essence" },
        { item: "alltheores:osmium_ingot" },
        { item: "mysticalagriculture:imperium_essence" },
        { item: "alltheores:osmium_ingot" },
        { item: "mysticalagriculture:imperium_essence" },
        { item: "alltheores:osmium_ingot" }
      ],
      input: { item: "mysticalagriculture:prosperity_seed_base" },
      result: { id: "mysticalagriculture:osmium_seeds" }
    }
  ).id("mysticalagriculture:seed/infusion/osmium")

  //Mystical

  event.shapeless("2x mysticalagriculture:cognizant_dust", ['mysticalagriculture:cognizant_dust', 'opolisinc:shattered_singularity']).id("opolisinc:cognizant_dust_crafting")

  //Powah
  event.shaped("powah:capacitor_hardened", [" D ", "SCS", " D "], { D: "powah:dielectric_paste", S: "powah:steel_energized", C: "powah:capacitor_basic" }).id("opolisinc:capacitor_hardened")
  event.shaped("powah:capacitor_blazing", [" D ", "BCB", " D "], { D: "powah:dielectric_paste", B: "powah:crystal_blazing", C: "powah:capacitor_basic" }).id("opolisinc:capacitor_blazing")
  event.shaped("powah:capacitor_niotic", [" D ", "NCN", " D "], { D: "powah:dielectric_paste", N: "powah:crystal_niotic", C: "powah:capacitor_basic" }).id("opolisinc:capacitor_niotic")
  event.shaped("2x powah:capacitor_niotic", ["DND", "NCN", "DND"], { D: "powah:dielectric_paste", N: "powah:crystal_niotic", C: "powah:capacitor_basic_large" }).id("powah:crafting/capacitor_niotic")
  event.shaped("powah:capacitor_spirited", [" D ", "SCS", " D "], { D: "powah:dielectric_paste", S: "powah:crystal_spirited", C: "powah:capacitor_basic" }).id("opolisinc:capacitor_spirited")
  event.shaped("2x powah:capacitor_spirited", ["DSD", "SCS", "DSD"], { D: "powah:dielectric_paste", S: "powah:crystal_spirited", C: "powah:capacitor_basic_large" }).id("powah:crafting/capacitor_spirited")

  // License
  event.recipes.powah.energizing(["opolisinc:elite_power_bucks", "opolisinc:elite_power_bucks", "opolisinc:elite_power_bucks", "opolisinc:elite_power_bucks", "opolisinc:elite_power_bucks", "opolisinc:elite_power_bucks"], "opolisinc:ultimate_power_license", 500000).id("opolisinc:ultimate_power_license")

  // Niotic / Spirited
  event.recipes.powah.energizing(["#c:gems/diamond"], "powah:crystal_niotic", 200000).id("powah:energizing/niotic_crystal")
  event.recipes.powah.energizing(["#c:gems/emerald"], "powah:crystal_spirited", 400000).id("powah:energizing/spirited_crystal")

  // Nitro
  event.recipes.powah.energizing(["opolisinc:ultimate_power_bucks", "opolisinc:ultimate_power_bucks", "opolisinc:ultimate_power_bucks", "opolisinc:ultimate_power_bucks", "minecraft:nether_star"], "16x powah:crystal_nitro", 2000000).id("powah:energizing/nitro_crystal")

  // Uraninite
  event.recipes.powah.energizing(["alltheores:raw_uranium"], "powah:uraninite_raw", 1000).id("opolisinc:energizing/uraninite_raw_from_ore")
  event.recipes.powah.energizing(["alltheores:raw_uranium_block"], "9x powah:uraninite_raw", 9000).id("opolisinc:energizing/uraninite_raw_from_block")

  // Energized steel
  event.recipes.powah.energizing(["iron_ingot", "gold_ingot", "opolisinc:basic_power_bucks"], "4x powah:steel_energized", 10000).id("opolisinc:energizing/basic_energized_steel")
  event.recipes.powah.energizing(["iron_ingot", "gold_ingot", "opolisinc:advanced_power_bucks"], "6x powah:steel_energized", 10000).id("opolisinc:energizing/advanced_energized_steel")
  event.recipes.powah.energizing(["iron_ingot", "gold_ingot", "opolisinc:elite_power_bucks"], "8x powah:steel_energized", 10000).id("opolisinc:energizing/elite_energized_steel")
  event.recipes.powah.energizing(["iron_ingot", "gold_ingot", "opolisinc:ultimate_power_bucks"], "10x powah:steel_energized", 10000).id("opolisinc:energizing/ultimate_energized_steel")

  // Helper for buck‑based crystal upgrades
  function buckEnergizing(input, output, energy) {
    const metal = output.split(":")[1]

    event.recipes.powah.energizing([input, "opolisinc:basic_power_bucks"], `2x ${output}`, energy).id(`opolisinc:energizing/basic_${metal}`)

    event.recipes.powah.energizing([input, "opolisinc:advanced_power_bucks"], `3x ${output}`, energy).id(`opolisinc:energizing/advanced_${metal}`)

    event.recipes.powah.energizing([input, "opolisinc:elite_power_bucks"], `4x ${output}`, energy).id(`opolisinc:energizing/elite_${metal}`)

    event.recipes.powah.energizing([input, "opolisinc:ultimate_power_bucks"], `5x ${output}`, energy).id(`opolisinc:energizing/ultimate_${metal}`)
  }

  buckEnergizing("blaze_rod", "powah:crystal_blazing", 120000)
  buckEnergizing("diamond", "powah:crystal_niotic", 200000)
  buckEnergizing("emerald", "powah:crystal_spirited", 400000)

  //Misc

  event.shaped("structurecompass:structure_compass", [" I ", "ICI", " I "], { I: "iron_ingot", C: "powah:capacitor_hardened" }).id("structurecompass:structure_compass")
  event.shapeless("ender_pearl", ["opolisinc:activated_ender_pearl"]).id("opolisinc:deactivate_ender_pearl")
  event.shaped("opolisinc:corruption_map", ["PPP", "PAP", "PPP"], { P: "paper", A: "opolisinc:activated_ender_pearl" }).id("opolisinc:corruption_finder")
  event.shaped("opolisinc:throne_pillar_map", ["PPP", "PAP", "PPP"], { P: "paper", A: "the_bumblezone:pollen_puff" }).id("opolisinc:throne_pillar_map")

  event.shaped("squarry:powered_quarry", [" B ", "BQB", " B "], { B: "opolisinc:advanced_power_bucks", Q: "squarry:fuel_quarry" }).id("opolisinc:powered_quarry")

  event.shaped("opolisinc:opolisite_ingot", ["NNN", "NNN", "NNN"], { N: "opolisinc:opolisite_nugget" }).id("opolisinc:opolisite_ingot_from_nugget")
  event.shapeless("9x opolisinc:opolisite_nugget", ["opolisinc:opolisite_ingot"]).id("opolisinc:opolisite_nugget_from_ingot")
  event.shaped("opolisinc:opolisite_block", ["III", "III", "III"], { I: "opolisinc:opolisite_ingot" }).id("opolisinc:opolisite_block_from_ingot")
  event.shapeless("9x opolisinc:opolisite_ingot", ["opolisinc:opolisite_block"]).id("opolisinc:opolisite_ingot_from_block")

  event.shaped("ae2:cell_component_4k", [" R ", "PCP", " R "], { R: "redstone", P: "ae2:logic_processor", C: "ae2:cell_component_1k" }).id("ae2:network/cells/item_storage_components_cell_4k_part")
  event.shaped("ae2:cell_component_16k", [" R ", "PCP", " R "], { R: "glowstone_dust", P: "ae2:calculation_processor", C: "ae2:cell_component_4k" }).id("ae2:network/cells/item_storage_components_cell_16k_part")
  event.shaped("ae2:cell_component_64k", [" R ", "PCP", " R "], { R: "glowstone_dust", P: "ae2:engineering_processor", C: "ae2:cell_component_16k" }).id("ae2:network/cells/item_storage_components_cell_64k_part")
  event.shaped("ae2:cell_component_256k", [" R ", "PCP", " R "], { R: "ae2:sky_dust", P: "extendedae:concurrent_processor", C: "ae2:cell_component_64k" }).id("ae2:network/cells/item_storage_components_cell_256k_part")

  event.shaped("mekanism:combiner", ["RBR", "PCP", "RBR"], { R: "redstone", B: "mekanism:basic_control_circuit", P: "piston", C: "mekanism:steel_casing" }).id("mekanism:combiner")

  event.shaped("8x ae2:silicon", ["SSS"], { S: "mysticalagriculture:silicon_essence" }).id("mysticalagriculture:essence/common/silicon")

  event.shaped("squarry:quarry_pipe", ["I", "I", "I"], { I: "iron_ingot" }).id("opolisinc:quarry_pipe")

  event.shaped("functionalstorage:compacting_framed_drawer", ["NNN", "NDN", "NNN"], { N: "iron_nugget", D: "functionalstorage:compacting_drawer" }).id("functionalstorage:compacting_framed_drawer_from_simple")
  event.shaped("functionalstorage:framed_storage_controller", ["NNN", "NDN", "NNN"], { N: "iron_nugget", D: "functionalstorage:storage_controller" }).id("functionalstorage:framed_storage_controller")
  event.shaped("functionalstorage:framed_controller_extension", ["NNN", "NDN", "NNN"], { N: "iron_nugget", D: "functionalstorage:controller_extension" }).id("functionalstorage:framed_controller_extension")
  event.shaped("functionalstorage:framed_simple_compacting_drawer", ["NNN", "NDN", "NNN"], { N: "iron_nugget", D: "functionalstorage:simple_compacting_drawer" }).id("functionalstorage:framed_simple_compacting_drawer_from_simple")

  event.shaped("copper_block", ["CC", "CC"], { C: "chiseled_copper" }).id("opolisinc:chiseled_copper_backcrafting")
  event.shaped("copper_block", ["CC", "CC"], { C: "cut_copper" }).id("opolisinc:cut_copper_backcrafting")
  event.shaped("copper_block", ["CC", "CC"], { C: "copper_grate" }).id("opolisinc:copper_grate_backcrafting")
  event.shaped("copper_block", ["CC", "CC"], { C: "cut_copper_stairs" }).id("opolisinc:cut_copper_stairs_backcrafting")
  event.shaped("copper_block", ["CCC", "C C", "CCC"], { C: "cut_copper_slab" }).id("opolisinc:cut_copper_slab_backcrafting")

  event.shaped("extendedcrafting:compressor", ["III", "ICI", "III"], { I: "extendedcrafting:black_iron_ingot", C: "mekanism:steel_casing" }).id("extendedcrafting:compressor")

  event.shaped("opolisinc:interdimensional_transactor", ["ONB", "ETE", "BNO"], { O: "opolisinc:fragments_of_the_overworld", N: "opolisinc:fragments_of_the_nether", B: "opolisinc:fragments_of_the_bumblezone", E: "opolisinc:fragments_of_the_end", T: "opolisinc:monodimensional_transactor" }).id("opolisinc:interdimensional_transactor")

  event.shapeless("4x alltheores:enderium_dust", ["alltheores:lead_dust", "alltheores:lead_dust", "alltheores:lead_dust", "alltheores:platinum_dust", "ae2:ender_dust", "ae2:ender_dust"]).id("alltheores:crifting/enderium/alloy_blending_from_dust")

  //Resource Generator

  event.recipes.opolisutilities.resource_generator("minecraft:netherrack")
  event.recipes.opolisutilities.resource_generator("minecraft:basalt")

  //Summoning

  event.recipes.opolisutilities.summoning_block("#minecraft:beds", "hay_block", "minecraft:villager")

  //Soaking/Drying Table

  event.recipes.opolisutilities.drying_table("clay", "mud", 200).id("opolisinc:drying_table/clay")

  //In World Recipes

  // End fragment in Liquid Null
  event.custom({
    type: 'inworldrecipes:drop_item_in_fluid',
    dropped_items: [
      { item: 'opolisinc:ultimate_trading_bucks', count: 1 }
    ],
    fluid: 'biomesoplenty:liquid_null',
    consume_fluid: false,
    results: [
      { item: { id: 'opolisinc:fragments_of_the_end', count: 1 } }
    ]
  }).id('opolisinc:item_in_fluid_fragments_of_the_end')

  // Nether fragment in Lava
  event.custom({
    type: 'inworldrecipes:drop_item_in_fluid',
    dropped_items: [
      { item: 'opolisinc:ultimate_trading_bucks', count: 1 }
    ],
    fluid: 'minecraft:lava',
    consume_fluid: false,
    results: [
      { item: { id: 'opolisinc:fragments_of_the_nether', count: 1 } }
    ]
  }).id('opolisinc:item_in_fluid_fragments_of_the_nether')

  // Null receipt from specific receipts in Liquid Null
  function nullReceiptFrom(receiptId, index) {
    event.custom({
      type: 'inworldrecipes:drop_item_in_fluid',
      dropped_items: [
        { item: receiptId, count: 1 }
      ],
      fluid: 'biomesoplenty:liquid_null',
      consume_fluid: false,
      results: [
        { item: { id: 'opolisinc:null_receipt', count: 1 } }
      ]
    }).id(`opolisinc:item_in_fluid_null_receipt_${index}`)
  }

  nullReceiptFrom('opolisinc:villager_receipt_1', 1)
  nullReceiptFrom('opolisinc:villager_receipt_2', 2)
  nullReceiptFrom('opolisinc:villager_receipt_3', 3)
  nullReceiptFrom('opolisinc:villager_receipt_4', 4)
  nullReceiptFrom('opolisinc:villager_receipt_5', 5)
  nullReceiptFrom('opolisinc:queen_receipt', 6)
  nullReceiptFrom('opolisinc:piglin_receipt', 7)

  /*
  event.custom({
    type: "inworldrecipes:drop_item_in_fluid",
    dropped_items: [
      {
        tag: "opolisinc:receipts",
        count: 1,
      },
    ],
    fluid: "biomesoplenty:liquid_null",
    consume_fluid: false,
    results: [
      {
        item: { count: 1, id: "opolisinc:null_receipt" },
      },
    ],
  }).id("opolisinc:item_in_fluid/null_receipt");
  */

  //Replace

  event.replaceInput({ id: "opolisutilities:catalogue" }, '#c:stones', 'minecraft:stone')
  event.replaceInput({ id: "casting:tank" }, '#c:glass_blocks', 'minecraft:bucket')
  event.replaceInput({ id: "mekanism:metallurgic_infuser" }, '#c:ingots/osmium', 'mekanism:steel_casing')
  event.replaceInput({ output: "powah:capacitor_basic" }, "minecraft:redstone_block", "minecraft:redstone")
  event.replaceInput({ output: "powah:battery_starter" }, "minecraft:redstone_block", "minecraft:redstone")
  event.replaceInput({ output: "powah:battery_basic" }, "minecraft:redstone_block", "minecraft:redstone")
  event.replaceInput({ output: "powah:battery_hardened" }, "minecraft:redstone_block", "minecraft:redstone")
  event.replaceInput({ output: "powah:battery_blazing" }, "minecraft:redstone_block", "minecraft:redstone")
  event.replaceInput({ output: "powah:battery_niotic" }, "minecraft:redstone_block", "minecraft:redstone")
  event.replaceInput({ output: "powah:battery_spirited" }, "minecraft:redstone_block", "minecraft:redstone")
  event.replaceInput({ output: "powah:battery_niotic" }, "minecraft:redstone_block", "minecraft:redstone")
  event.replaceInput({ output: "sawmill:sawmill" }, "iron_ingot", "#minecraft:logs")

  event.replaceInput({ id: "mysticalagriculture:awakening_pedestal" }, "gold_ingot", "opolisinc:shattered_singularity")
  event.replaceInput({ id: "mysticalagriculture:awakening_altar" }, "gold_ingot", "opolisinc:shattered_singularity")
  event.replaceInput({ id: "mysticalagriculture:essence_vessel" }, "gold_ingot", "opolisinc:shattered_singularity")

  event.replaceInput({ type: "cloche:cloche" }, "#minecraft:dirt", "farmersdelight:rich_soil")

  //Remove Vanilla Smelting for raw materials
  event.remove({ output: 'powah:dielectric_paste' })

  event.remove({ type: 'minecraft:smelting', output: '#c:ingots', input: '#c:raw_materials' })
  event.remove({ type: 'minecraft:blasting', output: '#c:ingots', input: '#c:raw_materials' })
  event.remove({ type: 'minecraft:smelting', output: '#c:ingots', input: '#c:ores' })
  event.remove({ type: 'minecraft:blasting', output: '#c:ingots', input: '#c:ores' })

  event.remove({ input: '#alltheores:ore_hammers' })

  event.remove({ id: 'minecraft:glass' })
  event.remove({ mod: 'ironchest' })

  event.remove({ type: "market:market", input: "minecraft:paper" })
  event.remove({ type: "market:market", input: "opolisutilities:log_sheet" })
  event.remove({ type: "market:market", input: "minecraft:diamond_sword" })
  event.remove({ type: "market:market", input: "minecraft:diamond" })
  event.remove({ id: "market:nbt_test_11" })
  event.remove({ id: "casting:test" })
  event.remove({ id: "farmersdelight:organic_compost_from_tree_bark" })
  event.remove({ id: "mekanism:processing/uranium/reprocessing/to_fuel" })
  event.remove({ id: "easy_villagers:iron_farm" })
  event.remove({ id: "easy_villagers:farmer" })
  event.remove({ id: "ae2:transform/fluix_crystal" })
  event.remove({ id: "ae2:transform/fluix_crystals" })
  event.remove({ id: "ae2:network/cells/fluid_storage_cell_1k" })
  event.remove({ id: "ae2:network/cells/item_storage_cell_1k" })
  event.remove({ id: "ae2:network/cells/fluid_storage_cell_4k" })
  event.remove({ id: "ae2:network/cells/item_storage_cell_4k" })
  event.remove({ id: "ae2:network/cells/fluid_storage_cell_16k" })
  event.remove({ id: "ae2:network/cells/item_storage_cell_16k" })
  event.remove({ id: "ae2:network/cells/fluid_storage_cell_64k" })
  event.remove({ id: "ae2:network/cells/item_storage_cell_64k" })
  event.remove({ id: "ae2:network/cells/fluid_storage_cell_256k" })
  event.remove({ id: "ae2:network/cells/item_storage_cell_256k" })
  event.remove({ id: "extendedae:inscriber/concurrent_process" })
  event.remove({ id: "extendedae:inscriber/concurrent_print" })
  event.remove({ id: "alltheores:brass_dust_from_alloy_blending" })
  event.remove({ id: "alltheores:invar_dust_from_alloy_blending" })
  event.remove({ id: "alltheores:signalum_dust_from_alloy_blending" })
  event.remove({ id: "alltheores:lumium_dust_from_alloy_blending" })
  event.remove({ id: "alltheores:constantan_dust_from_alloy_blending" })
  event.remove({ id: "alltheores:bronze_dust_from_alloy_blending" })

  event.remove({ id: "mysticalagriculture:mystical_fertilizer" })
  event.remove({ id: "mysticalagriculture:mystical_fertilizer_better" })

  event.remove({ id: "mysticalagriculture:essence/minecraft/iron_ingot" })
  event.remove({ id: "mysticalagriculture:essence/minecraft/copper_ingot" })
  event.remove({ id: "mysticalagriculture:essence/minecraft/gold_ingot" })
  event.remove({ id: "mysticalagriculture:essence/minecraft/coal" })
  event.remove({ id: "mysticalagriculture:essence/minecraft/redstone" })
  event.remove({ id: "mysticalagriculture:essence/minecraft/lapis_lazuli" })
  event.remove({ id: "mysticalagriculture:essence/minecraft/diamond" })
  event.remove({ id: "mysticalagriculture:essence/minecraft/emerald" })
  event.remove({ id: "mysticalagriculture:essence/minecraft/netherite_ingot" })
  event.remove({ id: "mysticalagriculture:essence/common/aluminum_ingot" })
  event.remove({ id: "mysticalagriculture:essence/common/tin_ingot" })
  event.remove({ id: "mysticalagriculture:essence/common/zinc_ingot" })
  event.remove({ id: "mysticalagriculture:essence/common/silver_ingot" })
  event.remove({ id: "mysticalagriculture:essence/common/lead_ingot" })
  event.remove({ id: "mysticalagriculture:essence/common/nickel_ingot" })
  event.remove({ id: "mysticalagriculture:essence/common/uranium_ingot" })
  event.remove({ id: "mysticalagriculture:essence/mekanism/osmium_ingot" })
  event.remove({ id: "mysticalagriculture:essence/common/platinum_ingot" })
  event.remove({ id: "mysticalagriculture:essence/common/iridium_ingot" })

  event.remove({ id: "mekanism:processing/netherite/ancient_debris_to_dirty_netherite_scrap" })

  event.remove({ id: "functionalstorage:framed_simple_compacting_drawer" })
  event.remove({ id: "functionalstorage:compacting_framed_drawer" })

  event.remove({ id: /bblcompat:.*mysticalagriculture.*/ })
  event.remove({ id: /bblcompat:.*caveopolis.*/ })

  event.remove({ output: "mysticalagriculture:nether_star_seeds" })
  event.remove({ output: "mysticalagriculture:nitro_crystal_seeds" })
  event.remove({ output: "mysticalagriculture:niotic_crystal_seeds" })
  event.remove({ output: "mysticalagriculture:spirited_crystal_seeds" })
  event.remove({ output: "mysticalagriculture:blazing_crystal_seeds" })
  event.remove({ output: "mysticalagriculture:energized_steel_seeds" })

  event.remove({ mod: "inworldrecipes" })


  //Remove in release versions

  event.shapeless("alltheores:raw_tin", ["mekanism:raw_tin"]).id("opolisinc:tin_conversion")
  event.shapeless("alltheores:raw_lead", ["mekanism:raw_lead"]).id("opolisinc:lead_conversion")
  event.shapeless("alltheores:raw_osmium", ["mekanism:raw_osmium"]).id("opolisinc:osmium_conversion")
  event.shapeless("alltheores:raw_uranium", ["mekanism:raw_uranium"]).id("opolisinc:uranium_conversion")
  event.shapeless("alltheores:fluorite", ["mekanism:fluorite_gem"]).id("opolisinc:fluorite_conversion")

  /*


  event.addBlockModifier("mekanism:tin_ore").replaceLoot("mekanism:raw_tin", "alltheores:raw_tin", true)
  event.addBlockModifier("mekanism:deepslate_tin_ore").replaceLoot("mekanism:raw_tin", "alltheores:raw_tin", true)
  event.addBlockModifier("mekanism:lead_ore").replaceLoot("mekanism:raw_lead", "alltheores:raw_lead", true)
  event.addBlockModifier("mekanism:deepslate_lead_ore").replaceLoot("mekanism:raw_lead", "alltheores:raw_lead", true)
  event.addBlockModifier("mekanism:osmium_ore").replaceLoot("mekanism:raw_osmium", "alltheores:raw_osmium", true)
  event.addBlockModifier("mekanism:deepslate_osmium_ore").replaceLoot("mekanism:raw_osmium", "alltheores:raw_osmium", true)
  event.addBlockModifier("mekanism:uranium_ore").replaceLoot("mekanism:raw_uranium", "alltheores:raw_uranium", true)
  event.addBlockModifier("mekanism:deepslate_uranium_ore").replaceLoot("mekanism:raw_uranium", "alltheores:raw_uranium", true)
  event.addBlockModifier("mekanism:fluorite_ore").replaceLoot("mekanism:fluorite_gem", "alltheores:fluorite", true)
  event.addBlockModifier("mekanism:deepslate_fluorite_ore").replaceLoot("mekanism:fluorite_gem", "alltheores:fluorite", true)
  */


})
