console.info('Loading catalogue.js for Opolis Inc')

ServerEvents.recipes(event => {

    //Mining Bucks

    event.recipes.opolisutilities.catalogue("iron_pickaxe", "6x opolisinc:basic_mining_bucks").id("minecraft:iron_pickaxe")
    event.recipes.opolisutilities.catalogue("ae2:nether_quartz_pickaxe", "6x opolisinc:basic_mining_bucks").id("ae2:tools/nether_quartz_pickaxe")
    event.recipes.opolisutilities.catalogue("ae2:certus_quartz_pickaxe", "6x opolisinc:basic_mining_bucks").id("ae2:tools/certus_quartz_pickaxe")
    event.recipes.opolisutilities.catalogue("ae2:fluix_pickaxe", "12x opolisinc:basic_mining_bucks").id("ae2:tools/fluix_pickaxe")
    event.recipes.opolisutilities.catalogue("mekanismtools:bronze_pickaxe", "6x opolisinc:basic_mining_bucks").id("mekanismtools:bronze/tools/pickaxe")
    event.recipes.opolisutilities.catalogue("mekanismtools:refined_glowstone_pickaxe", "6x opolisinc:basic_mining_bucks").id("mekanismtools:refined_glowstone/tools/pickaxe")
    event.recipes.opolisutilities.catalogue("minecraft:iron_shovel", "6x opolisinc:basic_mining_bucks").id('minecraft:iron_shovel')
    event.recipes.opolisutilities.catalogue("ae2:nether_quartz_shovel", "6x opolisinc:basic_mining_bucks").id("ae2:tools/nether_quartz_spade")
    event.recipes.opolisutilities.catalogue("ae2:certus_quartz_shovel", "6x opolisinc:basic_mining_bucks").id("ae2:tools/certus_quartz_spade")
    event.recipes.opolisutilities.catalogue("ae2:fluix_shovel", "12x opolisinc:basic_mining_bucks").id("ae2:tools/fluix_shovel")
    event.recipes.opolisutilities.catalogue("mekanismtools:bronze_shovel", "6x opolisinc:basic_mining_bucks").id("mekanismtools:bronze/tools/shovel")
    event.recipes.opolisutilities.catalogue("mekanismtools:refined_glowstone_shovel", "6x opolisinc:basic_mining_bucks").id("mekanismtools:refined_glowstone/tools/shovel")

    event.recipes.opolisutilities.catalogue("minecraft:bucket", "1x opolisinc:advanced_mining_bucks").id("opolisinc:catalogue/bucket")
    event.recipes.opolisutilities.catalogue("minecraft:lava_bucket", "2x opolisinc:advanced_mining_bucks").id("opolisinc:catalogue/lava_bucket")
    event.recipes.opolisutilities.catalogue("squarry:fuel_quarry", "8x opolisinc:advanced_mining_bucks").id("opolisinc:catalogue/fuel_quarry")
    event.recipes.opolisutilities.catalogue('squarry:upgrade_efficiency_1', "8x opolisinc:advanced_mining_bucks").id("opolisinc:catalogue/upgrade_efficiency_1")
    event.recipes.opolisutilities.catalogue('squarry:upgrade_silk', "8x opolisinc:advanced_mining_bucks").id("opolisinc:catalogue/upgrade_silk")
    event.recipes.opolisutilities.catalogue('squarry:upgrade_filter', "8x opolisinc:advanced_mining_bucks").id("opolisinc:catalogue/upgrade_filter")
    event.recipes.opolisutilities.catalogue('squarry:upgrade_filler', "8x opolisinc:advanced_mining_bucks").id("opolisinc:catalogue/upgrade_filler")
    event.recipes.opolisutilities.catalogue('squarry:upgrade_unification', "8x opolisinc:advanced_mining_bucks").id("opolisinc:catalogue/upgrade_unification")
    event.recipes.opolisutilities.catalogue("casting:ingot_mold", "3x opolisinc:advanced_mining_bucks").id("opolisinc:catalogue/ingot_mold")
    event.recipes.opolisutilities.catalogue("casting:nugget_mold", "3x opolisinc:advanced_mining_bucks").id("opolisinc:catalogue/nugget_mold")
    event.recipes.opolisutilities.catalogue("casting:block_mold", "3x opolisinc:advanced_mining_bucks").id("opolisinc:catalogue/block_mold")
    event.recipes.opolisutilities.catalogue("casting:rod_mold", "3x opolisinc:advanced_mining_bucks").id("opolisinc:catalogue/rod_mold")
    event.recipes.opolisutilities.catalogue("casting:plate_mold", "3x opolisinc:advanced_mining_bucks").id("opolisinc:catalogue/plate_mold")
    event.recipes.opolisutilities.catalogue("casting:gear_mold", "3x opolisinc:advanced_mining_bucks").id("opolisinc:catalogue/gear_mold")
    event.recipes.opolisutilities.catalogue("casting:gem_mold", "3x opolisinc:advanced_mining_bucks").id("opolisinc:catalogue/gem_mold")
    event.recipes.opolisutilities.catalogue("casting:dust_mold", "3x opolisinc:advanced_mining_bucks").id("opolisinc:catalogue/dust_mold")
    event.recipes.opolisutilities.catalogue("casting:ball_mold", "3x opolisinc:advanced_mining_bucks").id("opolisinc:catalogue/ball_mold")
    event.recipes.opolisutilities.catalogue("casting:mixer", "8x opolisinc:advanced_mining_bucks").id("opolisinc:catalogue/mixer")
    event.recipes.opolisutilities.catalogue("diamond_pickaxe", "6x opolisinc:advanced_mining_bucks").id("minecraft:diamond_pickaxe")
    event.recipes.opolisutilities.catalogue("diamond_shovel", "6x opolisinc:advanced_mining_bucks").id("minecraft:diamond_shovel")
    event.recipes.opolisutilities.catalogue("mekanismtools:steel_pickaxe", "6x opolisinc:advanced_mining_bucks").id("mekanismtools:steel/tools/pickaxe")
    event.recipes.opolisutilities.catalogue("mekanismtools:steel_shovel", "6x opolisinc:advanced_mining_bucks").id("mekanismtools:steel/tools/shovel")

    event.recipes.opolisutilities.catalogue("netherite_pickaxe", "6x opolisinc:elite_mining_bucks").id("minecraft:netherite_pickaxe_smithing")
    event.recipes.opolisutilities.catalogue("mekanismtools:osmium_pickaxe", "6x opolisinc:elite_mining_bucks").id("mekanismtools:osmium/tools/pickaxe")
    event.recipes.opolisutilities.catalogue("netherite_shovel", "6x opolisinc:elite_mining_bucks").id("minecraft:netherite_shovel_smithing")
    event.recipes.opolisutilities.catalogue("mekanismtools:osmium_shovel", "6x opolisinc:elite_mining_bucks").id("mekanismtools:osmium/tools/shovel")
    event.recipes.opolisutilities.catalogue('squarry:upgrade_efficiency_2', "12x opolisinc:elite_mining_bucks").id("opolisinc:catalogue/upgrade_efficiency_2")
    event.recipes.opolisutilities.catalogue("opolisinc:drill_license", "32x opolisinc:elite_mining_bucks").id("opolisinc:catalogue/drill_license")

    event.recipes.opolisutilities.catalogue("mekanismtools:refined_obsidian_pickaxe", "6x opolisinc:ultimate_mining_bucks").id("mekanismtools:refined_obsidian/tools/pickaxe")
    event.recipes.opolisutilities.catalogue("mekanismtools:refined_obsidian_shovel", "6x opolisinc:ultimate_mining_bucks").id("mekanismtools:refined_obsidian/tools/shovel")
    event.recipes.opolisutilities.catalogue('squarry:upgrade_efficiency_3', "16x opolisinc:ultimate_mining_bucks").id("opolisinc:catalogue/upgrade_efficiency_3")

    //Power Bucks

    event.recipes.opolisutilities.catalogue("mekanismgenerators:solar_generator", "4x opolisinc:basic_power_bucks").id('mekanismgenerators:generator/solar')
    event.recipes.opolisutilities.catalogue("mekanismgenerators:wind_generator", "4x opolisinc:basic_power_bucks").id('mekanismgenerators:generator/wind')
    event.recipes.opolisutilities.catalogue("mekanismgenerators:heat_generator", "4x opolisinc:basic_power_bucks").id('mekanismgenerators:generator/heat')
    event.recipes.opolisutilities.catalogue("8x mekanism:basic_universal_cable", "1x opolisinc:basic_power_bucks").id('mekanism:transmitter/universal_cable/basic')

    event.recipes.opolisutilities.catalogue("powah:energizing_orb", "25x opolisinc:advanced_power_bucks").id('powah:crafting/energizing_orb')
    event.recipes.opolisutilities.catalogue("mekanismgenerators:advanced_solar_generator", "5x opolisinc:advanced_power_bucks").id('mekanismgenerators:generator/advanced_solar')
    event.recipes.opolisutilities.catalogue("mekanismgenerators:bio_generator", "4x opolisinc:advanced_power_bucks").id('mekanismgenerators:generator/bio')

    event.recipes.opolisutilities.catalogue("4x powah:reactor_starter", "2x opolisinc:elite_power_bucks").id("powah:crafting/reactor_starter")
    event.recipes.opolisutilities.catalogue("mekanismgenerators:gas_burning_generator", "8x opolisinc:elite_power_bucks").id("mekanismgenerators:generator/gas_burning")
    event.recipes.opolisutilities.catalogue("opolisinc:radiation_relief", "32x opolisinc:elite_power_bucks").id("opolisinc:radiation_relief")

    //********** Storage Bucks **********//
    //Iron Chests
    event.recipes.opolisutilities.catalogue("ironchest:dirt_chest", "3x opolisinc:basic_storage_bucks").id('opolicinc:dirt_chest')
    event.recipes.opolisutilities.catalogue("ironchest:copper_chest", "5x opolisinc:basic_storage_bucks").id('opolicinc:copper_chest')
    event.recipes.opolisutilities.catalogue("ironchest:iron_chest", "6x opolisinc:basic_storage_bucks").id('opolicinc:iron_chest')
    event.recipes.opolisutilities.catalogue("ironchest:gold_chest", "9x opolisinc:basic_storage_bucks").id('opolicinc:gold_chest')
    event.recipes.opolisutilities.catalogue("ironchest:diamond_chest", "15x opolisinc:basic_storage_bucks").id('opolicinc:diamond_chest')
    event.recipes.opolisutilities.catalogue("ironchest:crystal_chest", "15x opolisinc:basic_storage_bucks").id('opolicinc:crystal_chest')
    event.recipes.opolisutilities.catalogue("ironchest:obsidian_chest", "15x opolisinc:basic_storage_bucks").id('opolicinc:obsidian_chest')

    //Iron Chest Upgrades
    event.recipes.opolisutilities.catalogue('ironchest:wood_to_iron_chest_upgrade', "5x opolisinc:basic_storage_bucks").id('opolicinc:wood_to_iron_chest_upgrade')
    event.recipes.opolisutilities.catalogue('ironchest:copper_to_iron_chest_upgrade', "1x opolisinc:basic_storage_bucks").id('opolicinc:copper_to_iron_chest_upgrade')
    event.recipes.opolisutilities.catalogue('ironchest:wood_to_copper_chest_upgrade', "4x opolisinc:basic_storage_bucks").id('opolicinc:wood_to_copper_chest_upgrade')
    event.recipes.opolisutilities.catalogue('ironchest:iron_to_gold_chest_upgrade', "2x opolisinc:basic_storage_bucks").id('opolicinc:iron_to_gold_chest_upgrade')
    event.recipes.opolisutilities.catalogue('ironchest:gold_to_diamond_chest_upgrade', "5x opolisinc:basic_storage_bucks").id('opolicinc:gold_to_diamond_chest_upgrade')
    event.recipes.opolisutilities.catalogue('ironchest:diamond_to_obsidian_chest_upgrade', "3x opolisinc:basic_storage_bucks").id('opolicinc:diamond_to_obsidian_chest_upgrade')
    event.recipes.opolisutilities.catalogue('ironchest:diamond_to_crystal_chest_upgrade', "1x opolisinc:basic_storage_bucks").id('opolicinc:diamond_to_crystal_chest_upgrade')

    //Framed Storage
    event.recipes.opolisutilities.catalogue('functionalstorage:compacting_drawer', "3x opolisinc:basic_storage_bucks").id('functionalstorage:compacting_drawer')
    event.recipes.opolisutilities.catalogue('functionalstorage:storage_controller', "12x opolisinc:basic_storage_bucks").id('functionalstorage:storage_controller')
    event.recipes.opolisutilities.catalogue('functionalstorage:controller_extension', "8x opolisinc:basic_storage_bucks").id('functionalstorage:controller_extension')
    event.recipes.opolisutilities.catalogue('functionalstorage:ender_drawer', "8x opolisinc:basic_storage_bucks").id('functionalstorage:ender_drawer')
    event.recipes.opolisutilities.catalogue('functionalstorage:armory_cabinet', "3x opolisinc:basic_storage_bucks").id('functionalstorage:armory_cabinet')
    event.recipes.opolisutilities.catalogue('functionalstorage:simple_compacting_drawer', "3x opolisinc:basic_storage_bucks").id('functionalstorage:simple_compacting_drawer')
    event.recipes.opolisutilities.catalogue('functionalstorage:configuration_tool', "1x opolisinc:basic_storage_bucks").id('functionalstorage:configuration_tool')
    event.recipes.opolisutilities.catalogue('functionalstorage:linking_tool', "1x opolisinc:basic_storage_bucks").id('functionalstorage:linking_tool')

    //Pocket Storage
    event.recipes.opolisutilities.catalogue('pocketstorage:psu_1', "16x opolisinc:basic_storage_bucks").id('pocketstorage:tier1')
    event.recipes.opolisutilities.catalogue('pocketstorage:psu_2', "32x opolisinc:basic_storage_bucks").id('pocketstorage:tier2')
    event.recipes.opolisutilities.catalogue('pocketstorage:psu_3', "20x opolisinc:advanced_storage_bucks").id('pocketstorage:tier3')
    event.recipes.opolisutilities.catalogue('pocketstorage:psu_4', "16x opolisinc:elite_storage_bucks").id('pocketstorage:tier4')

    //AE2 Storage
    event.recipes.opolisutilities.catalogue("ae2:drive", "4x opolisinc:advanced_storage_bucks").id("ae2:network/blocks/storage_drive")
    event.recipes.opolisutilities.catalogue("ae2:item_cell_housing", "4x opolisinc:advanced_storage_bucks").id("ae2:network/cells/item_cell_housing")
    event.recipes.opolisutilities.catalogue("ae2:fluid_cell_housing", "4x opolisinc:advanced_storage_bucks").id("ae2:network/cells/fluid_cell_housing")
    event.recipes.opolisutilities.catalogue("appmek:chemical_cell_housing", "4x opolisinc:advanced_storage_bucks").id("appmek:chemical_cell_housing")

    event.recipes.opolisutilities.catalogue('ae2:controller', "64x opolisinc:elite_storage_bucks").id("ae2:network/blocks/controller")



    event.recipes.opolisutilities.catalogue("ae2:charger", "8x opolisinc:basic_storage_bucks").id("ae2:network/blocks/crystal_processing_charger")

    event.recipes.opolisutilities.catalogue("ae2:condenser", "8x opolisinc:ultimate_storage_bucks").id("ae2:network/blocks/io_condenser")

    event.recipes.opolisutilities.catalogue("ae2:inscriber", "32x opolisinc:basic_storage_bucks").id("ae2:network/blocks/inscribers")

    //Trader Bucks

    event.recipes.opolisutilities.catalogue("easy_villagers:trader", "12x opolisinc:basic_trading_bucks").id('easy_villagers:trader')
    event.recipes.opolisutilities.catalogue("easy_villagers:auto_trader", "20x opolisinc:basic_trading_bucks").id('easy_villagers:auto_trader')
    event.recipes.opolisutilities.catalogue("easy_villagers:breeder", "8x opolisinc:basic_trading_bucks").id('easy_villagers:breeder')
    event.recipes.opolisutilities.catalogue("easy_villagers:converter", "8x opolisinc:basic_trading_bucks").id('easy_villagers:converter')
    event.recipes.opolisutilities.catalogue("easy_villagers:incubator", "8x opolisinc:basic_trading_bucks").id('easy_villagers:incubator')
    event.recipes.opolisutilities.catalogue("easy_villagers:villager", "32x opolisinc:basic_trading_bucks").id('easy_villagers:villager')
    event.recipes.opolisutilities.catalogue("easy_villagers:villager[easy_villagers:villager={Age:-24000}]", "32x opolisinc:basic_trading_bucks").id('easy_villagers:villager_baby')

    event.recipes.opolisutilities.catalogue("easy_piglins:barterer", "8x opolisinc:advanced_trading_bucks").id('easy_piglins:barterer')
    event.recipes.opolisutilities.catalogue('opolisinc:beehive_portal_stabilizer', "64x opolisinc:advanced_trading_bucks").id('opolisinc:beehive_portal_stabilizer')

    event.recipes.opolisutilities.catalogue("opolisinc:end_passport", "64x opolisinc:elite_trading_bucks").id("opolisinc:end_passport")

    event.recipes.opolisutilities.catalogue("opolisinc:transaction_license", "32x opolisinc:elite_trading_bucks").id("opolisinc:transaction_license")




    //Processing Bucks

    event.recipes.opolisutilities.catalogue("minecraft:hopper", "1x opolisinc:basic_processing_bucks").id("opolisinc:catalogue/hopper")

    event.recipes.opolisutilities.catalogue("8x mekanism:basic_mechanical_pipe", "1x opolisinc:basic_processing_bucks").id('mekanism:transmitter/mechanical_pipe/basic')
    event.recipes.opolisutilities.catalogue("8x mekanism:basic_logistical_transporter", "1x opolisinc:basic_processing_bucks").id('mekanism:transmitter/logistical_transporter/basic')
    event.recipes.opolisutilities.catalogue("1x mekanism:configurator", "1x opolisinc:basic_processing_bucks").id('mekanism:configurator')

    event.recipes.opolisutilities.catalogue("1x routers:router_connector", "1x opolisinc:basic_processing_bucks").id('routers:router_connector')
    event.recipes.opolisutilities.catalogue("1x routers:exporter_block", "1x opolisinc:basic_processing_bucks").id('routers:exporter_block')
    event.recipes.opolisutilities.catalogue("1x routers:importer_block", "1x opolisinc:basic_processing_bucks").id('routers:importer_block')

    event.recipes.opolisutilities.catalogue("mekanism:steel_casing", "8x opolisinc:advanced_processing_bucks").id("mekanism:steel_casing")
    event.recipes.opolisutilities.catalogue("squarry:upgrade_fortune_1", "8x opolisinc:advanced_processing_bucks").id("opolisinc:catalogue/upgrade_fortune_1")
    event.recipes.opolisutilities.catalogue("squarry:upgrade_auto_smelt", "8x opolisinc:advanced_processing_bucks").id("opolisinc:catalogue/upgrade_auto_smelt")

    event.recipes.opolisutilities.catalogue("1x mekanism:solar_neutron_activator", "48x opolisinc:elite_processing_bucks").id("mekanism:solar_neutron_activator")
    event.recipes.opolisutilities.catalogue("squarry:upgrade_fortune_2", "12x opolisinc:elite_processing_bucks").id("opolisinc:catalogue/upgrade_fortune_2")

    event.recipes.opolisutilities.catalogue("squarry:upgrade_fortune_3", "16x opolisinc:ultimate_processing_bucks").id("opolisinc:catalogue/upgrade_fortune_3")


    //Bounty Bucks

    event.recipes.opolisutilities.catalogue("iron_sword", "6x opolisinc:basic_bounty_bucks").id("minecraft:iron_sword")
    event.recipes.opolisutilities.catalogue("iron_axe", "10x opolisinc:basic_bounty_bucks").id("minecraft:iron_axe")
    event.recipes.opolisutilities.catalogue("ae2:nether_quartz_sword", "6x opolisinc:basic_bounty_bucks").id("ae2:tools/nether_quartz_sword")
    event.recipes.opolisutilities.catalogue("ae2:nether_quartz_axe", "10x opolisinc:basic_bounty_bucks").id("ae2:tools/nether_quartz_axe")
    event.recipes.opolisutilities.catalogue("ae2:certus_quartz_sword", "6x opolisinc:basic_bounty_bucks").id("ae2:tools/certus_quartz_sword")
    event.recipes.opolisutilities.catalogue("ae2:certus_quartz_axe", "10x opolisinc:basic_bounty_bucks").id("ae2:tools/certus_quartz_axe")
    event.recipes.opolisutilities.catalogue("ae2:fluix_sword", "12x opolisinc:basic_bounty_bucks").id("ae2:tools/fluix_sword")
    event.recipes.opolisutilities.catalogue("ae2:fluix_axe", "20x opolisinc:basic_bounty_bucks").id("ae2:tools/fluix_axe")
    event.recipes.opolisutilities.catalogue("mekanismtools:bronze_sword", "6x opolisinc:basic_bounty_bucks").id("mekanismtools:bronze/tools/sword")
    event.recipes.opolisutilities.catalogue("mekanismtools:bronze_axe", "10x opolisinc:basic_bounty_bucks").id("mekanismtools:bronze/tools/axe")
    event.recipes.opolisutilities.catalogue("mekanismtools:refined_glowstone_sword", "6x opolisinc:basic_bounty_bucks").id("mekanismtools:refined_glowstone/tools/sword")
    event.recipes.opolisutilities.catalogue("mekanismtools:refined_glowstone_axe", "10x opolisinc:basic_bounty_bucks").id("mekanismtools:refined_glowstone/tools/axe")

    event.recipes.opolisutilities.catalogue("diamond_sword", "6x opolisinc:advanced_bounty_bucks").id("minecraft:diamond_sword")
    event.recipes.opolisutilities.catalogue("diamond_axe", "10x opolisinc:advanced_bounty_bucks").id("minecraft:diamond_axe")
    event.recipes.opolisutilities.catalogue("mekanismtools:steel_sword", "6x opolisinc:advanced_bounty_bucks").id("mekanismtools:steel/tools/sword")
    event.recipes.opolisutilities.catalogue("mekanismtools:steel_axe", "10x opolisinc:advanced_bounty_bucks").id("mekanismtools:steel/tools/axe")

    event.recipes.opolisutilities.catalogue("netherite_sword", "6x opolisinc:elite_bounty_bucks").id("minecraft:netherite_sword_smithing")
    event.recipes.opolisutilities.catalogue("netherite_axe", "10x opolisinc:elite_bounty_bucks").id("minecraft:netherite_axe_smithing")
    event.recipes.opolisutilities.catalogue("mekanismtools:osmium_sword", "6x opolisinc:elite_bounty_bucks").id("mekanismtools:osmium/tools/sword")
    event.recipes.opolisutilities.catalogue("mekanismtools:osmium_axe", "10x opolisinc:elite_bounty_bucks").id("mekanismtools:osmium/tools/axe")

    event.recipes.opolisutilities.catalogue("mekanismtools:refined_obsidian_sword", "6x opolisinc:ultimate_bounty_bucks").id("mekanismtools:refined_obsidian/tools/sword")
    event.recipes.opolisutilities.catalogue("mekanismtools:refined_obsidian_axe", "10x opolisinc:ultimate_bounty_bucks").id("mekanismtools:refined_obsidian/tools/axe")

    event.recipes.opolisutilities.catalogue("mysticalagriculture:cognizant_dust", "8x opolisinc:ultimate_bounty_bucks").id("opolisinc:cognizant_dust")



    //Tools

    event.recipes.opolisutilities.catalogue("opolisutilities:wooden_shears", "1x opolisutilities:b_bucks").id('opolisutilities:wooden_shears')
    event.recipes.opolisutilities.catalogue("3x minecraft:apple", "1x opolisutilities:b_bucks").id('opolisinc:apple')
    event.recipes.opolisutilities.catalogue("opolisutilities:sapling_grower", "12x opolisutilities:b_bucks").id('opolisinc:sapling_grower')
    event.recipes.opolisutilities.catalogue("3x minecraft:sugar_cane", "2x opolisutilities:b_bucks").id('opolisinc:sugar_cane')
    event.recipes.opolisutilities.catalogue("1x opolisutilities:home_stone", "4x opolisutilities:b_bucks").id('opolisinc:home_stone')
    event.recipes.opolisutilities.catalogue("1x pipe_connector:pipe_connector", "4x opolisutilities:b_bucks").id('pipe_connector:pipe_connector')

    event.recipes.opolisutilities.catalogue("minecraft:stone_pickaxe", "1x opolisutilities:b_bucks").id('minecraft:stone_pickaxe')
    event.recipes.opolisutilities.catalogue("mekanismtools:lapis_lazuli_pickaxe", "1x opolisutilities:b_bucks").id("mekanismtools:lapis_lazuli/tools/pickaxe")
    event.recipes.opolisutilities.catalogue("minecraft:stone_axe", "1x opolisutilities:b_bucks").id('minecraft:stone_axe')
    event.recipes.opolisutilities.catalogue("mekanismtools:lapis_lazuli_axe", "1x opolisutilities:b_bucks").id("mekanismtools:lapis_lazuli/tools/axe")
    event.recipes.opolisutilities.catalogue("minecraft:stone_shovel", "1x opolisutilities:b_bucks").id('minecraft:stone_shovel')
    event.recipes.opolisutilities.catalogue("mekanismtools:lapis_lazuli_shovel", "1x opolisutilities:b_bucks").id("mekanismtools:lapis_lazuli/tools/shovel")
    event.recipes.opolisutilities.catalogue("minecraft:stone_hoe", "1x opolisutilities:b_bucks").id('minecraft:stone_hoe')
    event.recipes.opolisutilities.catalogue("mekanismtools:lapis_lazuli_hoe", "1x opolisutilities:b_bucks").id("mekanismtools:lapis_lazuli/tools/hoe")
    event.recipes.opolisutilities.catalogue("minecraft:stone_sword", "1x opolisutilities:b_bucks").id('minecraft:stone_sword')
    event.recipes.opolisutilities.catalogue("mekanismtools:lapis_lazuli_sword", "1x opolisutilities:b_bucks").id("mekanismtools:lapis_lazuli/tools/sword")

    event.recipes.opolisutilities.catalogue("opolisutilities:portable_gui", "3x opolisutilities:b_bucks").id('opolisutilities:portable_gui')

    event.recipes.opolisutilities.catalogue("minecraft:shears", "2x opolisinc:basic_mining_bucks").id('minecraft:shears')



    //Armor
    event.recipes.opolisutilities.catalogue("minecraft:iron_helmet", "15x opolisinc:basic_mining_bucks").id('minecraft:iron_helmet')
    event.recipes.opolisutilities.catalogue("minecraft:iron_chestplate", "24x opolisinc:basic_mining_bucks").id('minecraft:iron_chestplate')
    event.recipes.opolisutilities.catalogue("minecraft:iron_leggings", "21x opolisinc:basic_mining_bucks").id('minecraft:iron_leggings')
    event.recipes.opolisutilities.catalogue("minecraft:iron_boots", "12x opolisinc:basic_mining_bucks").id('minecraft:iron_boots')

    event.recipes.opolisutilities.catalogue("minecraft:diamond_helmet", "8x opolisinc:elite_mining_bucks").id('minecraft:diamond_helmet')
    event.recipes.opolisutilities.catalogue("minecraft:diamond_chestplate", "12x opolisinc:elite_mining_bucks").id('minecraft:diamond_chestplate')
    event.recipes.opolisutilities.catalogue("minecraft:diamond_leggings", "10x opolisinc:elite_mining_bucks").id('minecraft:diamond_leggings')
    event.recipes.opolisutilities.catalogue("minecraft:diamond_boots", "6x opolisinc:elite_mining_bucks").id('minecraft:diamond_boots')

    //Farming Bucks
    event.recipes.opolisutilities.catalogue("cloche:cloche", "5x opolisinc:basic_farming_bucks").id('cloche:cloche')
    event.recipes.opolisutilities.catalogue("farmersdelight:organic_compost", "2x opolisinc:basic_farming_bucks").id('farmersdelight:organic_compost_from_rotten_flesh')
    event.recipes.opolisutilities.catalogue("iron_hoe", "6x opolisinc:basic_farming_bucks").id("minecraft:iron_hoe")
    event.recipes.opolisutilities.catalogue("ae2:nether_quartz_hoe", "6x opolisinc:basic_farming_bucks").id("ae2:tools/nether_quartz_hoe")
    event.recipes.opolisutilities.catalogue("ae2:certus_quartz_hoe", "6x opolisinc:basic_farming_bucks").id("ae2:tools/certus_quartz_hoe")
    event.recipes.opolisutilities.catalogue("ae2:fluix_hoe", "12x opolisinc:basic_farming_bucks").id("ae2:tools/fluix_hoe")
    event.recipes.opolisutilities.catalogue("mekanismtools:bronze_hoe", "6x opolisinc:basic_farming_bucks").id("mekanismtools:bronze/tools/hoe")
    event.recipes.opolisutilities.catalogue("mekanismtools:refined_glowstone_hoe", "6x opolisinc:basic_farming_bucks").id("mekanismtools:refined_glowstone/tools/hoe")
    event.recipes.opolisutilities.catalogue("bblcore:upgrade_base", "3x opolisinc:basic_farming_bucks").id("opolisinc:upgrade_base")

    event.recipes.opolisutilities.catalogue("mysticalagriculture:infusion_altar", "8x opolisinc:advanced_farming_bucks").id('mysticalagriculture:infusion_altar')
    event.recipes.opolisutilities.catalogue("2x mysticalagriculture:infusion_pedestal", "1x opolisinc:advanced_farming_bucks").id('mysticalagriculture:infusion_pedestal')
    event.recipes.opolisutilities.catalogue("diamond_hoe", "6x opolisinc:advanced_farming_bucks").id("minecraft:diamond_hoe")
    event.recipes.opolisutilities.catalogue("mekanismtools:steel_hoe", "6x opolisinc:advanced_farming_bucks").id("mekanismtools:steel/tools/hoe")

    event.recipes.opolisutilities.catalogue("mysticalagriculture:sky_stone_seeds", "4x opolisinc:elite_farming_bucks").id('mysticalagriculture:sky_stone_seeds')
    event.recipes.opolisutilities.catalogue("ae2:damaged_budding_quartz", "6x opolisinc:elite_farming_bucks").id('opolisinc:damaged_budding_quartz')
    event.recipes.opolisutilities.catalogue("netherite_hoe", "6x opolisinc:elite_farming_bucks").id("minecraft:netherite_hoe_smithing")
    event.recipes.opolisutilities.catalogue("mekanismtools:osmium_hoe", "6x opolisinc:elite_farming_bucks").id("mekanismtools:osmium/tools/hoe")

    event.recipes.opolisutilities.catalogue("mekanismtools:refined_obsidian_hoe", "6x opolisinc:ultimate_farming_bucks").id("mekanismtools:refined_obsidian/tools/hoe")


    //Misc Catalogue

    event.recipes.opolisutilities.catalogue("opolisinc:nuclear_license", "32x opolisinc:elite_power_bucks").id("opolisinc:nuclear_license")
    event.recipes.opolisutilities.catalogue("opolisinc:data_license", "32x opolisinc:elite_storage_bucks").id("opolisinc:data_license")


    //Licenses



})
