ServerEvents.recipes(event => {

    // Custom compacting for Mini Coal -> Coal (8:1 ratio)
    event.custom({
        type: 'functionalstorage:custom_compacting',
        lower_input: {
            id: 'opolisutilities:mini_coal',
            count: 8
        },
        higher_input: {
            id: 'minecraft:coal',
            count: 1
        }
    }).id('opolisinc:compacting/mini_coal')

    // Custom compacting for Mini Charcoal -> Charcoal (8:1 ratio)
    event.custom({
        type: 'functionalstorage:custom_compacting',
        lower_input: {
            id: 'opolisutilities:mini_charcoal',
            count: 8
        },
        higher_input: {
            id: 'minecraft:charcoal',
            count: 1
        }
    }).id('opolisinc:compacting/mini_charcoal')

})
