console.info('Loading ore_processing.js for Opolis Inc')

ServerEvents.recipes(event => {
    // Helpers
    const rawMetalName = (rawId) => {
        // rawId example: minecraft:raw_iron / alltheores:raw_aluminum
        const path = rawId.split(':')[1]
        return path.replace('raw_', '')
    }

    const safeId = (s) =>
        String(s)
            .toLowerCase()
            .replace(/^#/, '')               // remove tag marker
            .replace(/[^a-z0-9._-]/g, '_')   // resource-location safe


    /**
     * Metal ore processing:
     * - Shapeless hammer recipe -> raw output (scaled by multiplier)
     * - Shapeless hammer recipe -> dust from raw output (basic processing bucks)
     * - Mekanism combiner recipes -> more raw output from ore + mining bucks
     * - Mekanism combiner recipes -> dirty/clump/shard/crystal from raw + processing bucks
     */
    function metalOreProcessing(rawOutput, oreInput, multiplier) {
        const metal = rawMetalName(rawOutput)

        // Hammer -> raw
        event
            .shapeless(Item.of(rawOutput, 2 * multiplier), [
                oreInput,
                'opolisinc:basic_mining_bucks',
                '#alltheores:ore_hammers'
            ])
            .damageIngredient('#alltheores:ore_hammers', 1)
            .id(`opolisinc:hammer/${safeId(metal)}_ore_to_raw`)

        // Hammer -> dust (uses the raw output item as input)
        event
            .shapeless(Item.of(`alltheores:${metal}_dust`, 2), [
                rawOutput,
                'opolisinc:basic_processing_bucks',
                '#alltheores:ore_hammers'
            ])
            .damageIngredient('#alltheores:ore_hammers', 1)
            .id(`opolisinc:hammer/${safeId(metal)}_raw_to_dust`)

        // Mekanism combiner (ore -> more raw) using mining bucks
        event.recipes.mekanism.combining(Item.of(rawOutput, 2 * multiplier), oreInput, 'opolisinc:basic_mining_bucks').id(`opolisinc:mekanism/combining/${safeId(metal)}_ore_basic`)
        event.recipes.mekanism.combining(Item.of(rawOutput, 3 * multiplier), oreInput, 'opolisinc:advanced_mining_bucks').id(`opolisinc:mekanism/combining/${safeId(metal)}_ore_advanced`)
        event.recipes.mekanism.combining(Item.of(rawOutput, 4 * multiplier), oreInput, 'opolisinc:elite_mining_bucks').id(`opolisinc:mekanism/combining/${safeId(metal)}_ore_elite`)
        event.recipes.mekanism.combining(Item.of(rawOutput, 5 * multiplier), oreInput, 'opolisinc:ultimate_mining_bucks').id(`opolisinc:mekanism/combining/${safeId(metal)}_ore_ultimate`)

        // Determine Mekanism vs AllTheOres naming for secondary outputs
        const namespace = rawOutput.split(':')[0]
        let dirtyOutput, clumpOutput, shardOutput, crystalOutput

        if (namespace === 'minecraft') {
            dirtyOutput = `mekanism:dirty_dust_${metal}`
            clumpOutput = `mekanism:clump_${metal}`
            shardOutput = `mekanism:shard_${metal}`
            crystalOutput = `mekanism:crystal_${metal}`
        } else {
            dirtyOutput = `alltheores:dirty_${metal}_dust`
            clumpOutput = `alltheores:${metal}_clump`
            shardOutput = `alltheores:${metal}_shard`
            crystalOutput = `alltheores:${metal}_crystal`
        }

        // Mekanism combiner (raw -> processing chain) using processing bucks
        event.recipes.mekanism.combining(Item.of(dirtyOutput, 2), rawOutput, 'opolisinc:basic_processing_bucks').id(`opolisinc:mekanism/combining/${safeId(metal)}_raw_to_dirty`)
        event.recipes.mekanism.combining(Item.of(clumpOutput, 3), rawOutput, 'opolisinc:advanced_processing_bucks').id(`opolisinc:mekanism/combining/${safeId(metal)}_raw_to_clump`)
        event.recipes.mekanism.combining(Item.of(shardOutput, 4), rawOutput, 'opolisinc:elite_processing_bucks').id(`opolisinc:mekanism/combining/${safeId(metal)}_raw_to_shard`)
        event.recipes.mekanism.combining(Item.of(crystalOutput, 5), rawOutput, 'opolisinc:ultimate_processing_bucks').id(`opolisinc:mekanism/combining/${safeId(metal)}_raw_to_crystal`)
    }

    // Metals (ores -> raw items)
    metalOreProcessing('minecraft:raw_iron', '#c:ores/iron', 1)
    metalOreProcessing('minecraft:raw_copper', '#c:ores/copper', 4)
    metalOreProcessing('minecraft:raw_gold', '#c:ores/gold', 1)

    metalOreProcessing('alltheores:raw_aluminum', '#c:ores/aluminum', 1)
    metalOreProcessing('alltheores:raw_lead', '#c:ores/lead', 1)
    metalOreProcessing('alltheores:raw_nickel', '#c:ores/nickel', 1)
    metalOreProcessing('alltheores:raw_osmium', '#c:ores/osmium', 1)
    metalOreProcessing('alltheores:raw_platinum', '#c:ores/platinum', 1)
    metalOreProcessing('alltheores:raw_silver', '#c:ores/silver', 1)
    metalOreProcessing('alltheores:raw_tin', '#c:ores/tin', 1)
    metalOreProcessing('alltheores:raw_uranium', '#c:ores/uranium', 1)
    metalOreProcessing('alltheores:raw_zinc', '#c:ores/zinc', 1)
    metalOreProcessing('alltheores:raw_iridium', '#c:ores/iridium', 1)

    // Non-metal ore processing:
    // - Hammer -> output
    // - Mekanism combiner -> output with mining bucks
    function nonMetalOreProcessing(output, oreTag, multiplier) {
        event
            .shapeless(Item.of(output, 2 * multiplier), [
                oreTag,
                'opolisinc:basic_mining_bucks',
                '#alltheores:ore_hammers'
            ])
            .damageIngredient('#alltheores:ore_hammers', 1)
            .id(`opolisinc:hammer/${safeId(output)}_from_${safeId(oreTag)}`)

        event.recipes.mekanism
            .combining(Item.of(output, 2 * multiplier), oreTag, 'opolisinc:basic_mining_bucks')
            .id(`opolisinc:mekanism/combining/${safeId(output)}_basic`)

        event.recipes.mekanism
            .combining(Item.of(output, 4 * multiplier), oreTag, 'opolisinc:advanced_mining_bucks')
            .id(`opolisinc:mekanism/combining/${safeId(output)}_advanced`)

        event.recipes.mekanism
            .combining(Item.of(output, 6 * multiplier), oreTag, 'opolisinc:elite_mining_bucks')
            .id(`opolisinc:mekanism/combining/${safeId(output)}_elite`)

        event.recipes.mekanism
            .combining(Item.of(output, 8 * multiplier), oreTag, 'opolisinc:ultimate_mining_bucks')
            .id(`opolisinc:mekanism/combining/${safeId(output)}_ultimate`)
    }

    nonMetalOreProcessing('minecraft:redstone', '#c:ores/redstone', 5)
    nonMetalOreProcessing('minecraft:coal', '#c:ores/coal', 1)
    nonMetalOreProcessing('minecraft:emerald', '#c:ores/emerald', 1)
    nonMetalOreProcessing('minecraft:diamond', '#c:ores/diamond', 1)
    nonMetalOreProcessing('minecraft:lapis_lazuli', '#c:ores/lapis', 3)
    nonMetalOreProcessing('mysticalagriculture:prosperity_shard', '#c:ores/prosperity', 2)

        // Nether Quartz (ore -> quartz)
        ;[
            ['opolisinc:basic_mining_bucks', 3, 'basic'],
            ['opolisinc:advanced_mining_bucks', 6, 'advanced'],
            ['opolisinc:elite_mining_bucks', 9, 'elite'],
            ['opolisinc:ultimate_mining_bucks', 12, 'ultimate']
        ].forEach(([buck, outCount, tier]) => {
            event.recipes.mekanism
                .combining(Item.of('minecraft:quartz', outCount), 'minecraft:nether_quartz_ore', buck)
                .id(`opolisinc:mekanism/combining/nether_quartz_${tier}`)
        })

        // Ancient Debris -> dirty netherite scrap
        ;[
            ['opolisinc:basic_mining_bucks', 2, 'basic'],
            ['opolisinc:advanced_mining_bucks', 3, 'advanced'],
            ['opolisinc:elite_mining_bucks', 4, 'elite'],
            ['opolisinc:ultimate_mining_bucks', 5, 'ultimate']
        ].forEach(([buck, outCount, tier]) => {
            event.recipes.mekanism
                .combining(Item.of('mekanism:dirty_netherite_scrap', outCount), 'minecraft:ancient_debris', buck)
                .id(`opolisinc:mekanism/combining/ancient_debris_${tier}`)
        })

        // Dirty netherite scrap -> netherite scrap (processing bucks)
        ;[
            ['opolisinc:basic_processing_bucks', 2, 'basic'],
            ['opolisinc:advanced_processing_bucks', 3, 'advanced'],
            ['opolisinc:elite_processing_bucks', 4, 'elite'],
            ['opolisinc:ultimate_processing_bucks', 5, 'ultimate']
        ].forEach(([buck, outCount, tier]) => {
            event.recipes.mekanism
                .combining(Item.of('minecraft:netherite_scrap', outCount), 'mekanism:dirty_netherite_scrap', buck)
                .id(`opolisinc:mekanism/combining/dirty_netherite_scrap_${tier}`)
        })

        // Powah uraninite raw -> uraninite (processing bucks)
        ;[
            ['opolisinc:basic_processing_bucks', 2, 'basic'],
            ['opolisinc:advanced_processing_bucks', 3, 'advanced'],
            ['opolisinc:elite_processing_bucks', 4, 'elite'],
            ['opolisinc:ultimate_processing_bucks', 5, 'ultimate']
        ].forEach(([buck, outCount, tier]) => {
            event.recipes.mekanism
                .combining(Item.of('powah:uraninite', outCount), 'powah:uraninite_raw', buck)
                .id(`opolisinc:mekanism/combining/uraninite_raw_${tier}`)
        })

    // Activated ores -> 2x raw (Mekanism enriching)
    function activatedOreProcessing(input, output) {
        event.recipes.mekanism
            .enriching(Item.of(output, 2), input)
            .id(`opolisinc:mekanism/enriching/${safeId(input)}`)
    }

    activatedOreProcessing('opolisinc:activated_raw_iron', 'minecraft:raw_iron')
    activatedOreProcessing('opolisinc:activated_raw_copper', 'minecraft:raw_copper')
    activatedOreProcessing('opolisinc:activated_raw_gold', 'minecraft:raw_gold')

    activatedOreProcessing('opolisinc:activated_raw_aluminum', 'alltheores:raw_aluminum')
    activatedOreProcessing('opolisinc:activated_raw_lead', 'alltheores:raw_lead')
    activatedOreProcessing('opolisinc:activated_raw_nickel', 'alltheores:raw_nickel')
    activatedOreProcessing('opolisinc:activated_raw_osmium', 'alltheores:raw_osmium')
    activatedOreProcessing('opolisinc:activated_raw_platinum', 'alltheores:raw_platinum')
    activatedOreProcessing('opolisinc:activated_raw_silver', 'alltheores:raw_silver')
    activatedOreProcessing('opolisinc:activated_raw_tin', 'alltheores:raw_tin')
    activatedOreProcessing('opolisinc:activated_raw_uranium', 'alltheores:raw_uranium')
    activatedOreProcessing('opolisinc:activated_raw_zinc', 'alltheores:raw_zinc')
    activatedOreProcessing('opolisinc:activated_raw_iridium', 'alltheores:raw_iridium')
})
