console.info('Loading extended_crafting.js for Opolis Inc')

ServerEvents.recipes(event => {
    event.custom({
        type: "extendedcrafting:compressor",
        power_cost: 1000000,
        ingredient: { item: "opolisinc:miniaturised_planetoid", count: 16 },
        catalyst: { item: "opolisinc:ultimate_mining_bucks" },
        result: { id: "opolisinc:galactic_simulator", count: 1 }
    }).id("opolisinc:compressor/galactic_simulator")

    event.custom({
        type: "extendedcrafting:compressor",
        power_cost: 1000000,
        ingredient: { item: "opolisinc:opolisite_circuit_board", count: 16 },
        catalyst: { item: "opolisinc:ultimate_processing_bucks" },
        result: { id: "opolisinc:central_routing_node", count: 1 }
    }).id("opolisinc:compressor/central_routing_node")

    event.custom({
        type: "extendedcrafting:compressor",
        power_cost: 1000000,
        ingredient: { item: "opolisinc:quantum_encoded_storage_component", count: 16 },
        catalyst: { item: "opolisinc:ultimate_storage_bucks" },
        result: { id: "opolisinc:superposition_storage_drive", count: 1 }
    }).id("opolisinc:compressor/superposition_storage_drive")

    event.custom({
        type: "extendedcrafting:compressor",
        power_cost: 1000000,
        ingredient: { item: "opolisinc:cosmic_roots", count: 16 },
        catalyst: { item: "opolisinc:ultimate_farming_bucks" },
        result: { id: "opolisinc:universal_adapter", count: 1 }
    }).id("opolisinc:compressor/universal_adapter")

    event.custom({
        type: "extendedcrafting:compressor",
        power_cost: 1000000,
        ingredient: { item: "opolisinc:mutated_supercell", count: 16 },
        catalyst: { item: "opolisinc:ultimate_bounty_bucks" },
        result: { id: "opolisinc:bio_neural_processor", count: 1 }
    }).id("opolisinc:compressor/bio_neural_processor")

    event.custom({
        type: "extendedcrafting:compressor",
        power_cost: 1000000,
        ingredient: { item: "opolisinc:nitro_temporal_lattice", count: 16 },
        catalyst: { item: "opolisinc:ultimate_power_bucks" },
        result: { id: "opolisinc:time_crystal_power_conduit", count: 1 }
    }).id("opolisinc:compressor/time_crystal_power_conduit")

    event.custom({
        type: "extendedcrafting:compressor",
        power_cost: 1000000,
        ingredient: { item: "opolisinc:interdimensional_transactor", count: 16 },
        catalyst: { item: "opolisinc:ultimate_trading_bucks" },
        result: { id: "opolisinc:nebulous_negotiator", count: 1 }
    }).id("opolisinc:compressor/nebulous_negotiator")


    function specialisedLicenseCrafting(input, catalyst) {
        var output_license
        if (input.split(":").length == 1) {
            output_license = input
        } else {
            output_license = input.split(":")[1]
        }

        if (output_license.split("_").length > 1) {
            if (output_license.split("_")[output_license.split("_").length - 1] == "ingot") {
                output_license = output_license.split("_")[0]
            }
        }

        event.custom(
            {
                type: "extendedcrafting:compressor",
                power_cost: 10000,
                ingredient: { item: input, count: 256 },
                catalyst: { item: "opolisinc:unbreakable_" + catalyst + "_license" },
                result: { id: SL(output_license), count: 1 }
            }
        ).id("opolisinc:compressor/specialised_license_" + output_license)
    }

    specialisedLicenseCrafting("cobblestone", "basic_mining")
    specialisedLicenseCrafting("sand", "basic_mining")
    specialisedLicenseCrafting("dirt", "basic_mining")

    specialisedLicenseCrafting("raw_iron", "advanced_mining")
    specialisedLicenseCrafting("raw_copper", "advanced_mining")
    specialisedLicenseCrafting("lapis_lazuli", "advanced_mining")
    specialisedLicenseCrafting("alltheores:raw_tin", "advanced_mining")
    specialisedLicenseCrafting("alltheores:raw_aluminum", "advanced_mining")
    specialisedLicenseCrafting("alltheores:cinnabar", "advanced_mining")

    specialisedLicenseCrafting("diamond", "elite_mining")
    specialisedLicenseCrafting("emerald", "elite_mining")
    specialisedLicenseCrafting("quartz", "elite_mining")
    specialisedLicenseCrafting("ancient_debris", "elite_mining")
    specialisedLicenseCrafting("alltheores:raw_platinum", "elite_mining")

    specialisedLicenseCrafting("opolisinc:activated_raw_gold", "ultimate_mining")
    specialisedLicenseCrafting("opolisinc:activated_raw_nickel", "ultimate_mining")
    specialisedLicenseCrafting("opolisinc:activated_raw_uranium", "ultimate_mining")
    specialisedLicenseCrafting("opolisinc:activated_raw_osmium", "ultimate_mining")
    specialisedLicenseCrafting("opolisinc:activated_raw_zinc", "ultimate_mining")
    specialisedLicenseCrafting("opolisinc:activated_raw_silver", "ultimate_mining")
    specialisedLicenseCrafting("opolisinc:activated_raw_lead", "ultimate_mining")

    specialisedLicenseCrafting("iron_ingot", "basic_processing")
    specialisedLicenseCrafting("copper_ingot", "basic_processing")
    specialisedLicenseCrafting("alltheores:tin_ingot", "basic_processing")
    specialisedLicenseCrafting("alltheores:aluminum_ingot", "basic_processing")
    specialisedLicenseCrafting("alltheores:lead_ingot", "basic_processing")
    specialisedLicenseCrafting("alltheores:nickel_ingot", "basic_processing")
    specialisedLicenseCrafting("alltheores:zinc_ingot", "basic_processing")
    specialisedLicenseCrafting("alltheores:silver_ingot", "basic_processing")
    specialisedLicenseCrafting("glass", "basic_processing")

    specialisedLicenseCrafting("alltheores:steel_ingot", "advanced_processing")
    specialisedLicenseCrafting("alltheores:bronze_ingot", "advanced_processing")
    specialisedLicenseCrafting("alltheores:brass_ingot", "advanced_processing")
    specialisedLicenseCrafting("alltheores:constantan_ingot", "advanced_processing")
    specialisedLicenseCrafting("alltheores:invar_ingot", "advanced_processing")
    specialisedLicenseCrafting("alltheores:electrum_ingot", "advanced_processing")
    event.custom(
        {
            type: "extendedcrafting:compressor",
            power_cost: 10000,
            ingredient: { item: "mekanism:alloy_infused", count: 256 },
            catalyst: { item: "opolisinc:unbreakable_advanced_processing_license" },
            result: { id: SL("infused_alloy"), count: 1 }
        }
    ).id("opolisinc:compressor/specialised_license_infused_alloy")

    specialisedLicenseCrafting("alltheores:lumium_ingot", "elite_processing")
    specialisedLicenseCrafting("alltheores:signalum_ingot", "elite_processing")
    specialisedLicenseCrafting("alltheores:enderium_ingot", "elite_processing")
    event.custom(
        {
            type: "extendedcrafting:compressor",
            power_cost: 10000,
            ingredient: { item: "mekanism:alloy_reinforced", count: 256 },
            catalyst: { item: "opolisinc:unbreakable_elite_processing_license" },
            result: { id: SL("reinforced_alloy"), count: 1 }
        }
    ).id("opolisinc:compressor/specialised_license_reinforced_alloy")

    event.custom(
        {
            type: "extendedcrafting:compressor",
            power_cost: 10000,
            ingredient: { item: "opolisinc:activated_signalum_ingot", count: 256 },
            catalyst: { item: "opolisinc:unbreakable_ultimate_processing_license" },
            result: { id: SL("activated_signalum"), count: 1 }
        }
    ).id("opolisinc:compressor/specialised_license_activated_signalum")
    event.custom(
        {
            type: "extendedcrafting:compressor",
            power_cost: 10000,
            ingredient: { item: "opolisinc:activated_lumium_ingot", count: 256 },
            catalyst: { item: "opolisinc:unbreakable_ultimate_processing_license" },
            result: { id: SL("activated_lumium"), count: 1 }
        }
    ).id("opolisinc:compressor/specialised_license_activated_lumium")
    event.custom(
        {
            type: "extendedcrafting:compressor",
            power_cost: 10000,
            ingredient: { item: "opolisinc:activated_enderium_ingot", count: 256 },
            catalyst: { item: "opolisinc:unbreakable_ultimate_processing_license" },
            result: { id: SL("activated_enderium"), count: 1 }
        }
    ).id("opolisinc:compressor/specialised_license_activated_enderium")

    specialisedLicenseCrafting("coal", "basic_power")
    specialisedLicenseCrafting("redstone", "basic_power")
    event.custom(
        {
            type: "extendedcrafting:compressor",
            power_cost: 10000,
            ingredient: { item: "powah:capacitor_niotic", count: 256 },
            catalyst: { item: "opolisinc:unbreakable_ultimate_power_license" },
            result: { id: SL("niotic_capacitor"), count: 1 }
        }
    ).id("opolisinc:compressor/specialised_license_niotic_capacitor")
    event.custom(
        {
            type: "extendedcrafting:compressor",
            power_cost: 10000,
            ingredient: { item: "powah:capacitor_spirited", count: 256 },
            catalyst: { item: "opolisinc:unbreakable_ultimate_power_license" },
            result: { id: SL("spirited_capacitor"), count: 1 }
        }
    ).id("opolisinc:compressor/specialised_license_spirited_capacitor")

    specialisedLicenseCrafting("chicken", "basic_bounty")
    specialisedLicenseCrafting("porkchop", "basic_bounty")
    specialisedLicenseCrafting("leather", "basic_bounty")
    specialisedLicenseCrafting("beef", "basic_bounty")
    specialisedLicenseCrafting("mutton", "basic_bounty")
    specialisedLicenseCrafting("ink_sac", "basic_bounty")
    specialisedLicenseCrafting("feather", "basic_bounty")

    specialisedLicenseCrafting("rotten_flesh", "advanced_bounty")
    specialisedLicenseCrafting("bone", "advanced_bounty")
    specialisedLicenseCrafting("gunpowder", "advanced_bounty")
    specialisedLicenseCrafting("spider_eye", "advanced_bounty")
    specialisedLicenseCrafting("arrow", "advanced_bounty")
    specialisedLicenseCrafting("ender_pearl", "advanced_bounty")
    specialisedLicenseCrafting("breeze_rod", "advanced_bounty")

    specialisedLicenseCrafting("blaze_rod", "elite_bounty")
    specialisedLicenseCrafting("ghast_tear", "elite_bounty")
    specialisedLicenseCrafting("opolisinc:withered_bone", "elite_bounty")

    specialisedLicenseCrafting("shulker_shell", "ultimate_bounty")
    specialisedLicenseCrafting("opolisinc:activated_ender_pearl", "ultimate_bounty")

    specialisedLicenseCrafting("opolisinc:villager_receipt_1", "basic_trading")
    specialisedLicenseCrafting("opolisinc:villager_receipt_2", "basic_trading")
    specialisedLicenseCrafting("opolisinc:villager_receipt_3", "basic_trading")
    specialisedLicenseCrafting("opolisinc:villager_receipt_4", "basic_trading")
    specialisedLicenseCrafting("opolisinc:villager_receipt_5", "basic_trading")

    event.custom(
        {
            type: "extendedcrafting:compressor",
            power_cost: 10000,
            ingredient: { tag: "c:chests/wooden", count: 256 },
            catalyst: { item: "opolisinc:unbreakable_basic_storage_license" },
            result: { id: SL("chest"), count: 1 }
        }
    ).id("opolisinc:compressor/specialised_license_chest")
    event.custom(
        {
            type: "extendedcrafting:compressor",
            power_cost: 10000,
            ingredient: { tag: "minecraft:logs", count: 256 },
            catalyst: { item: "opolisinc:unbreakable_basic_storage_license" },
            result: { id: SL("wood"), count: 1 }
        }
    ).id("opolisinc:compressor/specialised_license_wood")

    specialisedLicenseCrafting("ae2:cell_component_16k", "elite_storage")
    event.custom(
        {
            type: "extendedcrafting:compressor",
            power_cost: 10000,
            ingredient: { item: "extendedae:entro_ingot", count: 256 },
            catalyst: { item: "opolisinc:unbreakable_elite_storage_license" },
            result: { id: SL("entro_ingot"), count: 1 }
        }
    ).id("opolisinc:compressor/specialised_license_entro_ingot")

    specialisedLicenseCrafting("wheat", "basic_farming")
    specialisedLicenseCrafting("carrot", "basic_farming")
    specialisedLicenseCrafting("potato", "basic_farming")
    specialisedLicenseCrafting("beetroot", "basic_farming")


    specialisedLicenseCrafting("opolisinc:sculked_wheat", "advanced_farming")
    specialisedLicenseCrafting("opolisinc:sculked_carrot", "advanced_farming")
    specialisedLicenseCrafting("opolisinc:sculked_potato", "advanced_farming")
    specialisedLicenseCrafting("opolisinc:sculked_beetroot", "advanced_farming")

    specialisedLicenseCrafting("weeping_vines", "elite_farming")
    specialisedLicenseCrafting("twisting_vines", "elite_farming")

    specialisedLicenseCrafting("opolisinc:phased_wheat", "ultimate_farming")
    specialisedLicenseCrafting("opolisinc:phased_carrot", "ultimate_farming")
    specialisedLicenseCrafting("opolisinc:phased_potato", "ultimate_farming")
    specialisedLicenseCrafting("opolisinc:phased_beetroot", "ultimate_farming")
})