console.info('Loading mekanism.js for Opolis Inc')

ServerEvents.recipes(event => {

   // Smelting
   event.recipes.mekanism.smelting('minecraft:glass', '#minecraft:sand').id("opolisinc:smelting/glass")

   // Power License - Metallurgic Infusing
   event.recipes.mekanism.metallurgic_infusing('opolisinc:basic_power_license', 'opolisinc:starting_license', '100x #mekanism:redstone').id('opolisinc:basic_power_license')
   event.recipes.mekanism.metallurgic_infusing('opolisinc:basic_bounty_license', '9x opolisinc:basic_bounty_fragment', '10x #mekanism:redstone').id('opolisinc:basic_bounty_license')
   event.recipes.mekanism.metallurgic_infusing('opolisinc:advanced_bounty_license', '9x opolisinc:advanced_bounty_fragment', '20x #mekanism:redstone').id('opolisinc:advanced_bounty_license')
   event.recipes.mekanism.metallurgic_infusing('opolisinc:elite_bounty_license', '9x opolisinc:elite_bounty_fragment', '40x #mekanism:redstone').id('opolisinc:elite_bounty_license')
   event.recipes.mekanism.metallurgic_infusing('opolisinc:ultimate_bounty_license', '9x opolisinc:ultimate_bounty_fragment', '80x #mekanism:redstone').id('opolisinc:ultimate_bounty_license')
   event.recipes.mekanism.metallurgic_infusing('2x powah:dielectric_paste', '#c:dusts/coal', '10x #mekanism:gold').id('powah:dielectric_paste')

   // Dielectric Paste using Power Bucks
   event.recipes.mekanism.metallurgic_infusing('4x powah:dielectric_paste', 'opolisinc:basic_power_bucks', '20x #mekanism:carbon').id("opolisinc:infusing/basic_dielectric_paste")
   event.recipes.mekanism.metallurgic_infusing('8x powah:dielectric_paste', 'opolisinc:advanced_power_bucks', '20x #mekanism:carbon').id("opolisinc:infusing/advanced_dielectric_paste")
   event.recipes.mekanism.metallurgic_infusing('12x powah:dielectric_paste', 'opolisinc:elite_power_bucks', '20x #mekanism:carbon').id("opolisinc:infusing/elite_dielectric_paste")
   event.recipes.mekanism.metallurgic_infusing('16x powah:dielectric_paste', 'opolisinc:ultimate_power_bucks', '20x #mekanism:carbon').id("opolisinc:infusing/ultimate_dielectric_paste")

   // Nuclear Waste and the Demon Core (Keep as event.custom - not supported by addon)
   event.custom({
      type: "mekanism:rotary",
      chemical_input: {
         chemical: "mekanism:nuclear_waste",
         amount: 1
      },
      chemical_output: {
         id: "mekanism:nuclear_waste",
         amount: 1
      },
      fluid_input: {
         amount: 1,
         fluid: "opolisinc:nuclear_waste"
      },
      fluid_output: {
         amount: 1,
         id: "opolisinc:nuclear_waste"
      }
   }).id("opolisinc:mekanism/nuclear_waste_condensentrating")

   event.custom({
      type: "mekanism:oxidizing",
      input: {
         item: "opolisinc:demon_core",
         amount: 1
      },
      output: {
         id: "mekanism:fissile_fuel",
         amount: 4000
      }
   }).id("opolisinc:mekanism/demon_core_oxidizing")

   // Receipt Processing
   function receiptProcessing(receipt_type) {
      event.recipes.mekanism.crushing('9x opolisinc:shredded_' + receipt_type, 'opolisinc:' + receipt_type).id("opolisinc:crushing/shredded_" + receipt_type)
      event.recipes.mekanism.enriching('opolisinc:restored_' + receipt_type, '9x opolisinc:shredded_' + receipt_type).id("opolisinc:enriching/restored_" + receipt_type)
      event.recipes.mekanism.combining('2x opolisinc:restored_' + receipt_type, '9x opolisinc:shredded_' + receipt_type, 'opolisinc:basic_trading_bucks').id("opolisinc:combining/basic_restored_" + receipt_type)
      event.recipes.mekanism.combining('3x opolisinc:restored_' + receipt_type, '9x opolisinc:shredded_' + receipt_type, 'opolisinc:advanced_trading_bucks').id("opolisinc:combining/advanced_restored_" + receipt_type)
      event.recipes.mekanism.combining('4x opolisinc:restored_' + receipt_type, '9x opolisinc:shredded_' + receipt_type, 'opolisinc:elite_trading_bucks').id("opolisinc:combining/elite_restored_" + receipt_type)
      event.recipes.mekanism.combining('5x opolisinc:restored_' + receipt_type, '9x opolisinc:shredded_' + receipt_type, 'opolisinc:ultimate_trading_bucks').id("opolisinc:combining/ultimate_restored_" + receipt_type)
   }

   receiptProcessing("piglin_receipt")
   receiptProcessing("queen_receipt")
   receiptProcessing("null_receipt")

   function receiptCrushing(receipt_type) {
      event.recipes.mekanism.crushing('9x opolisinc:shredded_villager_receipt', 'opolisinc:' + receipt_type).id("opolisinc:crushing/shredded_" + receipt_type)
   }

   receiptCrushing("villager_receipt_1")
   receiptCrushing("villager_receipt_2")
   receiptCrushing("villager_receipt_3")
   receiptCrushing("villager_receipt_4")
   receiptCrushing("villager_receipt_5")

   event.recipes.mekanism.enriching('opolisinc:restored_villager_receipt', '9x opolisinc:shredded_villager_receipt').id("opolisinc:enriching/restored_villager_receipt")
   event.recipes.mekanism.combining('2x opolisinc:restored_villager_receipt', '9x opolisinc:shredded_villager_receipt', 'opolisinc:basic_trading_bucks').id("opolisinc:combining/basic_restored_villager_receipt")
   event.recipes.mekanism.combining('3x opolisinc:restored_villager_receipt', '9x opolisinc:shredded_villager_receipt', 'opolisinc:advanced_trading_bucks').id("opolisinc:combining/advanced_restored_villager_receipt")
   event.recipes.mekanism.combining('4x opolisinc:restored_villager_receipt', '9x opolisinc:shredded_villager_receipt', 'opolisinc:elite_trading_bucks').id("opolisinc:combining/elite_restored_villager_receipt")
   event.recipes.mekanism.combining('5x opolisinc:restored_villager_receipt', '9x opolisinc:shredded_villager_receipt', 'opolisinc:ultimate_trading_bucks').id("opolisinc:combining/ultimate_restored_villager_receipt")

   // Farming Buck Combining
   event.recipes.mekanism.combining('2x mysticalagriculture:mystical_fertilizer', 'bone_meal', 'opolisinc:basic_farming_bucks').id("opolisinc:combining/basic_mystical_fertilizer")
   event.recipes.mekanism.combining('4x mysticalagriculture:mystical_fertilizer', 'bone_meal', 'opolisinc:advanced_farming_bucks').id("opolisinc:combining/advanced_mystical_fertilizer")
   event.recipes.mekanism.combining('8x mysticalagriculture:mystical_fertilizer', 'bone_meal', 'opolisinc:elite_farming_bucks').id("opolisinc:combining/elite_mystical_fertilizer")
   event.recipes.mekanism.combining('16x mysticalagriculture:mystical_fertilizer', 'bone_meal', 'opolisinc:ultimate_farming_bucks').id("opolisinc:combining/ultimate_mystical_fertilizer")
   event.recipes.mekanism.combining('4x mysticalagriculture:mystical_fertilizer', 'mysticalagriculture:fertilized_essence', 'opolisinc:basic_farming_bucks').id("opolisinc:combining/basic_mystical_fertilizer_better")
   event.recipes.mekanism.combining('8x mysticalagriculture:mystical_fertilizer', 'mysticalagriculture:fertilized_essence', 'opolisinc:advanced_farming_bucks').id("opolisinc:combining/advanced_mystical_fertilizer_better")
   event.recipes.mekanism.combining('16x mysticalagriculture:mystical_fertilizer', 'mysticalagriculture:fertilized_essence', 'opolisinc:elite_farming_bucks').id("opolisinc:combining/elite_mystical_fertilizer_better")
   event.recipes.mekanism.combining('32x mysticalagriculture:mystical_fertilizer', 'mysticalagriculture:fertilized_essence', 'opolisinc:ultimate_farming_bucks').id("opolisinc:combining/ultimate_mystical_fertilizer_better")

   // Sawing recipes
   event.custom(
      {
         type: "mekanism:sawing",
         input: { item: "opolisinc:basic_farming_bucks", count: 1 },
         main_output: { id: "opolisinc:speed_gene", count: 1 },
         secondary_output: { id: "opolisinc:speed_gene", count: 1 },
         secondary_chance: 0.25
      }
   ).id("opolisinc:sawing/speed_gene")

   event.custom(
      {
         type: "mekanism:sawing",
         input: { item: "opolisinc:advanced_farming_bucks", count: 1 },
         main_output: { id: "opolisinc:nocturn_gene", count: 1 },
         secondary_output: { id: "opolisinc:nocturn_gene", count: 1 },
         secondary_chance: 0.25
      }
   ).id("opolisinc:sawing/nocturn_gene")

   event.custom(
      {
         type: "mekanism:sawing",
         input: { item: "opolisinc:elite_farming_bucks", count: 1 },
         main_output: { id: "opolisinc:hot_gene", count: 1 },
         secondary_output: { id: "opolisinc:hot_gene", count: 1 },
         secondary_chance: 0.25
      }
   ).id("opolisinc:sawing/hot_gene")

   event.custom(
      {
         type: "mekanism:sawing",
         input: { item: "opolisinc:ultimate_farming_bucks", count: 1 },
         main_output: { id: "opolisinc:phase_gene", count: 1 },
         secondary_output: { id: "opolisinc:phase_gene", count: 1 },
         secondary_chance: 0.25
      }
   ).id("opolisinc:sawing/phase_gene")

   // Gene Splicing
   function geneSplicing(input, output) {
      event.recipes.mekanism.combining('2x ' + output, input, 'opolisinc:speed_gene')
      event.recipes.mekanism.combining('4x ' + output, input, 'opolisinc:nocturn_gene')
      event.recipes.mekanism.combining('6x ' + output, input, 'opolisinc:hot_gene')
      event.recipes.mekanism.combining('8x ' + output, input, 'opolisinc:phase_gene')
   }

   geneSplicing("wheat", "opolisinc:gm_wheat")
   geneSplicing("carrot", "opolisinc:gm_carrot")
   geneSplicing("potato", "opolisinc:gm_potato")
   geneSplicing("beetroot", "opolisinc:gm_beetroot")
   geneSplicing("opolisinc:sculked_wheat", "opolisinc:gm_sculked_wheat")
   geneSplicing("opolisinc:sculked_carrot", "opolisinc:gm_sculked_carrot")
   geneSplicing("opolisinc:sculked_potato", "opolisinc:gm_sculked_potato")
   geneSplicing("opolisinc:sculked_beetroot", "opolisinc:gm_sculked_beetroot")
   geneSplicing("minecraft:twisting_vines", "opolisinc:gm_twisting_vines")
   geneSplicing("minecraft:weeping_vines", "opolisinc:gm_weeping_vines")
   geneSplicing("opolisinc:phased_wheat", "opolisinc:gm_phased_wheat")
   geneSplicing("opolisinc:phased_carrot", "opolisinc:gm_phased_carrot")
   geneSplicing("opolisinc:phased_potato", "opolisinc:gm_phased_potato")
   geneSplicing("opolisinc:phased_beetroot", "opolisinc:gm_phased_beetroot")

   event.recipes.mekanism.combining('opolisinc:reality_seeds', '8x #c:seeds', '10x opolisinc:phase_gene').id("opolisinc:combining/reality_seeds")

   // Enriching
   event.recipes.mekanism.enriching('opolisinc:opolisite_circuit_board', 'opolisinc:opolisite_ingot').id("opolisinc:enriching/opolisite_circuit_board")
   event.recipes.mekanism.enriching('glowstone_dust', 'blaze_powder').id("opolisinc:enriching/glowstone_dust")

   // Crushing
   event.recipes.mekanism.crushing('opolisinc:activation_essence', '#opolisinc:activated_ore').id("opolisinc:crushing/activation_essence")

   // Hyperdense Stone Combining
   event.recipes.mekanism.combining('opolisinc:hyperdense_stone', '64x #c:stones', '8x opolisinc:ultimate_processing_bucks').id("opolisinc:combining/hyperdense_stone")
   event.recipes.mekanism.combining('opolisinc:hyperdense_stone_step_1', 'opolisinc:hyperdense_stone', '4x raw_iron').id("opolisinc:combining/hyperdense_stone_step_1")
   event.recipes.mekanism.combining('opolisinc:hyperdense_stone_step_2', 'opolisinc:hyperdense_stone_step_1', '4x raw_copper').id("opolisinc:combining/hyperdense_stone_step_2")
   event.recipes.mekanism.combining('opolisinc:hyperdense_stone_step_3', 'opolisinc:hyperdense_stone_step_2', '4x raw_gold').id("opolisinc:combining/hyperdense_stone_step_3")
   event.recipes.mekanism.combining('opolisinc:hyperdense_stone_step_4', 'opolisinc:hyperdense_stone_step_3', '4x coal').id("opolisinc:combining/hyperdense_stone_step_4")
   event.recipes.mekanism.combining('opolisinc:hyperdense_stone_step_5', 'opolisinc:hyperdense_stone_step_4', '4x alltheores:raw_uranium').id("opolisinc:combining/hyperdense_stone_step_5")
   event.recipes.mekanism.combining('opolisinc:hyperdense_stone_step_6', 'opolisinc:hyperdense_stone_step_5', '4x quartz').id("opolisinc:combining/hyperdense_stone_step_6")
   event.recipes.mekanism.combining('opolisinc:hyperdense_stone_step_7', 'opolisinc:hyperdense_stone_step_6', '4x alltheores:raw_platinum').id("opolisinc:combining/hyperdense_stone_step_7")
   event.recipes.mekanism.combining('opolisinc:hyperdense_stone_step_8', 'opolisinc:hyperdense_stone_step_7', '4x emerald').id("opolisinc:combining/hyperdense_stone_step_8")
   event.recipes.mekanism.combining('opolisinc:hyperdense_stone_step_9', 'opolisinc:hyperdense_stone_step_8', '4x diamond').id("opolisinc:combining/hyperdense_stone_step_9")
   event.recipes.mekanism.combining('opolisinc:miniaturised_planetoid', 'opolisinc:hyperdense_stone_step_9', 'opolisinc:ultimate_mining_bucks').id("opolisinc:combining/miniaturised_planetoid")

   // Steel Casing
   event.recipes.mekanism.combining('mekanism:steel_casing', '4x alltheores:steel_ingot', '8x mekanism:alloy_infused').id("opolisinc:combining/steel_casing")

   // Activation Essence/Activated Alloys (Keep oxidizing, washing, reaction as event.custom - not supported)
   event.custom({
      type: "mekanism:oxidizing",
      input: { item: "opolisinc:activation_essence", count: 1 },
      output: { id: "opolisinc:noisy_activation_essence", amount: 250 }
   }).id("opolisinc:oxidizing/noisy_activation_essence")

   event.custom({
      type: "mekanism:washing",
      chemical_input: { chemical: "opolisinc:noisy_activation_essence", amount: 250 },
      fluid_input: { fluid: "biomesoplenty:liquid_null", amount: 1000 },
      output: { id: "opolisinc:filtered_activation_essence", amount: 250 }
   })

   event.custom({
      type: "mekanism:reaction",
      item_input: { item: "alltheores:lumium_ingot", count: 1 },
      chemical_input: { chemical: "opolisinc:filtered_activation_essence", amount: 1000 },
      fluid_input: { fluid: "minecraft:water", amount: 500 },
      item_output: { id: "opolisinc:activated_lumium_ingot", count: 1 },
      chemical_output: { id: "opolisinc:unstable_activation_essence", amount: 250 },
      duration: 400
   })

   event.custom({
      type: "mekanism:reaction",
      item_input: { item: "alltheores:signalum_ingot", count: 1 },
      chemical_input: { chemical: "opolisinc:filtered_activation_essence", amount: 1000 },
      fluid_input: { fluid: "minecraft:water", amount: 500 },
      item_output: { id: "opolisinc:activated_signalum_ingot", count: 1 },
      chemical_output: { id: "opolisinc:unstable_activation_essence", amount: 250 },
      duration: 400
   })

   event.custom({
      type: "mekanism:reaction",
      item_input: { item: "alltheores:enderium_ingot", count: 1 },
      chemical_input: { chemical: "opolisinc:filtered_activation_essence", amount: 1000 },
      fluid_input: { fluid: "minecraft:water", amount: 500 },
      item_output: { id: "opolisinc:activated_enderium_ingot", count: 1 },
      chemical_output: { id: "opolisinc:unstable_activation_essence", amount: 250 },
      duration: 400
   })

   // Opolisite
   event.recipes.mekanism.combining('opolisinc:inert_opolisite_ingot', 'opolisinc:impure_opolisite_ingot', 'opolisinc:plasma_tipped_drill_bit').id("opolisinc:combining/inert_opolisite_ingot")

   event.custom({
      type: "mekanism:nucleosynthesizing",
      item_input: { item: "opolisinc:inert_opolisite_ingot", count: 1 },
      chemical_input: { chemical: "mekanism:antimatter", amount: 10 },
      output: { id: "opolisinc:opolisite_ingot", count: 1 },
      duration: 40,
      per_tick_usage: false
   }).id("opolisinc:nucleosynthesizing/opolisite_ingot")

   // Chemical Infusing
   event.recipes.mekanism.chemical_infusing('mekanism:antimatter', '50x opolisinc:unstable_activation_essence', '200x mekanism:hydrogen').id("opolisinc:chemical_infusing/antimatter")

   event.custom({
      type: "mekanism:reaction",
      item_input: { tag: "c:nuggets", count: 1 },
      chemical_input: { chemical: "opolisinc:unstable_activation_essence", amount: 250 },
      fluid_input: { fluid: "mekanism:hydrogen", amount: 1000 },
      chemical_output: { id: "mekanism:antimatter", amount: 5 },
      duration: 400
   }).id("opolisinc:reaction/antimatter")

   // Antimatter changes (Keep custom - oxidizing not fully supported with gas output)
   event.custom({
      type: "mekanism:oxidizing",
      input: { item: "mekanism:pellet_antimatter", count: 1 },
      output: { id: "mekanism:antimatter", amount: 100 }
   }).id("mekanism:processing/lategame/antimatter/from_pellet")

   // Crystallizing
   event.recipes.mekanism.crystallizing('mekanism:pellet_antimatter', '100x mekanism:antimatter').id("mekanism:processing/lategame/antimatter_pellet/from_gas")

})
