console.info('Loading ae2.js for Opolis Inc')

ServerEvents.recipes(event => {
    function storageBuckInscribing(input, type) {
        event.custom({
            type: "ae2:inscriber",
            ingredients: {
                top: { item: "opolisinc:basic_storage_bucks" },
                middle: { item: input }
            },
            mode: "press",
            result: { count: 1, id: "ae2:printed_" + type }
        }).id("opolisinc:basic_" + type + "_print")

        event.custom({
            type: "ae2:inscriber",
            ingredients: {
                top: { item: "opolisinc:advanced_storage_bucks" },
                middle: { item: input }
            },
            mode: "press",
            result: { count: 2, id: "ae2:printed_" + type }
        }).id("opolisinc:advanced_" + type + "_print")

        event.custom({
            type: "ae2:inscriber",
            ingredients: {
                top: { item: "opolisinc:elite_storage_bucks" },
                middle: { item: input }
            },
            mode: "press",
            result: { count: 4, id: "ae2:printed_" + type }
        }).id("opolisinc:elite_" + type + "_print")

        event.custom({
            type: "ae2:inscriber",
            ingredients: {
                top: { item: "opolisinc:ultimate_storage_bucks" },
                middle: { item: input }
            },
            mode: "press",
            result: { count: 8, id: "ae2:printed_" + type }
        }).id("opolisinc:ultimate_" + type + "_print")
    }

    storageBuckInscribing("minecraft:gold_ingot", "logic_processor")
    storageBuckInscribing("minecraft:diamond", "engineering_processor")
    storageBuckInscribing("ae2:certus_quartz_crystal", "calculation_processor")
    storageBuckInscribing("ae2:silicon", "silicon")

    event.custom({
        type: "ae2:inscriber",
        ingredients: {
            top: { item: "opolisinc:basic_storage_bucks" },
            middle: { item: "extendedae:entro_crystal" }
        },
        mode: "press",
        result: { count: 2, id: "extendedae:concurrent_processor_print" }
    }).id("opolisinc:inscriber/basic_concurrent_processor_print")

    event.custom({
        type: "ae2:inscriber",
        ingredients: {
            top: { item: "opolisinc:advanced_storage_bucks" },
            middle: { item: "extendedae:entro_crystal" }
        },
        mode: "press",
        result: { count: 4, id: "extendedae:concurrent_processor_print" }
    }).id("opolisinc:inscriber/advanced_concurrent_processor_print")

    event.custom({
        type: "ae2:inscriber",
        ingredients: {
            top: { item: "opolisinc:elite_storage_bucks" },
            middle: { item: "extendedae:entro_crystal" }
        },
        mode: "press",
        result: { count: 6, id: "extendedae:concurrent_processor_print" }
    }).id("opolisinc:inscriber/elite_concurrent_processor_print")

    event.custom({
        type: "ae2:inscriber",
        ingredients: {
            top: { item: "opolisinc:ultimate_storage_bucks" },
            middle: { item: "extendedae:entro_crystal" }
        },
        mode: "press",
        result: { count: 8, id: "extendedae:concurrent_processor_print" }
    }).id("opolisinc:inscriber/ultimate_concurrent_processor_print")

    event.custom(
        {
            type: "ae2:inscriber",
            ingredients: {
                top: { item: "ae2:calculation_processor" },
                middle: { item: "ae2:logic_processor" },
                bottom: { item: "ae2:engineering_processor" }
            },
            mode: "press",
            result: { count: 1, id: "laserio:logic_chip" }
        }
    )
    event.replaceInput({ id: "laserio:laser_connector_advanced" }, "diamond", "mekanism:teleportation_core")
    event.replaceInput({ id: "laserio:laser_connector_advanced" }, "ender_pearl", "diamond")
    event.remove({ output: "laserio:logic_chip_raw" })
    event.remove({ input: "laserio:logic_chip_raw" })

    event.remove({ id: "ae2:inscriber/engineering_processor_print" })
    event.remove({ id: "ae2:inscriber/logic_processor_print" })
    event.remove({ id: "ae2:inscriber/calculation_processor_print" })
    event.remove({ id: "ae2:inscriber/silicon_print" })
})