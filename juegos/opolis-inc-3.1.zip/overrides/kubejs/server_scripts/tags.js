console.info('Loading tags.js for Opolis Inc')
// priority: 1000

ServerEvents.tags("item", event => {

    //event.get('opolisutilities:banned_in_item_repairer').add('#market:licenses')

    event.get('opolisutilities:banned_in_item_repairer').remove("wooden_axe")

    event.get('market:licenses').add("nether_star")
        .add([
            "stone_pickaxe",
            "stone_sword",
            "stone_axe",
            "stone_shovel",
            "stone_hoe",
            "iron_pickaxe",
            "iron_sword",
            "iron_axe",
            "iron_shovel",
            "iron_hoe",
            "diamond_pickaxe",
            "diamond_sword",
            "diamond_axe",
            "diamond_shovel",
            "diamond_hoe",
            "netherite_pickaxe",
            "netherite_sword",
            "netherite_axe",
            "netherite_shovel",
            "netherite_hoe",
            "ae2:nether_quartz_pickaxe",
            "ae2:nether_quartz_sword",
            "ae2:nether_quartz_axe",
            "ae2:nether_quartz_shovel",
            "ae2:nether_quartz_hoe",
            "ae2:certus_quartz_pickaxe",
            "ae2:certus_quartz_sword",
            "ae2:certus_quartz_axe",
            "ae2:certus_quartz_shovel",
            "ae2:certus_quartz_hoe",
            "ae2:fluix_pickaxe",
            "ae2:fluix_sword",
            "ae2:fluix_axe",
            "ae2:fluix_shovel",
            "ae2:fluix_hoe",
            "mekanismtools:bronze_pickaxe",
            "mekanismtools:bronze_sword",
            "mekanismtools:bronze_axe",
            "mekanismtools:bronze_shovel",
            "mekanismtools:bronze_hoe",
            "mekanismtools:lapis_lazuli_pickaxe",
            "mekanismtools:lapis_lazuli_sword",
            "mekanismtools:lapis_lazuli_axe",
            "mekanismtools:lapis_lazuli_shovel",
            "mekanismtools:lapis_lazuli_hoe",
            "mekanismtools:refined_glowstone_pickaxe",
            "mekanismtools:refined_glowstone_sword",
            "mekanismtools:refined_glowstone_axe",
            "mekanismtools:refined_glowstone_shovel",
            "mekanismtools:refined_glowstone_hoe",
            "mekanismtools:steel_pickaxe",
            "mekanismtools:steel_sword",
            "mekanismtools:steel_axe",
            "mekanismtools:steel_shovel",
            "mekanismtools:steel_hoe",
            "mekanismtools:osmium_pickaxe",
            "mekanismtools:osmium_sword",
            "mekanismtools:osmium_axe",
            "mekanismtools:osmium_shovel",
            "mekanismtools:osmium_hoe",
            "mekanismtools:refined_obsidian_pickaxe",
            "mekanismtools:refined_obsidian_sword",
            "mekanismtools:refined_obsidian_axe",
            "mekanismtools:refined_obsidian_shovel",
            "mekanismtools:refined_obsidian_hoe",
        ])

    event.get('market:no_demand').add("nether_star")
        .add([
            "stone_pickaxe",
            "stone_sword",
            "stone_axe",
            "stone_shovel",
            "stone_hoe",
            "iron_pickaxe",
            "iron_sword",
            "iron_axe",
            "iron_shovel",
            "iron_hoe",
            "diamond_pickaxe",
            "diamond_sword",
            "diamond_axe",
            "diamond_shovel",
            "diamond_hoe",
            "netherite_pickaxe",
            "netherite_sword",
            "netherite_axe",
            "netherite_shovel",
            "netherite_hoe",
            "ae2:nether_quartz_pickaxe",
            "ae2:nether_quartz_sword",
            "ae2:nether_quartz_axe",
            "ae2:nether_quartz_shovel",
            "ae2:nether_quartz_hoe",
            "ae2:certus_quartz_pickaxe",
            "ae2:certus_quartz_sword",
            "ae2:certus_quartz_axe",
            "ae2:certus_quartz_shovel",
            "ae2:certus_quartz_hoe",
            "ae2:fluix_pickaxe",
            "ae2:fluix_sword",
            "ae2:fluix_axe",
            "ae2:fluix_shovel",
            "ae2:fluix_hoe",
            "mekanismtools:bronze_pickaxe",
            "mekanismtools:bronze_sword",
            "mekanismtools:bronze_axe",
            "mekanismtools:bronze_shovel",
            "mekanismtools:bronze_hoe",
            "mekanismtools:lapis_lazuli_pickaxe",
            "mekanismtools:lapis_lazuli_sword",
            "mekanismtools:lapis_lazuli_axe",
            "mekanismtools:lapis_lazuli_shovel",
            "mekanismtools:lapis_lazuli_hoe",
            "mekanismtools:refined_glowstone_pickaxe",
            "mekanismtools:refined_glowstone_sword",
            "mekanismtools:refined_glowstone_axe",
            "mekanismtools:refined_glowstone_shovel",
            "mekanismtools:refined_glowstone_hoe",
            "mekanismtools:steel_pickaxe",
            "mekanismtools:steel_sword",
            "mekanismtools:steel_axe",
            "mekanismtools:steel_shovel",
            "mekanismtools:steel_hoe",
            "mekanismtools:osmium_pickaxe",
            "mekanismtools:osmium_sword",
            "mekanismtools:osmium_axe",
            "mekanismtools:osmium_shovel",
            "mekanismtools:osmium_hoe",
            "mekanismtools:refined_obsidian_pickaxe",
            "mekanismtools:refined_obsidian_sword",
            "mekanismtools:refined_obsidian_axe",
            "mekanismtools:refined_obsidian_shovel",
            "mekanismtools:refined_obsidian_hoe",
        ])

    event.get('opolisinc:first_power').add(['mekanismgenerators:wind_generator', 'mekanismgenerators:solar_generator', 'mekanismgenerators:heat_generator'])

    event.get('opolisinc:1_drawers').add(['functionalstorage:oak_1', 'functionalstorage:spruce_1', 'functionalstorage:birch_1', 'functionalstorage:jungle_1', 'functionalstorage:acacia_1', 'functionalstorage:dark_oak_1', 'functionalstorage:crimson_1', 'functionalstorage:warped_1', 'functionalstorage:mangrove_1', 'functionalstorage:cherry_1', 'functionalstorage:framed_1'])
    event.get('opolisinc:2_drawers').add(['functionalstorage:oak_2', 'functionalstorage:spruce_2', 'functionalstorage:birch_2', 'functionalstorage:jungle_2', 'functionalstorage:acacia_2', 'functionalstorage:dark_oak_2', 'functionalstorage:crimson_2', 'functionalstorage:warped_2', 'functionalstorage:mangrove_2', 'functionalstorage:cherry_2', 'functionalstorage:framed_2'])
    event.get('opolisinc:4_drawers').add(['functionalstorage:oak_4', 'functionalstorage:spruce_4', 'functionalstorage:birch_4', 'functionalstorage:jungle_4', 'functionalstorage:acacia_4', 'functionalstorage:dark_oak_4', 'functionalstorage:crimson_4', 'functionalstorage:warped_4', 'functionalstorage:mangrove_2', 'functionalstorage:cherry_2', 'functionalstorage:framed_4'])

    event.get("market:licenses").remove(["minecraft:diamond_sword", "minecraft:paper", "opolisutilities:log_sheet"])

    event.get("opolisinc:banned_in_loot_tables").add("#c:ingots").add("#c:gems").add("minecraft:bucket")

    event.get("opolisinc:villager_blocks_1").add(['minecraft:blast_furnace', 'minecraft:smoker', 'minecraft:cartography_table'])
    event.get("opolisinc:villager_blocks_2").add(['minecraft:composter', 'minecraft:barrel', 'minecraft:fletching_table'])
    event.get("opolisinc:villager_blocks_3").add(['minecraft:loom', 'minecraft:stonecutter', 'sawmill:sawmill'])
    event.get("opolisinc:villager_blocks_4").add(['minecraft:grindstone', 'minecraft:lectern', 'minecraft:smithing_table'])
    event.get("opolisinc:villager_blocks_5").add(['minecraft:brewing_stand', 'ae2:charger', 'minecraft:cauldron'])

    event.get("opolisinc:1k_4k_storage_cells").add(['ae2:item_storage_cell_1k', 'ae2:fluid_storage_cell_1k', 'appmek:chemical_storage_cell_1k', 'ae2:item_storage_cell_4k', 'ae2:fluid_storage_cell_4k', 'appmek:chemical_storage_cell_4k'])

    event.get("opolisinc:crafters").add(["minecraft:crafter", "opolisutilities:crafter", "mekanism:formulaic_assemblicator", 'extendedcrafting:basic_auto_table', 'extendedcrafting:advanced_auto_table', 'extendedcrafting:elite_auto_table', 'extendedcrafting:ultimate_auto_table'])

    event.get("c:crops").add(['colors:yellow_apple', 'colors:white_apple', 'colors:red_apple', 'colors:purple_apple', 'colors:pink_apple', 'colors:orange_apple', 'colors:magenta_apple', 'colors:lime_apple', 'colors:light_gray_apple', 'colors:black_apple', 'colors:blue_apple', 'colors:brown_apple', 'colors:cyan_apple', 'colors:gray_apple', 'colors:green_apple', 'colors:light_blue_apple', 'minecraft:apple'])

    event.get("opolisinc:wheat").add(["wheat", "opolisinc:gm_wheat"])
    event.get("opolisinc:carrot").add(["carrot", "opolisinc:gm_carrot"])
    event.get("opolisinc:potato").add(["potato", "opolisinc:gm_potato"])
    event.get("opolisinc:beetroot").add(["beetroot", "opolisinc:gm_beetroot"])

    event.get("opolisinc:basic_crops").add(["wheat", "carrot", "potato", "beetroot"])

    event.get("opolisinc:sculked_wheat").add(["opolisinc:sculked_wheat", "opolisinc:gm_sculked_wheat"])
    event.get("opolisinc:sculked_carrot").add(["opolisinc:sculked_carrot", "opolisinc:gm_sculked_carrot"])
    event.get("opolisinc:sculked_potato").add(["opolisinc:sculked_potato", "opolisinc:gm_sculked_potato"])
    event.get("opolisinc:sculked_beetroot").add(["opolisinc:sculked_beetroot", "opolisinc:gm_sculked_beetroot"])

    event.get("opolisinc:sculked_crops").add("opolisinc:sculked_wheat", "opolisinc:sculked_carrot", "opolisinc:sculked_potato", "opolisinc:sculked_beetroot")

    event.get("opolisinc:twisting_vines").add(["twisting_vines", "opolisinc:gm_twisting_vines"])
    event.get("opolisinc:weeping_vines").add(["weeping_vines", "opolisinc:gm_weeping_vines"])

    event.get("opolisinc:phased_wheat").add(["opolisinc:phased_wheat", "opolisinc:gm_phased_wheat"])
    event.get("opolisinc:phased_carrot").add(["opolisinc:phased_carrot", "opolisinc:gm_phased_carrot"])
    event.get("opolisinc:phased_potato").add(["opolisinc:phased_potato", "opolisinc:gm_phased_potato"])
    event.get("opolisinc:phased_beetroot").add(["opolisinc:phased_beetroot", "opolisinc:gm_phased_beetroot"])

    event.get("opolisinc:phased_crops").add("opolisinc:phased_wheat", "opolisinc:phased_carrot", "opolisinc:phased_potato", "opolisinc:phased_beetroot")

    //Colored Items
    colors.forEach(color => {
        event.get('opolisinc:colored_stone').add(`colors:${color}_stone`)
        event.get('opolisinc:colored_cobblestone').add(`colors:${color}_cobblestone`)
    })
})

ServerEvents.tags("block", event => {

    event.get("the_bumblezone:dimension_teleportation/required_blocks_under_beehive_to_teleport").add('minecraft:brewing_stand')

    event.get("minecraft:needs_iron_tool").remove("alltheores:raw_platinum_block")
    event.get("minecraft:needs_diamond_tool").add("alltheores:raw_platinum_block")

    event.get("smartcrafting:whitelisted_storage").add(["@functionalstorage", "@ironchest", "@sophisticatedbackpacks"])
})

// Banned items
ServerEvents.recipes(event => {

    event.remove({ mod: 'caveopolis' });
    event.remove({ output: /caveopolis:/ });
    event.remove({ output: 'opolisutilities:smart_crafting_table' });
    event.remove({ input: 'extendedae:quartz_blend' });
    event.remove({ output: 'extendedae:quartz_blend' });

})

