console.info('Loading casting.js for Opolis Inc')

ServerEvents.recipes(event => {

   event.recipes.casting.melting("opolisinc:ultimate_storage_bucks", "100x opolisinc:quantum_memory_fluid", 10000).id("opolisinc:casting/ultimate_storage_bucks")

   event.recipes.casting.melting("powah:dielectric_paste", "50x opolisinc:molten_dielectric", 800).id("opolisinc:casting/dielectric_paste")

   event.recipes.casting.melting("alltheores:cinnabar", "90x casting:molten_redstone", 1000).id("opolisinc:casting/cinnabar_to_redstone")
   event.recipes.casting.melting("mysticalagriculture:prosperity_shard", "100x opolisinc:molten_prosperity", 1000).id("opolisinc:casting/prosperity_shard_melting")
   event.recipes.casting.melting("mysticalagriculture:prosperity_block", "900x opolisinc:molten_prosperity", 1000).id("opolisinc:casting/prosperity_block_melting")
   event.recipes.casting.melting("mysticalagriculture:prosperity_ingot", "400x opolisinc:molten_prosperity", 1000).id("opolisinc:casting/prosperity_ingot_melting")
   event.recipes.casting.melting("mysticalagriculture:prosperity_gemstone", "400x opolisinc:molten_prosperity", 1000).id("opolisinc:casting/prosperity_gemstone_melting")
   event.recipes.casting.melting("mysticalagriculture:prosperity_ingot_block", "3600x opolisinc:molten_prosperity", 1000).id("opolisinc:casting/prosperity_ingot_block_melting")
   event.recipes.casting.melting("mysticalagriculture:prosperity_gemstone_block", "3600x opolisinc:molten_prosperity", 1000).id("opolisinc:casting/prosperity_gemstone_block_melting")

   event.recipes.casting.solidifier("opolisinc:basic_power_license", "500x opolisinc:molten_dielectric", "opolisinc:advanced_power_license").id('opolisinc:advanced_power_license')
   event.recipes.casting.solidifier("casting:rod_mold", "50x opolisinc:molten_dielectric", "powah:dielectric_rod").id('powah:dielectric_rod')

   event.recipes.casting.solidifier("copper_ingot", "180x casting:molten_redstone", "mekanism:alloy_infused").id("opolisinc:casting/infused_alloy")

   //Fixes
   event.recipes.casting.melting("alltheores:raw_aluminum_block", "900x casting:molten_aluminum", 1000).id("casting:melting/aluminum/from_raw_ore_block")
   event.recipes.casting.melting("alltheores:raw_nickel_block", "900x casting:molten_nickel", 1000).id("casting:melting/nickel/from_raw_ore_block")
   event.recipes.casting.melting("alltheores:raw_platinum_block", "900x casting:molten_platinum", 1000).id("casting:melting/platinum/from_raw_ore_block")
   event.recipes.casting.melting("alltheores:raw_zinc_block", "900x casting:molten_zinc", 1000).id("casting:melting/zinc/from_raw_ore_block")
   event.recipes.casting.melting("alltheores:raw_iridium_block", "900x casting:molten_iridium", 1000).id("casting:melting/iridium/from_raw_ore_block")

   event.recipes.casting.melting("redstone_block", "810x casting:molten_redstone", 1000).id("casting:melting/redstone/from_block")

   //Ore Casting
   event.recipes.casting.solidifier("stone", "180x casting:molten_iron", "iron_ore").id("opolisinc:casting/iron_ore")
   event.recipes.casting.solidifier("deepslate", "180x casting:molten_iron", "deepslate_iron_ore").id("opolisinc:casting/deepslate_iron_ore")

   event.recipes.casting.solidifier("stone", "630x casting:molten_copper", "copper_ore").id("opolisinc:casting/copper_ore")
   event.recipes.casting.solidifier("deepslate", "630x casting:molten_copper", "deepslate_copper_ore").id("opolisinc:casting/deepslate_copper_ore")

   event.recipes.casting.solidifier("stone", "180x casting:molten_gold", "gold_ore").id("opolisinc:casting/gold_ore")
   event.recipes.casting.solidifier("deepslate", "180x casting:molten_gold", "deepslate_gold_ore").id("opolisinc:casting/deepslate_gold_ore")
   event.recipes.casting.solidifier("netherrack", "180x casting:molten_gold", "nether_gold_ore").id("opolisinc:casting/nether_gold_ore")

   event.recipes.casting.solidifier("stone", "720x casting:molten_redstone", "redstone_ore").id("opolisinc:casting/redstone_ore")
   event.recipes.casting.solidifier("deepslate", "720x casting:molten_redstone", "deepslate_redstone_ore").id("opolisinc:casting/deepslate_redstone_ore")

   event.recipes.casting.solidifier("stone", "180x casting:molten_coal", "coal_ore").id("opolisinc:casting/coal_ore")
   event.recipes.casting.solidifier("deepslate", "180x casting:molten_coal", "deepslate_coal_ore").id("opolisinc:casting/deepslate_coal_ore")

   event.recipes.casting.solidifier("stone", "360x casting:molten_lapis", "lapis_ore").id("opolisinc:casting/lapis_ore")
   event.recipes.casting.solidifier("deepslate", "360x casting:molten_lapis", "deepslate_lapis_ore").id("opolisinc:casting/deepslate_lapis_ore")

   event.recipes.casting.solidifier("stone", "180x casting:molten_diamond", "diamond_ore").id("opolisinc:casting/diamond_ore")
   event.recipes.casting.solidifier("deepslate", "180x casting:molten_diamond", "deepslate_diamond_ore").id("opolisinc:casting/deepslate_diamond_ore")

   event.recipes.casting.solidifier("stone", "180x casting:molten_emerald", "emerald_ore").id("opolisinc:casting/emerald_ore")
   event.recipes.casting.solidifier("deepslate", "180x casting:molten_emerald", "deepslate_emerald_ore").id("opolisinc:casting/deepslate_emerald_ore")

   event.recipes.casting.solidifier("netherrack", "180x casting:molten_quartz", "nether_quartz_ore").id("opolisinc:casting/nether_quartz_ore")

   event.recipes.casting.solidifier("basalt", "90x casting:molten_netherite", "ancient_debris").id("opolisinc:casting/ancient_debris")

   function allTheOresOreCasting(type) {
      event.recipes.casting.solidifier("stone", "180x casting:molten_" + type, "alltheores:" + type + "_ore").id("opolisinc:casting/" + type + "_ore")
      event.recipes.casting.solidifier("deepslate", "180x casting:molten_" + type, "alltheores:deepslate_" + type + "_ore").id("opolisinc:casting/deepslate_" + type + "_ore")
      event.recipes.casting.solidifier("netherrack", "180x casting:molten_" + type, "alltheores:nether_" + type + "_ore").id("opolisinc:casting/nether_" + type + "_ore")
      event.recipes.casting.solidifier("end_stone", "180x casting:molten_" + type, "alltheores:end_" + type + "_ore").id("opolisinc:casting/end_" + type + "_ore")
   }

   allTheOresOreCasting("lead")
   allTheOresOreCasting("tin")
   allTheOresOreCasting("nickel")
   allTheOresOreCasting("osmium")
   allTheOresOreCasting("silver")
   allTheOresOreCasting("uranium")
   allTheOresOreCasting("aluminum")
   allTheOresOreCasting("zinc")
   allTheOresOreCasting("platinum")
   allTheOresOreCasting("iridium")

   event.recipes.casting.solidifier("stone", "300x opolisinc:molten_prosperity", "mysticalagriculture:prosperity_ore").id("opolisinc:casting/prosperity_ore")
   event.recipes.casting.solidifier("deepslate", "300x opolisinc:molten_prosperity", "mysticalagriculture:deepslate_prosperity_ore").id("opolisinc:casting/deepslate_prosperity_ore")
   event.recipes.casting.solidifier("netherrack", "300x opolisinc:molten_prosperity", "mysticalagradditions:nether_prosperity_ore").id("opolisinc:casting/nether_prosperity_ore")
   event.recipes.casting.solidifier("end_stone", "300x opolisinc:molten_prosperity", "mysticalagradditions:end_prosperity_ore").id("opolisinc:casting/end_prosperity_ore")

   function essenceCasting(type, output) {
      event.custom(
         {
            type: "casting:solidifier",
            fluid: { amount: 1000, id: "casting:molten_stone" },
            mold: { item: "mysticalagriculture:" + type + "_essence", count: 18 },
            output: { item: output, count: 1 }
         }
      ).id("opolisinc:casting/essence_" + type + "_ore")
   }

   essenceCasting("iron", "iron_ore")
   essenceCasting("copper", "copper_ore")
   essenceCasting("gold", "gold_ore")
   essenceCasting("redstone", "redstone_ore")
   essenceCasting("coal", "coal_ore")
   essenceCasting("lapis_lazuli", "lapis_ore")
   essenceCasting("nether_quartz", "nether_quartz_ore")
   event.custom(
      {
         type: "casting:solidifier",
         fluid: { amount: 1000, id: "casting:molten_stone" },
         mold: { item: "mysticalagriculture:netherite_essence", count: 9 },
         output: { item: "ancient_debris", count: 1 }
      }
   ).id("opolisinc:casting/essence_ancient_debris")
   essenceCasting("diamond", "diamond_ore")
   essenceCasting("emerald", "emerald_ore")
   essenceCasting("aluminum", "alltheores:aluminum_ore")
   essenceCasting("tin", "alltheores:tin_ore")
   essenceCasting("nickel", "alltheores:nickel_ore")
   essenceCasting("silver", "alltheores:silver_ore")
   essenceCasting("zinc", "alltheores:zinc_ore")
   essenceCasting("lead", "alltheores:lead_ore")
   essenceCasting("uranium", "alltheores:uranium_ore")
   essenceCasting("osmium", "alltheores:osmium_ore")
   essenceCasting("platinum", "alltheores:platinum_ore")
   essenceCasting("iridium", "alltheores:iridium_ore")

   //Bacterial Sludge and Mulch
   event.recipes.casting.melting("opolisinc:basic_bounty_bucks", "1000x opolisinc:benign_bacterial_sludge", 100)
   event.recipes.casting.melting("opolisinc:advanced_bounty_bucks", "1000x opolisinc:malignant_bacterial_sludge", 100)
   event.recipes.casting.melting("opolisinc:elite_bounty_bucks", "1000x opolisinc:feverish_bacterial_sludge", 100)
   event.recipes.casting.melting("opolisinc:ultimate_bounty_bucks", "1000x opolisinc:draconic_bacterial_sludge", 100)

   //Opolisite 

   event.recipes.casting.melting("opolisinc:activated_signalum_ingot", "90x opolisinc:molten_activated_signalum", 2000).id("opolisinc:casting/molten_activated_signalum")
   event.recipes.casting.melting("opolisinc:activated_lumium_ingot", "90x opolisinc:molten_activated_lumium", 2000).id("opolisinc:casting/molten_activated_lumium")
   event.recipes.casting.melting("opolisinc:activated_enderium_ingot", "90x opolisinc:molten_activated_enderium", 2000).id("opolisinc:casting/molten_activated_enderium")

   event.recipes.casting.solidifier("casting:ingot_mold", "90x opolisinc:molten_activated_signalum", "opolisinc:activated_signalum_ingot").id("opolisinc:casting/activated_signalum_ingot")
   event.recipes.casting.solidifier("casting:ingot_mold", "90x opolisinc:molten_activated_lumium", "opolisinc:activated_lumium_ingot").id("opolisinc:casting/activated_lumium_ingot")
   event.recipes.casting.solidifier("casting:ingot_mold", "90x opolisinc:molten_activated_enderium", "opolisinc:activated_enderium_ingot").id("opolisinc:casting/activated_enderium_ingot")

   event.recipes.casting.solidifier("opolisinc:ultimate_processing_bucks", "90x opolisinc:molten_inert_opolisite", "opolisinc:impure_opolisite_ingot").id("opolisinc:casting/impure_opolisite_ingot")

   event.recipes.casting.solidifier("casting:block_mold", "810x opolisinc:molten_opolisite", "opolisinc:opolisite_block").id("opolisinc:casting/opolisite_block")
   event.recipes.casting.solidifier("casting:ingot_mold", "90x opolisinc:molten_opolisite", "opolisinc:opolisite_ingot").id("opolisinc:casting/opolisite_ingot")
   event.recipes.casting.solidifier("casting:nugget_mold", "10x opolisinc:molten_opolisite", "opolisinc:opolisite_nugget").id("opolisinc:casting/opolisite_nugget")

   event.recipes.casting.melting("opolisinc:opolisite_block", "810x opolisinc:molten_opolisite", 10000).id("opolisinc:melting/opolisite_block")
   event.recipes.casting.melting("opolisinc:opolisite_ingot", "90x opolisinc:molten_opolisite", 10000).id("opolisinc:melting/opolisite_ingot")
   event.recipes.casting.melting("opolisinc:opolisite_nugget", "10x opolisinc:molten_opolisite", 10000).id("opolisinc:melting/opolisite_nugget")

   //Bacterial Mulch

   event.recipes.casting.solidifier("dirt", "1000x opolisinc:benign_bacterial_sludge", "opolisinc:benign_bacterial_mulch").id("opolisinc:casting/benign_bacterial_sludge")
   event.recipes.casting.solidifier("dirt", "1000x opolisinc:malignant_bacterial_sludge", "opolisinc:malignant_bacterial_mulch").id("opolisinc:casting/malignant_bacterial_sludge")
   event.recipes.casting.solidifier("dirt", "1000x opolisinc:feverish_bacterial_sludge", "opolisinc:feverish_bacterial_mulch").id("opolisinc:casting/feverish_bacterial_sludge")
   event.recipes.casting.solidifier("dirt", "1000x opolisinc:draconic_bacterial_sludge", "opolisinc:draconic_bacterial_mulch").id("opolisinc:casting/draconic_bacterial_sludge")
   event.recipes.casting.solidifier("dirt", "1000x opolisinc:irradiated_bacterial_sludge", "opolisinc:irradiated_bacterial_mulch").id("opolisinc:casting/irradiated_bacterial_mulch_1")
   event.recipes.casting.solidifier("opolisinc:draconic_bacterial_mulch", "1000x opolisinc:nuclear_waste", "opolisinc:irradiated_bacterial_mulch").id("opolisinc:casting/irradiated_bacterial_mulch_2")


   //Processing Licenses
   event.recipes.casting.solidifier("casting:plate_mold", "360x opolisinc:basic_processing_alloy", "opolisinc:basic_processing_license").id("opolisinc:casting/basic_processing_license")
   event.recipes.casting.solidifier("opolisinc:basic_processing_bucks", "360x opolisinc:advanced_processing_alloy", "opolisinc:advanced_processing_license").id("opolisinc:casting/advanced_processing_license")
   event.recipes.casting.solidifier("opolisinc:advanced_processing_bucks", "360x opolisinc:elite_processing_alloy", "opolisinc:elite_processing_license").id("opolisinc:casting/elite_processing_license")
   event.recipes.casting.solidifier("opolisinc:elite_processing_bucks", "360x opolisinc:ultimate_processing_alloy", "opolisinc:ultimate_processing_license").id("opolisinc:casting/ultimate_processing_license")

   event.remove({ id: 'powah:crafting/dielectric_rod_h' })
   event.remove({ id: 'powah:crafting/dielectric_rod' })

   //Alloy Essences
   event.recipes.casting.melting("mysticalagriculture:steel_essence", "10x casting:molten_steel", 1000).id("opolisinc:melting/steel_essence")
   event.recipes.casting.melting("mysticalagriculture:bronze_essence", "10x casting:molten_bronze", 1000).id("opolisinc:melting/bronze_essence")
   event.recipes.casting.melting("mysticalagriculture:brass_essence", "10x casting:molten_brass", 1000).id("opolisinc:melting/brass_essence")
   event.recipes.casting.melting("mysticalagriculture:invar_essence", "10x casting:molten_invar", 1000).id("opolisinc:melting/invar_essence")
   event.recipes.casting.melting("mysticalagriculture:constantan_essence", "10x casting:molten_constantan", 1000).id("opolisinc:melting/constantan_essence")
   event.recipes.casting.melting("mysticalagriculture:electrum_essence", "10x casting:molten_electrum", 1000).id("opolisinc:melting/electrum_essence")
   event.remove({ input: "mysticalagriculture:steel_essence" })
   event.remove({ input: "mysticalagriculture:bronze_essence" })
   event.remove({ input: "mysticalagriculture:brass_essence" })
   event.remove({ input: "mysticalagriculture:invar_essence" })
   event.remove({ input: "mysticalagriculture:constantan_essence" })
   event.remove({ input: "mysticalagriculture:electrum_essence" })

})
