const letters = ["a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z"]
const vips = ["ExaltedZoro", "benbenlaw", "GamingOnCaffeine", "JANKYnik", "DrSpilikin", "Szszabi2002"]

function SL(item) {
    return "opolisinc:specialised_license_" + item
}

function caeser_encode(name) {
    var name_array = name.split("")
    var uppercase
    var encoded_name = ""
    for (let i = 0; i < name_array.length; i++) {
        uppercase = false
        var letter = name_array[i]
        var lowercase_letter = letter.toLowerCase()

        if (letters.includes(lowercase_letter) == false) {
            continue
        }

        if (letters.includes(letter) == false) {
            uppercase = true
        }
        for (let j = 0; j < letters.length; j++) {
            if (letters[j] == lowercase_letter) {
                if (uppercase) {
                    encoded_name += letters[(j + 7) % 26].toUpperCase()
                } else {
                    encoded_name += letters[(j + 7) % 26]
                }
                break
            }
        }
    }
    return encoded_name
}