console.info('Loading server_events.js for Opolis Inc')
// priority: 0

// Visit the wiki for more info - https://kubejs.com/
ServerEvents.loaded(event => {

  if (event.server.persistentData.gameRules) return
  event.server.gameRules.set("doTraderSpawning", false)
  event.server.persistentData.gameRules = true

})

ServerEvents.command(event => {

  /*
  if (event.commandName === "reload") {
    event.server.tell("STOP BEN or EXALTED + 1 on reload count, tut tut when will you learn!")
  }
  */

})

ItemEvents.rightClicked("opolisinc:radiation_relief", event => {
  event.server.runCommandSilent("mek radiation removeAll")
  event.item.count--
})

/*ItemEvents.rightClicked(["opolisinc:villager_receipt_1", "opolisinc:villager_receipt_2", "opolisinc:villager_receipt_3", "opolisinc:villager_receipt_4", "opolisinc:villager_receipt_5", "opolisinc:piglin_receipt", "opolisinc:queen_receipt"], event => {
  if (event.target.block.id == "biomesoplenty:liquid_null") {
    event.item.count--
    event.player.give("opolisinc:null_receipt")
    if (!event.player.persistentData.null_trade) {
      if (vips.includes(event.player.displayName.getString())) {
        event.player.tell("<���> Dhpa, hyl fvb aol ylhs "+ caeser_encode(event.player.displayName.getString()) +"? Pa'z nylha av tlla fvb, P't zbjo h ipn mhu!")
      } else {
        event.player.tell("<���> Olf aolyl, ibkkf. Fvb nva fvbyzlsm h klhs.")
      }
      event.player.persistentData.null_trade = true
    }
  }
})*/

PlayerEvents.inventoryChanged(event => {
  if (!event.player.persistentData.null_trade && event.player.inventory.contains("opolisinc:null_receipt")) {
    if (vips.includes(event.player.displayName.getString())) {
      event.player.tell("<���> Dhpa, hyl fvb aol ylhs " + caeser_encode(event.player.displayName.getString()) + "? Pa'z nylha av tlla fvb, P't zbjo h ipn mhu!")
    } else {
      event.player.tell("<���> Olf aolyl, ibkkf. Fvb nva fvbyzlsm h klhs.")
    }
    event.player.persistentData.null_trade = true
  } else if (!event.player.persistentData.null_trade_2 && event.player.inventory.contains("opolisinc:fragments_of_the_end")) {
    event.player.tell("<���> Vo, aopz pz lclu tvyl pualylzapun. P aopur P't nvpun av luqvf vby spaasl whyaulyzopw. Qbza thrl zbyl fvb ovsk fvby luk vm aol ihynhpu.")
    event.player.persistentData.null_trade_2 = true
  }
})

const MapItem = Java.loadClass("net.minecraft.world.item.MapItem");
const MapItemSavedData = Java.loadClass("net.minecraft.world.level.saveddata.maps.MapItemSavedData");
function createMapItem(level, position) {
  if (position == null) {
    return null;
  }

  var mapViewScale = 2;
  var trackPos = true;
  var unlimitedTracking = true;
  var item = MapItem.create(level, position.x, position.z, mapViewScale, trackPos, unlimitedTracking);
  MapItem.renderBiomePreviewMap(level, item);
  MapItemSavedData.addTargetDecoration(item, position, "+", "red_x")
  return item;
}

ItemEvents.rightClicked("opolisinc:corruption_map", event => {
  let corruptionBiome = MoreUtils.findBiome(event.player.getOnPos(), event.getLevel(), "biomesoplenty:end_corruption", 128)
  var item = createMapItem(event.player.getLevel(), corruptionBiome)//.setHoverName("Map To Reality Corruption")
  event.player.give(item)
  event.item.count--
})

ItemEvents.rightClicked("opolisinc:throne_pillar_map", event => {

  if (event.level.dimension == "the_bumblezone:the_bumblezone") {

    let throneStructure = MoreUtils.findStructure(event.player.getOnPos(), event.getLevel(), "the_bumblezone:throne_pillar", 1024)
    var item = createMapItem(event.player.getLevel(), throneStructure)//.setHoverName("Map to Throne Pillar")
    event.player.give(item)
    event.item.count--

  } else {
    event.player.tell("Try in The Bumblezone")

  }
})

ItemEvents.rightClicked("opolisinc:cosmic_currency", event => {
  event.level.runCommandSilent("playsound opolisinc:time_echo player " + event.player.displayName.getString())
})

BlockEvents.rightClicked("opolisinc:central_routing_node", event => {
  if (event.hand != "MAIN_HAND") {
    return
  }
  var other_parts = ["opolisinc:superposition_storage_drive", "opolisinc:universal_adapter", "opolisinc:bio_neural_processor", "opolisinc:time_crystal_power_conduit", "opolisinc:galactic_simulator", "opolisinc:nebulous_negotiator"]
  var block = event.block

  //Validate the bottom four blocks
  if (other_parts.includes(block.down.north.west.id.toString())) {
    other_parts.splice(other_parts.indexOf(block.down.north.west.id.toString()), 1)
  } else {
    return
  }

  if (other_parts.includes(block.down.north.east.id.toString())) {
    other_parts.splice(other_parts.indexOf(block.down.north.east.id.toString()), 1)
  } else {
    return
  }

  if (other_parts.includes(block.down.south.west.id.toString())) {
    other_parts.splice(other_parts.indexOf(block.down.south.west.id.toString()), 1)
  } else {
    return
  }

  if (other_parts.includes(block.down.south.east.id.toString())) {
    other_parts.splice(other_parts.indexOf(block.down.south.east.id.toString()), 1)
  } else {
    return
  }

  //If there is a block at north, check south. Otherwise check west and east
  if (other_parts.includes(block.up.north.id.toString())) {
    other_parts.splice(other_parts.indexOf(block.up.north.id.toString()), 1)
    if (other_parts.includes(block.up.south.id.toString())) {
      completeComputer(event, true)
    }
  } else {
    if (other_parts.includes(block.up.east.id.toString())) {
      other_parts.splice(other_parts.indexOf(block.up.north.id.toString()), 1)
      if (other_parts.includes(block.up.west.id.toString())) {
        completeComputer(event, false)
      }
    }
  }

})

function completeComputer(event, north) {
  var block = event.block
  event.level.runCommandSilent("playsound minecraft:block.beacon.activate block @a " + block.x + " " + block.y + " " + block.z)
  event.server.scheduleInTicks(40, callback => {
    event.level.runCommandSilent("playsound minecraft:block.beacon.ambient block @a " + block.x + " " + block.y + " " + block.z)
    event.server.scheduleInTicks(90, callback => {
      event.level.runCommandSilent("playsound minecraft:block.beacon.ambient block @a " + block.x + " " + block.y + " " + block.z)
      event.server.scheduleInTicks(90, callback => {
        event.level.runCommandSilent("playsound minecraft:block.beacon.ambient block @a " + block.x + " " + block.y + " " + block.z)
        event.server.scheduleInTicks(90, callback => {
          event.level.runCommandSilent("playsound minecraft:block.beacon.ambient block @a " + block.x + " " + block.y + " " + block.z)
          event.level.runCommandSilent("playsound opolisinc:time_echo block @a " + block.x + " " + block.y + " " + block.z + " 0.5")
          event.server.scheduleInTicks(90, callback => {
            event.level.runCommandSilent("playsound minecraft:block.beacon.deactivate block @a " + block.x + " " + block.y + " " + block.z)
            event.block.up.popItem(Item.of("opolisinc:cosmic_currency"))
          })
        })
      })
    })
  })
}

