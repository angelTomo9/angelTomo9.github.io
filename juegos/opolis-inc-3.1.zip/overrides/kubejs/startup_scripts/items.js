// priority: 0
Platform.mods.kubejs.name = 'Opolis Inc'

StartupEvents.registry("item", (event) => {

  //Starting License
  event.create('opolisinc:starting_license').maxDamage(20).texture('opolisinc:item/basic_license').color(0, 0xFFE251).tag(['market:licenses', 'opolisutilities:banned_in_item_repairer']).tag('opolisinc:starting_license')

  //Mining License
  event.create('opolisinc:basic_mining_license').maxDamage(20).texture('opolisinc:item/basic_license').tag(['market:licenses', 'opolisutilities:banned_in_item_repairer']).tag('opolisinc:basic_mining_license')
  event.create("opolisinc:basic_mining_fragment").texture("opolisinc:item/license_fragment")
  event.create('opolisinc:advanced_mining_license').maxDamage(20).texture('opolisinc:item/advanced_license').tag(['market:licenses', 'opolisutilities:banned_in_item_repairer']).tag('opolisinc:advanced_mining_license')
  event.create("opolisinc:advanced_mining_fragment").texture("opolisinc:item/license_fragment")
  event.create('opolisinc:elite_mining_license').maxDamage(20).texture('opolisinc:item/elite_license').tag(['market:licenses', 'opolisutilities:banned_in_item_repairer']).tag('opolisinc:elite_mining_license')
  event.create("opolisinc:elite_mining_fragment").texture("opolisinc:item/license_fragment")
  event.create('opolisinc:ultimate_mining_license').maxDamage(20).texture('opolisinc:item/ultimate_license').tag(['market:licenses', 'opolisutilities:banned_in_item_repairer']).tag('opolisinc:ultimate_mining_license')
  event.create("opolisinc:ultimate_mining_fragment").texture("opolisinc:item/license_fragment")
  event.create('opolisinc:unbreakable_basic_mining_license').texture('opolisinc:item/basic_license').tag('market:licenses').glow(true).tag('opolisinc:basic_mining_license')
  event.create('opolisinc:unbreakable_advanced_mining_license').texture('opolisinc:item/advanced_license').tag('market:licenses').glow(true).tag('opolisinc:advanced_mining_license')
  event.create('opolisinc:unbreakable_elite_mining_license').texture('opolisinc:item/elite_license').tag('market:licenses').glow(true).tag('opolisinc:elite_mining_license')
  event.create('opolisinc:unbreakable_ultimate_mining_license').texture('opolisinc:item/ultimate_license').tag('market:licenses').glow(true).tag('opolisinc:ultimate_mining_license')
  event.create("opolisinc:drill_license").texture("opolisinc:item/basic_license").tag(["market:licenses", "market:no_demand"]).color(0, 0xA8FFFB)

  event.create('opolisinc:basic_mining_bucks').texture('opolisinc:item/basic_bucks')
  event.create('opolisinc:advanced_mining_bucks').texture('opolisinc:item/advanced_bucks')
  event.create('opolisinc:elite_mining_bucks').texture('opolisinc:item/elite_bucks')
  event.create('opolisinc:ultimate_mining_bucks').texture('opolisinc:item/ultimate_bucks')
  //event.create("opolisinc:supreme_mining_bucks").texture("opolisinc:item/ultimate_bucks").glow(true)

  //Processing License
  event.create('opolisinc:basic_processing_license').maxDamage(20).texture('opolisinc:item/basic_license').color(0, 0x7766FF).tag(['market:licenses', 'opolisutilities:banned_in_item_repairer']).tag('opolisinc:basic_processing_license')
  event.create('opolisinc:advanced_processing_license').maxDamage(20).texture('opolisinc:item/advanced_license').color(0, 0x7766FF).tag(['market:licenses', 'opolisutilities:banned_in_item_repairer']).tag('opolisinc:advanced_processing_license')
  event.create('opolisinc:elite_processing_license').maxDamage(20).texture('opolisinc:item/elite_license').color(0, 0x7766FF).tag(['market:licenses', 'opolisutilities:banned_in_item_repairer']).tag('opolisinc:elite_processing_license')
  event.create('opolisinc:ultimate_processing_license').maxDamage(20).texture('opolisinc:item/ultimate_license').color(0, 0x7766FF).tag(['market:licenses', 'opolisutilities:banned_in_item_repairer']).tag('opolisinc:ultimate_processing_license')
  event.create('opolisinc:unbreakable_basic_processing_license').texture('opolisinc:item/basic_license').color(0, 0x7766FF).tag('market:licenses').glow(true).tag('opolisinc:basic_processing_license')
  event.create('opolisinc:unbreakable_advanced_processing_license').texture('opolisinc:item/advanced_license').color(0, 0x7766FF).tag('market:licenses').glow(true).tag('opolisinc:advanced_processing_license')
  event.create('opolisinc:unbreakable_elite_processing_license').texture('opolisinc:item/elite_license').color(0, 0x7766FF).tag('market:licenses').glow(true).tag('opolisinc:elite_processing_license')
  event.create('opolisinc:unbreakable_ultimate_processing_license').texture('opolisinc:item/ultimate_license').color(0, 0x7766FF).tag('market:licenses').glow(true).tag('opolisinc:ultimate_processing_license')

  event.create('opolisinc:basic_processing_bucks').texture('opolisinc:item/basic_bucks').color(0, 0x7766FF)
  event.create('opolisinc:advanced_processing_bucks').texture('opolisinc:item/advanced_bucks').color(0, 0x7766FF)
  event.create('opolisinc:elite_processing_bucks').texture('opolisinc:item/elite_bucks').color(0, 0x7766FF)
  event.create('opolisinc:ultimate_processing_bucks').texture('opolisinc:item/ultimate_bucks').color(0, 0x7766FF)
  //event.create("opolisinc:supreme_processing_bucks").texture("opolisinc:item/ultimate_bucks").color(0, 0x7766FF).glow(true)

  //Farming License
  event.create('opolisinc:basic_farming_license').maxDamage(20).texture('opolisinc:item/basic_license').color(0, 0x094913).tag(['market:licenses', 'opolisutilities:banned_in_item_repairer']).tag('opolisinc:basic_farming_license')
  event.create('opolisinc:advanced_farming_license').maxDamage(20).texture('opolisinc:item/advanced_license').color(0, 0x094913).tag(['market:licenses', 'opolisutilities:banned_in_item_repairer']).tag('opolisinc:advanced_farming_license')
  event.create('opolisinc:elite_farming_license').maxDamage(20).texture('opolisinc:item/elite_license').color(0, 0x094913).tag(['market:licenses', 'opolisutilities:banned_in_item_repairer']).tag('opolisinc:elite_farming_license')
  event.create('opolisinc:ultimate_farming_license').maxDamage(20).texture('opolisinc:item/ultimate_license').color(0, 0x094913).tag(['market:licenses', 'opolisutilities:banned_in_item_repairer']).tag('opolisinc:ultimate_farming_license')
  event.create('opolisinc:unbreakable_basic_farming_license').texture('opolisinc:item/basic_license').color(0, 0x094913).tag('market:licenses').glow(true).tag('opolisinc:basic_farming_license')
  event.create('opolisinc:unbreakable_advanced_farming_license').texture('opolisinc:item/advanced_license').color(0, 0x094913).tag('market:licenses').glow(true).tag('opolisinc:advanced_farming_license')
  event.create('opolisinc:unbreakable_elite_farming_license').texture('opolisinc:item/elite_license').color(0, 0x094913).tag('market:licenses').glow(true).tag('opolisinc:elite_farming_license')
  event.create('opolisinc:unbreakable_ultimate_farming_license').texture('opolisinc:item/ultimate_license').color(0, 0x094913).tag('market:licenses').glow(true).tag('opolisinc:ultimate_farming_license')

  event.create('opolisinc:basic_farming_bucks').texture('opolisinc:item/basic_bucks').color(0, 0x094913)
  event.create('opolisinc:advanced_farming_bucks').texture('opolisinc:item/advanced_bucks').color(0, 0x094913)
  event.create('opolisinc:elite_farming_bucks').texture('opolisinc:item/elite_bucks').color(0, 0x094913)
  event.create('opolisinc:ultimate_farming_bucks').texture('opolisinc:item/ultimate_bucks').color(0, 0x094913)
  //event.create("opolisinc:supreme_farming_bucks").texture("opolisinc:item/ultimate_bucks").color(0, 0x094913).glow(true)

  //Bounty License
  event.create('opolisinc:basic_bounty_license').maxDamage(20).texture('opolisinc:item/basic_license').color(0, 0x47131B).tag(['market:licenses', 'opolisutilities:banned_in_item_repairer']).tag('opolisinc:basic_bounty_license')
  event.create("opolisinc:basic_bounty_fragment").texture("opolisinc:item/license_fragment").color(0, 0x47131B)
  event.create('opolisinc:advanced_bounty_license').maxDamage(20).texture('opolisinc:item/advanced_license').color(0, 0x47131B).tag(['market:licenses', 'opolisutilities:banned_in_item_repairer']).tag('opolisinc:advanced_bounty_license')
  event.create("opolisinc:advanced_bounty_fragment").texture("opolisinc:item/license_fragment").color(0, 0x47131B)
  event.create('opolisinc:elite_bounty_license').maxDamage(20).texture('opolisinc:item/elite_license').color(0, 0x47131B).tag(['market:licenses', 'opolisutilities:banned_in_item_repairer']).tag('opolisinc:elite_bounty_license')
  event.create("opolisinc:elite_bounty_fragment").texture("opolisinc:item/license_fragment").color(0, 0x47131B)
  event.create('opolisinc:ultimate_bounty_license').maxDamage(20).texture('opolisinc:item/ultimate_license').color(0, 0x47131B).tag(['market:licenses', 'opolisutilities:banned_in_item_repairer']).tag('opolisinc:ultimate_bounty_license')
  event.create("opolisinc:ultimate_bounty_fragment").texture("opolisinc:item/license_fragment").color(0, 0x47131B)
  event.create('opolisinc:unbreakable_basic_bounty_license').texture('opolisinc:item/basic_license').color(0, 0x47131B).tag('market:licenses').glow(true).tag('opolisinc:basic_bounty_license')
  event.create('opolisinc:unbreakable_advanced_bounty_license').texture('opolisinc:item/advanced_license').color(0, 0x47131B).tag('market:licenses').glow(true).tag('opolisinc:advanced_bounty_license')
  event.create('opolisinc:unbreakable_elite_bounty_license').texture('opolisinc:item/elite_license').color(0, 0x47131B).tag('market:licenses').glow(true).tag('opolisinc:elite_bounty_license')
  event.create('opolisinc:unbreakable_ultimate_bounty_license').texture('opolisinc:item/ultimate_license').color(0, 0x47131B).tag('market:licenses').glow(true).tag('opolisinc:ultimate_bounty_license')

  event.create('opolisinc:basic_bounty_bucks').texture('opolisinc:item/basic_bucks').color(0, 0x47131B)
  event.create('opolisinc:advanced_bounty_bucks').texture('opolisinc:item/advanced_bucks').color(0, 0x47131B)
  event.create('opolisinc:elite_bounty_bucks').texture('opolisinc:item/elite_bucks').color(0, 0x47131B)
  event.create('opolisinc:ultimate_bounty_bucks').texture('opolisinc:item/ultimate_bucks').color(0, 0x47131B)
  //event.create('opolisinc:supreme_bounty_bucks').texture('opolisinc:item/ultimate_bucks').color(0, 0x47131B).glow(true)

  //Power License
  event.create('opolisinc:basic_power_license').maxDamage(20).texture('opolisinc:item/basic_license').color(0, 0xFF0019).tag(['market:licenses', 'opolisutilities:banned_in_item_repairer']).tag('opolisinc:basic_power_license')
  event.create('opolisinc:advanced_power_license').maxDamage(20).texture('opolisinc:item/advanced_license').color(0, 0xFF0019).tag(['market:licenses', 'opolisutilities:banned_in_item_repairer']).tag('opolisinc:advanced_power_license')
  event.create('opolisinc:elite_power_license').maxDamage(20).texture('opolisinc:item/elite_license').color(0, 0xFF0019).tag(['market:licenses', 'opolisutilities:banned_in_item_repairer']).tag('opolisinc:elite_power_license')
  event.create('opolisinc:ultimate_power_license').maxDamage(20).texture('opolisinc:item/ultimate_license').color(0, 0xFF0019).tag(['market:licenses', 'opolisutilities:banned_in_item_repairer']).tag('opolisinc:ultimate_power_license')
  event.create('opolisinc:unbreakable_basic_power_license').texture('opolisinc:item/basic_license').color(0, 0xFF0019).tag('market:licenses').glow(true).tag('opolisinc:basic_power_license')
  event.create('opolisinc:unbreakable_advanced_power_license').texture('opolisinc:item/advanced_license').color(0, 0xFF0019).tag('market:licenses').glow(true).tag('opolisinc:advanced_power_license')
  event.create('opolisinc:unbreakable_elite_power_license').texture('opolisinc:item/elite_license').color(0, 0xFF0019).tag('market:licenses').glow(true).tag('opolisinc:elite_power_license')
  event.create('opolisinc:unbreakable_ultimate_power_license').texture('opolisinc:item/ultimate_license').color(0, 0xFF0019).tag('market:licenses').glow(true).tag('opolisinc:ultimate_power_license')
  event.create("opolisinc:nuclear_license").texture("opolisinc:item/basic_license").color(0, 0x32402D).tag(["market:licenses", "market:no_demand"])

  event.create('opolisinc:basic_power_bucks').texture('opolisinc:item/basic_bucks').color(0, 0xFF0019)
  event.create('opolisinc:advanced_power_bucks').texture('opolisinc:item/advanced_bucks').color(0, 0xFF0019)
  event.create('opolisinc:elite_power_bucks').texture('opolisinc:item/elite_bucks').color(0, 0xFF0019)
  event.create('opolisinc:ultimate_power_bucks').texture('opolisinc:item/ultimate_bucks').color(0, 0xFF0019)
  //event.create("opolisinc:supreme_power_bucks").texture("opolisinc:item/ultimate_bucks").color(0, 0xFF0019).glow(true)

  //Storage License
  event.create('opolisinc:basic_storage_license').maxDamage(20).texture('opolisinc:item/basic_license').color(0, 0xFF9D00).tag(['market:licenses', 'opolisutilities:banned_in_item_repairer']).tag('opolisinc:basic_storage_license')
  event.create('opolisinc:advanced_storage_license').maxDamage(20).texture('opolisinc:item/advanced_license').color(0, 0xFF9D00).tag(['market:licenses', 'opolisutilities:banned_in_item_repairer']).tag('opolisinc:advanced_storage_license')
  event.create('opolisinc:elite_storage_license').maxDamage(20).texture('opolisinc:item/elite_license').color(0, 0xFF9D00).tag(['market:licenses', 'opolisutilities:banned_in_item_repairer']).tag('opolisinc:elite_storage_license')
  event.create('opolisinc:ultimate_storage_license').maxDamage(20).texture('opolisinc:item/ultimate_license').color(0, 0xFF9D00).tag(['market:licenses', 'opolisutilities:banned_in_item_repairer']).tag('opolisinc:ultimate_storage_license')
  event.create('opolisinc:unbreakable_basic_storage_license').texture('opolisinc:item/basic_license').color(0, 0xFF9D00).tag('market:licenses').glow(true).tag('opolisinc:basic_storage_license')
  event.create('opolisinc:unbreakable_advanced_storage_license').texture('opolisinc:item/advanced_license').color(0, 0xFF9D00).tag('market:licenses').glow(true).tag('opolisinc:advanced_storage_license')
  event.create('opolisinc:unbreakable_elite_storage_license').texture('opolisinc:item/elite_license').color(0, 0xFF9D00).tag('market:licenses').glow(true).tag('opolisinc:elite_storage_license')
  event.create('opolisinc:unbreakable_ultimate_storage_license').texture('opolisinc:item/ultimate_license').color(0, 0xFF9D00).tag('market:licenses').glow(true).tag('opolisinc:ultimate_storage_license')
  event.create("opolisinc:data_license").texture("opolisinc:item/basic_license").color(0, 0x27968D).tag(["market:licenses", "market:no_demand"])

  event.create('opolisinc:basic_storage_bucks').texture('opolisinc:item/basic_bucks').color(0, 0xFF9D00)
  event.create('opolisinc:advanced_storage_bucks').texture('opolisinc:item/advanced_bucks').color(0, 0xFF9D00)
  event.create('opolisinc:elite_storage_bucks').texture('opolisinc:item/elite_bucks').color(0, 0xFF9D00)
  event.create('opolisinc:ultimate_storage_bucks').texture('opolisinc:item/ultimate_bucks').color(0, 0xFF9D00)
  //event.create("opolisinc:supreme_storage_bucks").texture("opolisinc:item/ultimate_bucks").color(0, 0xFF9D00).glow(true)

  //Trading License
  event.create('opolisinc:basic_trading_license').maxDamage(20).texture('opolisinc:item/basic_license').color(0, 0x3AFF3D).tag(['market:licenses', 'opolisutilities:banned_in_item_repairer']).tag('opolisinc:basic_trading_license')
  event.create('opolisinc:advanced_trading_license').maxDamage(20).texture('opolisinc:item/advanced_license').color(0, 0x3AFF3D).tag(['market:licenses', 'opolisutilities:banned_in_item_repairer']).tag('opolisinc:advanced_trading_license')
  event.create('opolisinc:elite_trading_license').maxDamage(20).texture('opolisinc:item/elite_license').color(0, 0x3AFF3D).tag(['market:licenses', 'opolisutilities:banned_in_item_repairer']).tag('opolisinc:elite_trading_license')
  event.create('opolisinc:ultimate_trading_license').maxDamage(20).texture('opolisinc:item/ultimate_license').color(0, 0x3AFF3D).tag(['market:licenses', 'opolisutilities:banned_in_item_repairer']).tag('opolisinc:ultimate_trading_license')
  event.create('opolisinc:unbreakable_basic_trading_license').texture('opolisinc:item/basic_license').color(0, 0x3AFF3D).tag('market:licenses').glow(true).tag('opolisinc:basic_trading_license')
  event.create('opolisinc:unbreakable_advanced_trading_license').texture('opolisinc:item/advanced_license').color(0, 0x3AFF3D).tag('market:licenses').glow(true).tag('opolisinc:advanced_trading_license')
  event.create('opolisinc:unbreakable_elite_trading_license').texture('opolisinc:item/elite_license').color(0, 0x3AFF3D).tag('market:licenses').glow(true).tag('opolisinc:elite_trading_license')
  event.create('opolisinc:unbreakable_ultimate_trading_license').texture('opolisinc:item/ultimate_license').color(0, 0x3AFF3D).tag('market:licenses').glow(true).tag('opolisinc:ultimate_trading_license')
  event.create("opolisinc:transaction_license").texture("opolisinc:item/basic_license").color(0, 0x363232).tag(["market:licenses", "market:no_demand"])

  event.create('opolisinc:basic_trading_bucks').texture('opolisinc:item/basic_bucks').color(0, 0x3AFF3D)
  event.create('opolisinc:advanced_trading_bucks').texture('opolisinc:item/advanced_bucks').color(0, 0x3AFF3D)
  event.create('opolisinc:elite_trading_bucks').texture('opolisinc:item/elite_bucks').color(0, 0x3AFF3D)
  event.create('opolisinc:ultimate_trading_bucks').texture('opolisinc:item/ultimate_bucks').color(0, 0x3AFF3D)
  //event.create("opolisinc:supreme_trading_bucks").texture("opolisinc:item/ultimate_bucks").color(0, 0x3AFF3D).glow(true)

  event.create("opolisinc:nether_passport_fragment_1").texture("opolisinc:item/nether_passport_fragment")
  event.create("opolisinc:nether_passport_fragment_2").texture("opolisinc:item/nether_passport_fragment")
  event.create("opolisinc:nether_passport_fragment_3").texture("opolisinc:item/nether_passport_fragment")
  event.create("opolisinc:nether_passport_fragment_4").texture("opolisinc:item/nether_passport_fragment")
  event.create("opolisinc:nether_passport_fragment_5").texture("opolisinc:item/nether_passport_fragment")

  event.create("opolisinc:villager_receipt_1").texture("opolisinc:item/receipt").tag(["opolisinc:villager_receipt_1", "opolisinc:receipts"])
  event.create("opolisinc:villager_receipt_2").texture("opolisinc:item/receipt").tag(["opolisinc:villager_receipt_2", "opolisinc:receipts"])
  event.create("opolisinc:villager_receipt_3").texture("opolisinc:item/receipt").tag(["opolisinc:villager_receipt_3", "opolisinc:receipts"])
  event.create("opolisinc:villager_receipt_4").texture("opolisinc:item/receipt").tag(["opolisinc:villager_receipt_4", "opolisinc:receipts"])
  event.create("opolisinc:villager_receipt_5").texture("opolisinc:item/receipt").tag(["opolisinc:villager_receipt_5", "opolisinc:receipts"])

  event.create("opolisinc:shredded_villager_receipt").texture("opolisinc:item/shredded_receipt")
  event.create("opolisinc:restored_villager_receipt").texture("opolisinc:item/restored_receipt").tag(["opolisinc:villager_receipt_1", "opolisinc:villager_receipt_2", "opolisinc:villager_receipt_3", "opolisinc:villager_receipt_4", "opolisinc:villager_receipt_5"])

  event.create("opolisinc:piglin_receipt").texture("opolisinc:item/receipt").color(0, 0xFF6549).tag(["opolisinc:piglin_receipt", "opolisinc:receipts"])
  event.create("opolisinc:shredded_piglin_receipt").texture("opolisinc:item/shredded_receipt").color(0, 0xFF6549)
  event.create("opolisinc:restored_piglin_receipt").texture("opolisinc:item/restored_receipt").color(0, 0xFF6549).tag("opolisinc:piglin_receipt")

  event.create("opolisinc:queen_receipt").texture("opolisinc:item/receipt").color(0, 0xFF964C).tag(["opolisinc:queen_receipt", "opolisinc:receipts"])
  event.create("opolisinc:shredded_queen_receipt").texture("opolisinc:item/shredded_receipt").color(0, 0xFF964C)
  event.create("opolisinc:restored_queen_receipt").texture("opolisinc:item/restored_receipt").color(0, 0xFF964C).tag("opolisinc:queen_receipt")

  event.create("opolisinc:null_receipt").displayName("���� �������").texture("opolisinc:item/receipt").color(0, 0x9F25DB).tag("opolisinc:null_receipt")
  event.create("opolisinc:shredded_null_receipt").displayName("�������� ���� �������").texture("opolisinc:item/shredded_receipt").color(0, 0x9F25DB)
  event.create("opolisinc:restored_null_receipt").displayName("�������� ���� �������").texture("opolisinc:item/restored_receipt").color(0, 0x9F25DB).tag("opolisinc:null_receipt")

  //Misc
  event.create("opolisinc:withered_bone").texture("minecraft:item/bone").color(0, 0x1F1F1F)
  event.create("opolisinc:activated_ender_pearl").texture("minecraft:item/ender_pearl").glow(true)
  event.create("opolisinc:radiation_relief").displayName("Radiation Relief TM")
  event.create("opolisinc:nether_passport").displayName("Nether Passport").tooltip("Authorizes travel to the Nether").displayName("Nether Passport")
  event.create("opolisinc:end_passport").tooltip("Authorizes travel to the End").displayName("End Passport")
  event.create("opolisinc:corruption_map").texture("minecraft:item/map").tooltip("Right click to point the way to a Reality Corruption").glow(true)
  event.create("opolisinc:throne_pillar_map").texture("minecraft:item/map").tooltip("Right click in The Bumblezone to locate the Throne Pillar").glow(true)
  event.create("opolisinc:deep_dark_map").texture("minecraft:item/map").tooltip("Right click to point the way to the Deep Dark").glow(true)

  event.create("opolisinc:quantum_processor")
  event.create("opolisinc:shattered_singularity")
  event.create("opolisinc:reality_seeds").tooltip("Seeds of reality itself, these cannot be grown in world!")
  event.create("opolisinc:ancient_data")
  event.create("opolisinc:plasma_tipped_drill_bit").displayName("Plasma-tipped Drill Bit")


  //ENDGAME ITEMS
  event.create("opolisinc:fragments_of_the_overworld").texture("opolisinc:item/dimension_fragment").color(0, 0x138F34)
  event.create("opolisinc:fragments_of_the_nether").texture("opolisinc:item/dimension_fragment").color(0, 0x8C200D)
  event.create("opolisinc:fragments_of_the_bumblezone").texture("opolisinc:item/dimension_fragment").color(0, 0xBD8F11)
  event.create("opolisinc:fragments_of_the_end").texture("opolisinc:item/dimension_fragment").color(0, 0x9711BD)
  event.create("opolisinc:monodimensional_transactor")

  event.create("opolisinc:impure_opolisite_ingot").tag("c:ingots")
  event.create("opolisinc:inert_opolisite_ingot").tag("c:ingots")

  event.create("opolisinc:opolisite_ingot").tag("c:ingots")
  event.create("opolisinc:opolisite_nugget").tag("c:nuggets")

  event.create("opolisinc:opolisite_circuit_board")
  event.create("opolisinc:cosmic_roots")
  event.create("opolisinc:mutated_supercell")
  event.create("opolisinc:nitro_temporal_lattice").displayName("Nitro-temporal Lattice")
  event.create("opolisinc:miniaturised_planetoid")
  event.create("opolisinc:interdimensional_transactor")
  event.create("opolisinc:quantum_encoded_storage_component")

  event.create("opolisinc:cosmic_currency").glow(true).tooltip("ℸ ̣╎ᒲᒷꖎᒷᓭᓭ, ⍑╎ᓭℸ ̣𝙹∷|| ᔑ∴ᔑ╎ℸ ̣ᓭ ||𝙹⚍").unstackable()
  //Activated Resources
  event.create("opolisinc:activated_raw_iron").texture("minecraft:item/raw_iron").glow(true).tag("opolisinc:activated_ore")
  event.create("opolisinc:activated_raw_copper").texture("minecraft:item/raw_copper").glow(true).tag("opolisinc:activated_ore")
  event.create("opolisinc:activated_raw_gold").texture("minecraft:item/raw_gold").glow(true).tag("opolisinc:activated_ore")
  event.create("opolisinc:activated_raw_aluminum").texture("alltheores:item/raw_aluminum").glow(true).tag("opolisinc:activated_ore")
  event.create("opolisinc:activated_raw_lead").texture("alltheores:item/raw_lead").glow(true).tag("opolisinc:activated_ore")
  event.create("opolisinc:activated_raw_nickel").texture("alltheores:item/raw_nickel").glow(true).tag("opolisinc:activated_ore")
  event.create("opolisinc:activated_raw_osmium").texture("alltheores:item/raw_osmium").glow(true).tag("opolisinc:activated_ore")
  event.create("opolisinc:activated_raw_platinum").texture("alltheores:item/raw_platinum").glow(true).tag("opolisinc:activated_ore")
  event.create("opolisinc:activated_raw_silver").texture("alltheores:item/raw_silver").glow(true).tag("opolisinc:activated_ore")
  event.create("opolisinc:activated_raw_tin").texture("alltheores:item/raw_tin").glow(true).tag("opolisinc:activated_ore")
  event.create("opolisinc:activated_raw_uranium").texture("alltheores:item/raw_uranium").glow(true).tag("opolisinc:activated_ore")
  event.create("opolisinc:activated_raw_zinc").texture("alltheores:item/raw_zinc").glow(true).tag("opolisinc:activated_ore")
  event.create("opolisinc:activated_raw_iridium").texture("alltheores:item/raw_iridium").glow(true).tag("opolisinc:activated_ore")

  event.create("opolisinc:activated_enderium_ingot").texture("alltheores:item/enderium_ingot").glow(true).tag("c:ingots")
  event.create("opolisinc:activated_signalum_ingot").texture("alltheores:item/signalum_ingot").glow(true).tag("c:ingots")
  event.create("opolisinc:activated_lumium_ingot").texture("alltheores:item/lumium_ingot").glow(true).tag("c:ingots")

  event.create("opolisinc:activation_essence").glow(true)

  //Farming Stuff
  event.create("opolisinc:speed_gene").displayName("SP-33-D Gene")
  event.create("opolisinc:nocturn_gene").displayName("N0C-1URN Gene")
  event.create("opolisinc:hot_gene").displayName("H0-T Gene")
  event.create("opolisinc:phase_gene").displayName("PH-4-S3 Gene")

  event.create("opolisinc:gm_wheat").texture("minecraft:item/wheat").glow(true).displayName("GM Wheat")
  event.create("opolisinc:gm_potato").texture("minecraft:item/potato").glow(true).displayName("GM Potato")
  event.create("opolisinc:gm_carrot").texture("minecraft:item/carrot").glow(true).displayName("GM Carrot")
  event.create("opolisinc:gm_beetroot").texture("minecraft:item/beetroot").glow(true).displayName("GM Beetroot")

  event.create("opolisinc:sculked_wheat")
  event.create("opolisinc:sculked_carrot")
  event.create("opolisinc:sculked_potato")
  event.create("opolisinc:sculked_beetroot")
  event.create("opolisinc:gm_sculked_wheat").texture("opolisinc:item/sculked_wheat").glow(true).displayName("GM Sculked Wheat")
  event.create("opolisinc:gm_sculked_carrot").texture("opolisinc:item/sculked_carrot").glow(true).displayName("GM Sculked Carrot")
  event.create("opolisinc:gm_sculked_potato").texture("opolisinc:item/sculked_potato").glow(true).displayName("GM Sculked Potato")
  event.create("opolisinc:gm_sculked_beetroot").texture("opolisinc:item/sculked_beetroot").glow(true).displayName("GM Sculked Beetroot")

  event.create("opolisinc:gm_weeping_vines").texture("minecraft:block/weeping_vines_plant").glow(true).displayName("GM Weeping Vines")
  event.create("opolisinc:gm_twisting_vines").texture("minecraft:block/twisting_vines_plant").glow(true).displayName("GM Twisting Vines")

  event.create("opolisinc:phased_wheat")
  event.create("opolisinc:phased_carrot")
  event.create("opolisinc:phased_potato")
  event.create("opolisinc:phased_beetroot")
  event.create("opolisinc:gm_phased_wheat").texture("opolisinc:item/phased_wheat").glow(true).displayName("GM Phased Wheat")
  event.create("opolisinc:gm_phased_carrot").texture("opolisinc:item/phased_carrot").glow(true).displayName("GM Phased Carrot")
  event.create("opolisinc:gm_phased_potato").texture("opolisinc:item/phased_potato").glow(true).displayName("GM Phased Potato")
  event.create("opolisinc:gm_phased_beetroot").texture("opolisinc:item/phased_beetroot").glow(true).displayName("GM Phased Beetroot")

  //Specialised Licenses
  event.create("opolisinc:specialised_license_chicken").texture("opolisinc:item/bounty_license").maxDamage(40).color(0, 0xEBB9A2).tag(["market:licenses", "opolisutilities:banned_in_item_repairer"]).displayName("Specialised Chicken License")
  event.create("opolisinc:specialised_license_leather").texture("opolisinc:item/bounty_license").maxDamage(40).color(0, 0x592D2D).tag(["market:licenses", "opolisutilities:banned_in_item_repairer"]).displayName("Specialised Leather License")
  event.create("opolisinc:specialised_license_beef").texture("opolisinc:item/bounty_license").maxDamage(40).color(0, 0xC22727).tag(["market:licenses", "opolisutilities:banned_in_item_repairer"]).displayName("Specialised Beef License")
  event.create("opolisinc:specialised_license_porkchop").texture("opolisinc:item/bounty_license").maxDamage(40).color(0, 0xE07E9A).tag(["market:licenses", "opolisutilities:banned_in_item_repairer"]).displayName("Specialised Porkchop License")
  event.create("opolisinc:specialised_license_mutton").texture("opolisinc:item/bounty_license").maxDamage(40).color(0, 0xC24040).tag(["market:licenses", "opolisutilities:banned_in_item_repairer"]).displayName("Specialised Mutton License")
  event.create("opolisinc:specialised_license_ink_sac").texture("opolisinc:item/bounty_license").maxDamage(40).color(0, 0x413A54).tag(["market:licenses", "opolisutilities:banned_in_item_repairer"]).displayName("Specialised Ink Sac License")
  event.create("opolisinc:specialised_license_feather").texture("opolisinc:item/bounty_license").maxDamage(40).color(0, 0xEDEDED).tag(["market:licenses", "opolisutilities:banned_in_item_repairer"]).displayName("Specialised Feather License")

  event.create("opolisinc:specialised_license_rotten_flesh").texture("opolisinc:item/bounty_license").maxDamage(40).color(0, 0x382020).tag(["market:licenses", "opolisutilities:banned_in_item_repairer"]).displayName("Specialised Rotten Flesh License")
  event.create("opolisinc:specialised_license_bone").texture("opolisinc:item/bounty_license").maxDamage(40).color(0, 0xD9D3C7).tag(["market:licenses", "opolisutilities:banned_in_item_repairer"]).displayName("Specialised Bone License")
  event.create("opolisinc:specialised_license_gunpowder").texture("opolisinc:item/bounty_license").maxDamage(40).color(0, 0x474747).tag(["market:licenses", "opolisutilities:banned_in_item_repairer"]).displayName("Specialised Gunpowder License")
  event.create("opolisinc:specialised_license_spider_eye").texture("opolisinc:item/bounty_license").maxDamage(40).color(0, 0xC73C3C).tag(["market:licenses", "opolisutilities:banned_in_item_repairer"]).displayName("Specialised Spider Eye License")
  event.create("opolisinc:specialised_license_arrow").texture("opolisinc:item/bounty_license").maxDamage(40).color(0, 0x361919).tag(["market:licenses", "opolisutilities:banned_in_item_repairer"]).displayName("Specialised Arrow License")
  event.create("opolisinc:specialised_license_ender_pearl").texture("opolisinc:item/bounty_license").maxDamage(40).color(0, 0x0A545C).tag(["market:licenses", "opolisutilities:banned_in_item_repairer"]).displayName("Specialised Ender Pearl License")
  event.create("opolisinc:specialised_license_breeze_rod").texture("opolisinc:item/bounty_license").maxDamage(40).color(0, 0x5D9EBA).tag(["market:licenses", "opolisutilities:banned_in_item_repairer"]).displayName("Specialised Breeze Rod License")

  event.create("opolisinc:specialised_license_blaze_rod").texture("opolisinc:item/bounty_license").maxDamage(40).color(0, 0xFFC65C).tag(["market:licenses", "opolisutilities:banned_in_item_repairer"]).displayName("Specialised Blaze Rod License")
  event.create("opolisinc:specialised_license_ghast_tear").texture("opolisinc:item/bounty_license").maxDamage(40).color(0, 0xC7C7FC).tag(["market:licenses", "opolisutilities:banned_in_item_repairer"]).displayName("Specialised Ghast Tear License")
  event.create("opolisinc:specialised_license_withered_bone").texture("opolisinc:item/bounty_license").maxDamage(40).color(0, 0x1F1F1F).tag(["market:licenses", "opolisutilities:banned_in_item_repairer"]).displayName("Specialised Withered Bone License")

  event.create("opolisinc:specialised_license_shulker_shell").texture("opolisinc:item/bounty_license").maxDamage(40).color(0, 0xBC57FF).tag(["market:licenses", "opolisutilities:banned_in_item_repairer"]).displayName("Specialised Shulker Shell License")
  event.create("opolisinc:specialised_license_activated_ender_pearl").texture("opolisinc:item/bounty_license").maxDamage(40).color(0, 0x0E7480).tag(["market:licenses", "opolisutilities:banned_in_item_repairer"]).displayName("Specialised Activated Ender Pearl License")

  event.create("opolisinc:specialised_license_coal").texture("opolisinc:item/power_license").maxDamage(40).color(0, 0x292929).tag(["market:licenses", "opolisutilities:banned_in_item_repairer"]).displayName("Specialised Coal License")
  event.create("opolisinc:specialised_license_redstone").texture("opolisinc:item/power_license").maxDamage(40).color(0, 0xA80000).tag(["market:licenses", "opolisutilities:banned_in_item_repairer"]).displayName("Specialised Redstone License")

  event.create("opolisinc:specialised_license_niotic_capacitor").texture("opolisinc:item/power_license").maxDamage(40).color(0, 0x3BC1FF).tag(["market:licenses", "opolisutilities:banned_in_item_repairer"]).displayName("Specialised Niotic Capacitor License")
  event.create("opolisinc:specialised_license_spirited_capacitor").texture("opolisinc:item/power_license").maxDamage(40).color(0, 0x47D400).tag(["market:licenses", "opolisutilities:banned_in_item_repairer"]).displayName("Specialised Spirited Capacitor License")

  event.create("opolisinc:specialised_license_aluminum").texture("opolisinc:item/processing_license").maxDamage(40).color(0, 0xB1BDBC).tag(["market:licenses", "opolisutilities:banned_in_item_repairer"]).displayName("Specialised Aluminum License")
  event.create("opolisinc:specialised_license_tin").texture("opolisinc:item/processing_license").maxDamage(40).color(0, 0xA6E0DD).tag(["market:licenses", "opolisutilities:banned_in_item_repairer"]).displayName("Specialised Tin License")
  event.create("opolisinc:specialised_license_glass").texture("opolisinc:item/processing_license").maxDamage(40).color(0, 0xFFFFFF).tag(["market:licenses", "opolisutilities:banned_in_item_repairer"]).displayName("Specialised Glass License")
  event.create("opolisinc:specialised_license_copper").texture("opolisinc:item/processing_license").maxDamage(40).color(0, 0xFF7033).tag(["market:licenses", "opolisutilities:banned_in_item_repairer"]).displayName("Specialised Copper License")
  event.create("opolisinc:specialised_license_iron").texture("opolisinc:item/processing_license").maxDamage(40).color(0, 0xEBEBEB).tag(["market:licenses", "opolisutilities:banned_in_item_repairer"]).displayName("Specialised Iron License")
  event.create("opolisinc:specialised_license_lead").texture("opolisinc:item/processing_license").maxDamage(40).color(0, 0x5E7D91).tag(["market:licenses", "opolisutilities:banned_in_item_repairer"]).displayName("Specialised Lead License")
  event.create("opolisinc:specialised_license_nickel").texture("opolisinc:item/processing_license").maxDamage(40).color(0, 0xFFFDBD).tag(["market:licenses", "opolisutilities:banned_in_item_repairer"]).displayName("Specialised Nickel License")
  event.create("opolisinc:specialised_license_zinc").texture("opolisinc:item/processing_license").maxDamage(40).color(0, 0x9FC9C7).tag(["market:licenses", "opolisutilities:banned_in_item_repairer"]).displayName("Specialised Zinc License")
  event.create("opolisinc:specialised_license_silver").texture("opolisinc:item/processing_license").maxDamage(40).color(0, 0xEDEDED).tag(["market:licenses", "opolisutilities:banned_in_item_repairer"]).displayName("Specialised Silver License")

  event.create("opolisinc:specialised_license_infused_alloy").texture("opolisinc:item/processing_license").maxDamage(40).color(0, 0xD40000).tag(["market:licenses", "opolisutilities:banned_in_item_repairer"]).displayName("Specialised Infused Alloy License")
  event.create("opolisinc:specialised_license_bronze").texture("opolisinc:item/processing_license").maxDamage(40).color(0, 0xFF642B).tag(["market:licenses", "opolisutilities:banned_in_item_repairer"]).displayName("Specialised Bronze License")
  event.create("opolisinc:specialised_license_steel").texture("opolisinc:item/processing_license").maxDamage(40).color(0, 0x5C5C5C).tag(["market:licenses", "opolisutilities:banned_in_item_repairer"]).displayName("Specialised Steel License")
  event.create("opolisinc:specialised_license_invar").texture("opolisinc:item/processing_license").maxDamage(40).color(0, 0xDAE8E0).tag(["market:licenses", "opolisutilities:banned_in_item_repairer"]).displayName("Specialised Invar License")
  event.create("opolisinc:specialised_license_electrum").texture("opolisinc:item/processing_license").maxDamage(40).color(0, 0xFFFF70).tag(["market:licenses", "opolisutilities:banned_in_item_repairer"]).displayName("Specialised Electrum License")
  event.create("opolisinc:specialised_license_constantan").texture("opolisinc:item/processing_license").maxDamage(40).color(0, 0xBA9E00).tag(["market:licenses", "opolisutilities:banned_in_item_repairer"]).displayName("Specialised Constantan License")
  event.create("opolisinc:specialised_license_brass").texture("opolisinc:item/processing_license").maxDamage(40).color(0, 0xFFAF19).tag(["market:licenses", "opolisutilities:banned_in_item_repairer"]).displayName("Specialised Brass License")

  event.create("opolisinc:specialised_license_signalum").texture("opolisinc:item/processing_license").maxDamage(40).color(0, 0xFF7614).tag(["market:licenses", "opolisutilities:banned_in_item_repairer"]).displayName("Specialised Signalum License")
  event.create("opolisinc:specialised_license_lumium").texture("opolisinc:item/processing_license").maxDamage(40).color(0, 0xFFF170).tag(["market:licenses", "opolisutilities:banned_in_item_repairer"]).displayName("Specialised Lumium License")
  event.create("opolisinc:specialised_license_enderium").texture("opolisinc:item/processing_license").maxDamage(40).color(0, 0x005E45).tag(["market:licenses", "opolisutilities:banned_in_item_repairer"]).displayName("Specialised Enderium License")
  event.create("opolisinc:specialised_license_reinforced_alloy").texture("opolisinc:item/processing_license").maxDamage(40).color(0, 0x00F0ff).tag(["market:licenses", "opolisutilities:banned_in_item_repairer"]).displayName("Specialised Reinforced Alloy License")

  event.create("opolisinc:specialised_license_activated_signalum").texture("opolisinc:item/processing_license").maxDamage(40).color(0, 0xFF8B38).tag(["market:licenses", "opolisutilities:banned_in_item_repairer"]).displayName("Specialised Activated Signalum License")
  event.create("opolisinc:specialised_license_activated_lumium").texture("opolisinc:item/processing_license").maxDamage(40).color(0, 0xFAEF8E).tag(["market:licenses", "opolisutilities:banned_in_item_repairer"]).displayName("Specialised Activated Lumium License")
  event.create("opolisinc:specialised_license_activated_enderium").texture("opolisinc:item/processing_license").maxDamage(40).color(0, 0x016E51).tag(["market:licenses", "opolisutilities:banned_in_item_repairer"]).displayName("Specialised Activated Enderium License")

  event.create("opolisinc:specialised_license_villager_receipt_1").texture("opolisinc:item/trading_license").maxDamage(40).tag(["market:licenses", "opolisutilities:banned_in_item_repairer"]).displayName("Specialised Villager Receipt 1 License")
  event.create("opolisinc:specialised_license_villager_receipt_2").texture("opolisinc:item/trading_license").maxDamage(40).tag(["market:licenses", "opolisutilities:banned_in_item_repairer"]).displayName("Specialised Villager Receipt 2 License")
  event.create("opolisinc:specialised_license_villager_receipt_3").texture("opolisinc:item/trading_license").maxDamage(40).tag(["market:licenses", "opolisutilities:banned_in_item_repairer"]).displayName("Specialised Villager Receipt 3 License")
  event.create("opolisinc:specialised_license_villager_receipt_4").texture("opolisinc:item/trading_license").maxDamage(40).tag(["market:licenses", "opolisutilities:banned_in_item_repairer"]).displayName("Specialised Villager Receipt 4 License")
  event.create("opolisinc:specialised_license_villager_receipt_5").texture("opolisinc:item/trading_license").maxDamage(40).tag(["market:licenses", "opolisutilities:banned_in_item_repairer"]).displayName("Specialised Villager Receipt 5 License")

  event.create("opolisinc:specialised_license_chest").texture("opolisinc:item/storage_license").maxDamage(40).color(0, 0xBA4D25).tag(["market:licenses", "opolisutilities:banned_in_item_repairer"]).displayName("Specialised Chest License")
  event.create("opolisinc:specialised_license_wood").texture("opolisinc:item/storage_license").maxDamage(40).color(0, 0x521F0C).tag(["market:licenses", "opolisutilities:banned_in_item_repairer"]).displayName("Specialised Wood License")

  event.create("opolisinc:specialised_license_cell_component_16k").texture("opolisinc:item/storage_license").maxDamage(40).color(0, 0xE6FEFF).tag(["market:licenses", "opolisutilities:banned_in_item_repairer"]).displayName("Specialised 16k Storage Component License")
  event.create("opolisinc:specialised_license_entro_ingot").texture("opolisinc:item/storage_license").maxDamage(40).color(0, 0x26C759).tag(["market:licenses", "opolisutilities:banned_in_item_repairer"]).displayName("Specialised Entro Ingot License")

  event.create("opolisinc:specialised_license_cobblestone").texture("opolisinc:item/mining_license").maxDamage(40).color(0, 0x666666).tag(["market:licenses", "opolisutilities:banned_in_item_repairer"]).displayName("Specialised Cobblestone License")
  event.create("opolisinc:specialised_license_sand").texture("opolisinc:item/mining_license").maxDamage(40).color(0, 0xE0DD80).tag(["market:licenses", "opolisutilities:banned_in_item_repairer"]).displayName("Specialised Sand License")
  event.create("opolisinc:specialised_license_dirt").texture("opolisinc:item/mining_license").maxDamage(40).color(0, 0x40291B).tag(["market:licenses", "opolisutilities:banned_in_item_repairer"]).displayName("Specialised Dirt License")

  event.create("opolisinc:specialised_license_raw_iron").texture("opolisinc:item/mining_license").maxDamage(40).color(0, 0x7D5A46).tag(["market:licenses", "opolisutilities:banned_in_item_repairer"]).displayName("Specialised Raw Iron License")
  event.create("opolisinc:specialised_license_raw_tin").texture("opolisinc:item/mining_license").maxDamage(40).color(0, 0xA6E0DD).tag(["market:licenses", "opolisutilities:banned_in_item_repairer"]).displayName("Specialised Raw Tin License")
  event.create("opolisinc:specialised_license_lapis_lazuli").texture("opolisinc:item/mining_license").maxDamage(40).color(0, 0x171C85).tag(["market:licenses", "opolisutilities:banned_in_item_repairer"]).displayName("Specialised Lapis Lazuli License")
  event.create("opolisinc:specialised_license_raw_aluminum").texture("opolisinc:item/mining_license").maxDamage(40).color(0, 0xB1BDBC).tag(["market:licenses", "opolisutilities:banned_in_item_repairer"]).displayName("Specialised Raw Aluminum License")
  event.create("opolisinc:specialised_license_raw_copper").texture("opolisinc:item/mining_license").maxDamage(40).color(0, 0xFF7033).tag(["market:licenses", "opolisutilities:banned_in_item_repairer"]).displayName("Specialised Raw Copper License")
  event.create("opolisinc:specialised_license_cinnabar").texture("opolisinc:item/mining_license").maxDamage(40).color(0, 0xC40D00).tag(["market:licenses", "opolisutilities:banned_in_item_repairer"]).displayName("Specialised Cinnabar License")

  event.create("opolisinc:specialised_license_diamond").texture("opolisinc:item/mining_license").maxDamage(40).color(0, 0x00FFF7).tag(["market:licenses", "opolisutilities:banned_in_item_repairer"]).displayName("Specialised Diamond License")
  event.create("opolisinc:specialised_license_emerald").texture("opolisinc:item/mining_license").maxDamage(40).color(0, 0x00FF26).tag(["market:licenses", "opolisutilities:banned_in_item_repairer"]).displayName("Specialised Emerald License")
  event.create("opolisinc:specialised_license_quartz").texture("opolisinc:item/mining_license").maxDamage(40).color(0, 0xFFF9E3).tag(["market:licenses", "opolisutilities:banned_in_item_repairer"]).displayName("Specialised Nether Quartz License")
  event.create("opolisinc:specialised_license_ancient_debris").texture("opolisinc:item/mining_license").maxDamage(40).color(0, 0x2E1700).tag(["market:licenses", "opolisutilities:banned_in_item_repairer"]).displayName("Specialised Ancient Debris License")
  event.create("opolisinc:specialised_license_raw_platinum").texture("opolisinc:item/mining_license").maxDamage(40).color(0, 0x00DBCD).tag(["market:licenses", "opolisutilities:banned_in_item_repairer"]).displayName("Specialised Raw Platinum License")

  event.create("opolisinc:specialised_license_activated_raw_gold").texture("opolisinc:item/mining_license").maxDamage(40).color(0, 0xFFD129).tag(["market:licenses", "opolisutilities:banned_in_item_repairer"]).displayName("Specialised Activated Raw Gold License")
  event.create("opolisinc:specialised_license_activated_raw_nickel").texture("opolisinc:item/mining_license").maxDamage(40).color(0, 0xFFFDBD).tag(["market:licenses", "opolisutilities:banned_in_item_repairer"]).displayName("Specialised Activated Raw Nickel License")
  event.create("opolisinc:specialised_license_activated_raw_uranium").texture("opolisinc:item/mining_license").maxDamage(40).color(0, 0x1D4225).tag(["market:licenses", "opolisutilities:banned_in_item_repairer"]).displayName("Specialised Activated Raw Uranium License")
  event.create("opolisinc:specialised_license_activated_raw_silver").texture("opolisinc:item/mining_license").maxDamage(40).color(0, 0xEDEDED).tag(["market:licenses", "opolisutilities:banned_in_item_repairer"]).displayName("Specialised Activated Raw Silver License")
  event.create("opolisinc:specialised_license_activated_raw_lead").texture("opolisinc:item/mining_license").maxDamage(40).color(0, 0x3D444A).tag(["market:licenses", "opolisutilities:banned_in_item_repairer"]).displayName("Specialised Activated Raw Lead License")
  event.create("opolisinc:specialised_license_activated_raw_zinc").texture("opolisinc:item/mining_license").maxDamage(40).color(0, 0x9FC9C7).tag(["market:licenses", "opolisutilities:banned_in_item_repairer"]).displayName("Specialised Activated Raw Zinc License")
  event.create("opolisinc:specialised_license_activated_raw_osmium").texture("opolisinc:item/mining_license").maxDamage(40).color(0, 0x599C97).tag(["market:licenses", "opolisutilities:banned_in_item_repairer"]).displayName("Specialised Activated Raw Osmium License")

  event.create("opolisinc:specialised_license_wheat").texture("opolisinc:item/farming_license").maxDamage(40).color(0, 0x929635).tag(["market:licenses", "opolisutilities:banned_in_item_repairer"]).displayName("Specialised Wheat License")
  event.create("opolisinc:specialised_license_carrot").texture("opolisinc:item/farming_license").maxDamage(40).color(0, 0xC77A16).tag(["market:licenses", "opolisutilities:banned_in_item_repairer"]).displayName("Specialised Carrot License")
  event.create("opolisinc:specialised_license_potato").texture("opolisinc:item/farming_license").maxDamage(40).color(0, 0xAB8726).tag(["market:licenses", "opolisutilities:banned_in_item_repairer"]).displayName("Specialised Potato License")
  event.create("opolisinc:specialised_license_beetroot").texture("opolisinc:item/farming_license").maxDamage(40).color(0, 0xA11212).tag(["market:licenses", "opolisutilities:banned_in_item_repairer"]).displayName("Specialised Beetroot License")

  event.create("opolisinc:specialised_license_sculked_wheat").texture("opolisinc:item/farming_license").maxDamage(40).color(0, 0x929635).tag(["market:licenses", "opolisutilities:banned_in_item_repairer"]).displayName("Specialised Sculked Wheat License")
  event.create("opolisinc:specialised_license_sculked_carrot").texture("opolisinc:item/farming_license").maxDamage(40).color(0, 0xC77A16).tag(["market:licenses", "opolisutilities:banned_in_item_repairer"]).displayName("Specialised Sculked Carrot License")
  event.create("opolisinc:specialised_license_sculked_potato").texture("opolisinc:item/farming_license").maxDamage(40).color(0, 0xAB8726).tag(["market:licenses", "opolisutilities:banned_in_item_repairer"]).displayName("Specialised Sculked Potato License")
  event.create("opolisinc:specialised_license_sculked_beetroot").texture("opolisinc:item/farming_license").maxDamage(40).color(0, 0xA11212).tag(["market:licenses", "opolisutilities:banned_in_item_repairer"]).displayName("Specialised Sculked Beetroot License")

  event.create("opolisinc:specialised_license_weeping_vines").texture("opolisinc:item/farming_license").maxDamage(40).color(0, 0x730707).tag(["market:licenses", "opolisutilities:banned_in_item_repairer"]).displayName("Specialised Weeping Vines License")
  event.create("opolisinc:specialised_license_twisting_vines").texture("opolisinc:item/farming_license").maxDamage(40).color(0, 0x08807C).tag(["market:licenses", "opolisutilities:banned_in_item_repairer"]).displayName("Specialised Twisting Vines License")

  event.create("opolisinc:specialised_license_phased_wheat").texture("opolisinc:item/farming_license").maxDamage(40).color(0, 0xAEB340).tag(["market:licenses", "opolisutilities:banned_in_item_repairer"]).displayName("Specialised Phased Wheat License")
  event.create("opolisinc:specialised_license_phased_carrot").texture("opolisinc:item/farming_license").maxDamage(40).color(0, 0xDB8618).tag(["market:licenses", "opolisutilities:banned_in_item_repairer"]).displayName("Specialised Phased Carrot License")
  event.create("opolisinc:specialised_license_phased_potato").texture("opolisinc:item/farming_license").maxDamage(40).color(0, 0xBA9329).tag(["market:licenses", "opolisutilities:banned_in_item_repairer"]).displayName("Specialised Phased Potato License")
  event.create("opolisinc:specialised_license_phased_beetroot").texture("opolisinc:item/farming_license").maxDamage(40).color(0, 0xB81616).tag(["market:licenses", "opolisutilities:banned_in_item_repairer"]).displayName("Specialised Phased Beetroot License")
})
