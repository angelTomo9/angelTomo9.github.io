// priority: 0
Platform.getInfo('opolisinc').name = 'Opolis Inc'

StartupEvents.registry('block', event => {

    //Mining ore
    event.create("opolisinc:basic_license_ore")
        .stoneSoundType()
        .requiresTool()
        .tagBlock(["minecraft:mineable/pickaxe", "minecraft:needs_stone_tool"])

    event.create("opolisinc:advanced_license_ore")
        .stoneSoundType()
        .requiresTool()
        .tagBlock(["minecraft:mineable/pickaxe", "minecraft:needs_iron_tool"])

    event.create("opolisinc:elite_license_ore")
        .stoneSoundType()
        .requiresTool()
        .tagBlock(["minecraft:mineable/pickaxe", "minecraft:needs_diamond_tool"])

    event.create("opolisinc:ultimate_license_ore")
        .stoneSoundType()
        .requiresTool()
        .tagBlock(["minecraft:mineable/pickaxe", "minecraft:needs_diamond_tool"])


    //Bacterial Mulch
    event.create("opolisinc:benign_bacterial_mulch")
        .gravelSoundType()
        .tagBlock("minecraft:mineable/shovel")
        .texture("opolisinc:block/benign_bacterial_mulch")

    event.create("opolisinc:malignant_bacterial_mulch")
        .gravelSoundType()
        .tagBlock("minecraft:mineable/shovel")
        .texture("opolisinc:block/malignant_bacterial_mulch")

    event.create("opolisinc:feverish_bacterial_mulch")
        .gravelSoundType()
        .tagBlock("minecraft:mineable/shovel")
        .texture("opolisinc:block/feverish_bacterial_mulch")

    event.create("opolisinc:draconic_bacterial_mulch")
        .gravelSoundType()
        .tagBlock("minecraft:mineable/shovel")
        .texture("opolisinc:block/draconic_bacterial_mulch")

    event.create("opolisinc:irradiated_bacterial_mulch")
        .gravelSoundType()
        .tagBlock("minecraft:mineable/shovel")
        .texture("opolisinc:block/irradiated_bacterial_mulch")

    event.create("opolisinc:demon_core")
        .displayName("§dDemon Core")
        .soundType("netherite_block")
        //  .model("opolisinc:block/demon_core")
        .box(4, 0, 4, 12, 8, 12, true)

    event.create("opolisinc:beehive_portal_stabilizer")
        .displayName("§eBeehive Portal Stabilizer")
        .soundType("wood")
        .tagBlock("the_bumblezone:dimension_teleportation/required_blocks_under_beehive_to_teleport")

    event.create("opolisinc:opolisite_block")
        .soundType("netherite_block")
        .tagItem("c:storage_blocks/opolisite")
        .requiresTool()
        .tagBlock(["minecraft:mineable/pickaxe", "minecraft:needs_diamond_tool"])

    event.create("opolisinc:hyperdense_stone").soundType("polished_deepslate").hardness(50).resistance(1200).requiresTool().tagBlock(["minecraft:mineable/pickaxe", "minecraft:needs_diamond_tool"])
    event.create("opolisinc:hyperdense_stone_step_1").soundType("polished_deepslate").hardness(50).resistance(1200).requiresTool().tagBlock(["minecraft:mineable/pickaxe", "minecraft:needs_diamond_tool"]).displayName("Ferrite-Infused Hyperdense Stone")
    event.create("opolisinc:hyperdense_stone_step_2").soundType("polished_deepslate").hardness(50).resistance(1200).requiresTool().tagBlock(["minecraft:mineable/pickaxe", "minecraft:needs_diamond_tool"]).displayName("Ferrite-Infused Cuprite-Veined Hyperdense Stone")
    event.create("opolisinc:hyperdense_stone_step_3").soundType("polished_deepslate").hardness(50).resistance(1200).requiresTool().tagBlock(["minecraft:mineable/pickaxe", "minecraft:needs_diamond_tool"]).displayName("Ferrite-Infused Cuprite-Veined Pyrite-Laced Hyperdense Stone")
    event.create("opolisinc:hyperdense_stone_step_4").soundType("polished_deepslate").hardness(50).resistance(1200).requiresTool().tagBlock(["minecraft:mineable/pickaxe", "minecraft:needs_diamond_tool"]).displayName("Ferrite-Infused Cuprite-Veined Pyrite-Laced Anthracite-Embedded Hyperdense Stone")
    event.create("opolisinc:hyperdense_stone_step_5").soundType("polished_deepslate").hardness(50).resistance(1200).requiresTool().tagBlock(["minecraft:mineable/pickaxe", "minecraft:needs_diamond_tool"]).displayName("Ferrite-Infused Cuprite-Veined Pyrite-Laced Anthracite-Embedded Pitchblende-Threaded Hyperdense Stone")
    event.create("opolisinc:hyperdense_stone_step_6").soundType("polished_deepslate").hardness(50).resistance(1200).requiresTool().tagBlock(["minecraft:mineable/pickaxe", "minecraft:needs_diamond_tool"]).displayName("Ferrite-Infused Cuprite-Veined Pyrite-Laced Anthracite-Embedded Pitchblende-Threaded Silica-Imbued Hyperdense Stone")
    event.create("opolisinc:hyperdense_stone_step_7").soundType("polished_deepslate").hardness(50).resistance(1200).requiresTool().tagBlock(["minecraft:mineable/pickaxe", "minecraft:needs_diamond_tool"]).displayName("Ferrite-Infused Cuprite-Veined Pyrite-Laced Anthracite-Embedded Pitchblende-Threaded Silica-Imbued Sperrylite-Riddled Hyperdense Stone")
    event.create("opolisinc:hyperdense_stone_step_8").soundType("polished_deepslate").hardness(50).resistance(1200).requiresTool().tagBlock(["minecraft:mineable/pickaxe", "minecraft:needs_diamond_tool"]).displayName("Ferrite-Infused Cuprite-Veined Pyrite-Laced Anthracite-Embedded Pitchblende-Threaded Silica-Imbued Sperrylite-Riddled Beryl-Striated Hyperdense Stone")
    event.create("opolisinc:hyperdense_stone_step_9").soundType("polished_deepslate").hardness(50).resistance(1200).requiresTool().tagBlock(["minecraft:mineable/pickaxe", "minecraft:needs_diamond_tool"]).displayName("Ferrite-Infused Cuprite-Veined Pyrite-Laced Anthracite-Embedded Pitchblende-Threaded Silica-Imbued Sperrylite-Riddled Beryl-Striated Kimberlite-Streaked Hyperdense Stone")

    event.create("opolisinc:central_routing_node").soundType("netherite_block")
    event.create("opolisinc:superposition_storage_drive").soundType("netherite_block")
    event.create("opolisinc:universal_adapter").soundType("netherite_block")
    event.create("opolisinc:bio_neural_processor").soundType("netherite_block").displayName("Bio-neural Processor")
    event.create("opolisinc:time_crystal_power_conduit").soundType("netherite_block")
    event.create("opolisinc:galactic_simulator").soundType("netherite_block")
    event.create("opolisinc:nebulous_negotiator").soundType("netherite_block")
})
