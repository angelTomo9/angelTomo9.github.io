// priority: 0
Platform.mods.kubejs.name = 'Opolis Inc'

StartupEvents.registry('fluid', event => {

    event.create('opolisinc:molten_dielectric', 'thick').tint('#808080')
    event.create("opolisinc:nuclear_waste", "thick").tint("#4F412A").tag("c:nuclear_waste")

    event.create("opolisinc:basic_processing_alloy", "thick").tint("#7766FF")
    event.create("opolisinc:advanced_processing_alloy", "thick").tint("#7766FF")
    event.create("opolisinc:elite_processing_alloy", "thick").tint("#7766FF")
    event.create("opolisinc:ultimate_processing_alloy", "thick").tint("#7766FF")

    event.create("opolisinc:molten_activated_signalum", "thick").tint("#FFB15E")
    event.create("opolisinc:molten_activated_lumium", "thick").tint("#FFD77A")
    event.create("opolisinc:molten_activated_enderium", "thick").tint("#02CCB8")
    event.create("opolisinc:molten_inert_opolisite", "thick").tint("#1691C7")
    event.create("opolisinc:molten_opolisite", "thick").tint("#1BB9FF")

    event.create("opolisinc:quantum_memory_fluid", "thin").tint("light_purple")

    event.create("opolisinc:benign_bacterial_sludge", "thick").tint("#3D400D")
    event.create("opolisinc:malignant_bacterial_sludge", "thick").tint("#13360F")
    event.create("opolisinc:feverish_bacterial_sludge", "thick").tint("#632525")
    event.create("opolisinc:draconic_bacterial_sludge", "thick").tint("#4B2F78")
    event.create("opolisinc:irradiated_bacterial_sludge", "thick").tint("#261E11")

    event.create("opolisinc:molten_prosperity", "thin").tint("#D6FFF9")

    //Molten Essence
    /*event.create("opolisinc:essence_of_iron", "thin").tint("#EBEBEB")
    event.create("opolisinc:essence_of_copper", "thin").tint("#FF7033")
    event.create("opolisinc:essence_of_gold", "thin").tint("#FFD129")
    event.create("opolisinc:essence_of_coal", "thin").tint("#292929")
    event.create("opolisinc:essence_of_redstone", "thin").tint("#A80000")
    event.create("opolisinc:essence_of_lapis_lazuli", "thin").tint("#171C85")
    event.create("opolisinc:essence_of_quartz", "thin").tint("#FFFAE6")
    event.create("opolisinc:essence_of_diamond", "thin").tint("#00FFEE")
    event.create("opolisinc:essence_of_emerald", "thin").tint("#00FF4C")
    event.create("opolisinc:essence_of_netherite", "thin").tint("#3D3D3D")
    event.create("opolisinc:essence_of_aluminum", "thin").tint("#B1BDBC")
    event.create("opolisinc:essence_of_tin", "thin").tint("#A6E0DD")
    event.create("opolisinc:essence_of_nickel", "thin").tint("#FFFDBD")
    event.create("opolisinc:essence_of_silver", "thin").tint("#EDEDED")
    event.create("opolisinc:essence_of_zinc", "thin").tint("#9FC9C7")
    event.create("opolisinc:essence_of_lead", "thin").tint("#3D444A")
    event.create("opolisinc:essence_of_uranium", "thin").tint("#1D4225")
    event.create("opolisinc:essence_of_osmium", "thin").tint("#599C97")
    event.create("opolisinc:essence_of_platinum", "thin").tint("#54FFF1")
    event.create("opolisinc:essence_of_iridium", "thin").tint("#ABABAB")*/

})

const $Chemical = Java.loadClass('mekanism.api.chemical.Chemical')
const $ChemicalBuilder = Java.loadClass('mekanism.api.chemical.ChemicalBuilder')
const $ChemicalAttributes = Java.loadClass('mekanism.api.chemical.attribute.ChemicalAttributes')
const $ChemicalRadioactivity = Java.loadClass('mekanism.api.datamaps.chemical.attribute.ChemicalRadioactivity')
const $Radiation = $ChemicalAttributes.Radiation

StartupEvents.registry('mekanism:chemical', event => {
    event.createCustom('opolisinc:noisy_activation_essence', () =>
        new $Chemical($ChemicalBuilder.builder().tint(0x7129D6))
    )

    event.createCustom('opolisinc:filtered_activation_essence', () =>
        new $Chemical($ChemicalBuilder.builder().tint(0x37E7ED))
    )

    // Optional: make ONLY unstable radioactive
    event.createCustom('opolisinc:unstable_activation_essence', () =>
        new $Chemical(
            $ChemicalBuilder.builder()
                .tint(0x42F5AD)
                .with(new $Radiation(new $ChemicalRadioactivity(0.02)))
        )
    )
})


// .thickTexture(0x373438)
// .bucketColor(0x373438)