StartupEvents.registry("sound_event", event => {
    event.create("opolisinc:time_echo")
})