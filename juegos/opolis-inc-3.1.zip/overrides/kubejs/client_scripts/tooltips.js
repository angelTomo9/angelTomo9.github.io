

ItemEvents.modifyTooltips(event => {
 
  event.add(['mekanism:raw_tin', 'mekanism:raw_lead', 'mekanism:raw_osmium', 'mekanism:raw_uranium', 'mekanism:fluorite_gem'], 'Craft in crafting table to convert!')


})