// Hide items from recipe viewers like JEI
RecipeViewerEvents.removeEntries('item', event => {
	event.remove(/caveopolis:/);
	event.remove('opolisutilities:cloche');
	event.remove('opolisutilities:smart_crafting_table');
	event.remove('extendedae:quartz_blend');
});