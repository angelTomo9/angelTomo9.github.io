// Visit the wiki for more info - https://kubejs.com/

/*
JEIEvents.hideItems(event => {

  //  event.hide('bedrockminer:bedrock_breaker')
})

JEIEvents.addItems(event => {

    event.add('market:market')
})

JEIEvents.removeCategories(event => {

 //   event.remove('jeresources:worldgen')

})

*/