---
navigation:
    title: Casting 
    position: 0
    icon: 'casting:controller'
    
---

# Casting Guide Book

Casting and you
<ItemImage id="casting:controller" />

This guide contains a lot of information about the casting mod! Information from Techopolis 3

